import React, { useState, useRef, useEffect, useMemo } from "react";
import {
  Sparkles,
  X,
  Send,
  RotateCcw,
  Bot,
  User,
  Loader2,
  AlertCircle,
  HelpCircle,
  Maximize2,
  Minimize2,
  Copy,
  Check,
  ShieldCheck,
  BarChart3,
  FileText,
  Printer,
  ChevronDown,
  Wand2,
  Download,
  Search,
  BookOpen,
  Volume2,
  VolumeX
} from "lucide-react";
import { InventoryItem } from "../types";

interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: string;
  category?: "guidance" | "analytics" | "draft" | "search";
}

interface AIAssistantChatProps {
  databaseStore?: InventoryItem[];
  activeStation?: string;
  currentTab?: "IT" | "Furniture" | "Misc";
  authenticatedUser?: string;
}

const DEFAULT_WELCOME_MESSAGE: ChatMessage = {
  id: "welcome-1",
  role: "assistant",
  content: `👋 **Welcome to the ECP Inventory Management AI Assistant!**

I am equipped with specialized tools to assist Election Commission of Pakistan officers:
• **Live Analytics:** Instant stats on IT, Furniture, and Misc stock & repair statuses.
• **Official Drafting:** Generate official ECP handover memos, condemnation notices & remarks.
• **Printing & Reports:** Walkthroughs for official single-line A4 landscape PDF generation.
• **System & Security:** Guidelines on role privileges, SuperAdmin controls, and Supabase synchronization.

*For data integrity, I provide operational guidance and drafting. Direct record additions or removals are performed securely via the portal forms.*`,
  timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
};

const QUICK_ACTIONS = [
  {
    label: "📊 Stock Summary",
    prompt: "Provide an executive summary of current inventory breakdown and condition across all categories.",
    category: "analytics" as const,
  },
  {
    label: "📝 Draft Handover Memo",
    prompt: "Draft an official ECP Handover & Receiving Certificate format for assigning a laptop and printer to an official.",
    category: "draft" as const,
  },
  {
    label: "🖨️ A4 Landscape Print Guide",
    prompt: "How do I print the registry or save as PDF ensuring all columns fit into a single line without wrapping?",
    category: "guidance" as const,
  },
  {
    label: "⚠️ Condemnation Procedure",
    prompt: "What is the standard procedure and criteria for marking non-working assets as 'Ready for Condemnation'?",
    category: "guidance" as const,
  },
];

export default function AIAssistantChat({
  databaseStore = [],
  activeStation = "All Offices",
  currentTab = "IT",
  authenticatedUser = "User",
}: AIAssistantChatProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([DEFAULT_WELCOME_MESSAGE]);
  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isSpeakingId, setIsSpeakingId] = useState<string | null>(null);
  const [activeQuickTab, setActiveQuickTab] = useState<"all" | "analytics" | "draft" | "guidance">("all");
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  // Compute live inventory summary snapshot to feed AI context
  const liveInventorySummary = useMemo(() => {
    const totalAssets = databaseStore.length;
    const itCount = databaseStore.filter((i) => (i.tabContext || "").toLowerCase() === "it").length;
    const furnitureCount = databaseStore.filter((i) => (i.tabContext || "").toLowerCase() === "furniture").length;
    const miscCount = databaseStore.filter((i) => (i.tabContext || "").toLowerCase() === "misc").length;
    
    const workingItems = databaseStore.filter((i) => (i.workingStatus || "").toLowerCase() === "working");
    const workingCount = workingItems.length;
    const issuedCount = workingItems.filter((i) => (i.workingSubStatus || "").toLowerCase() === "issued").length;
    const instockCount = workingItems.filter((i) => (i.workingSubStatus || "").toLowerCase() === "in-stock" || (i.workingSubStatus || "").toLowerCase() === "instock").length;

    const nonWorkingItems = databaseStore.filter((i) => (i.workingStatus || "").toLowerCase() !== "working");
    const nonWorkingCount = nonWorkingItems.length;
    const needsRepairCount = nonWorkingItems.filter((i) => (i.nonWorkingSubStatus || "").toLowerCase().includes("repair")).length;
    const condemnationCount = nonWorkingItems.filter((i) => (i.nonWorkingSubStatus || "").toLowerCase().includes("condem")).length;

    return {
      totalAssets,
      activeStation,
      itCount,
      furnitureCount,
      miscCount,
      workingCount,
      issuedCount,
      instockCount,
      nonWorkingCount,
      needsRepairCount,
      condemnationCount,
    };
  }, [databaseStore, activeStation]);

  // Auto scroll to bottom
  const scrollToBottom = (behavior: ScrollBehavior = "smooth") => {
    messagesEndRef.current?.scrollIntoView({ behavior });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom("auto");
      setTimeout(() => inputRef.current?.focus(), 150);
    }
  }, [isOpen, isExpanded]);

  useEffect(() => {
    if (isOpen) {
      scrollToBottom("smooth");
    }
  }, [messages, isLoading]);

  // Clean speech synthesis if closed
  useEffect(() => {
    return () => {
      if (typeof window !== "undefined" && "speechSynthesis" in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  const handleSendMessage = async (textToSend?: string) => {
    const rawText = textToSend !== undefined ? textToSend : inputValue;
    const trimmed = rawText.trim();
    if (!trimmed || isLoading) return;

    if (trimmed.length > 2000) {
      setErrorMessage("Your message exceeds the 2,000 character limit.");
      return;
    }

    setErrorMessage(null);
    const userMessage: ChatMessage = {
      id: "msg-" + Date.now() + "-u",
      role: "user",
      content: trimmed,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };

    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    setInputValue("");
    setIsLoading(true);

    try {
      const apiPayload = {
        messages: newMessages.map((m) => ({
          role: m.role,
          content: m.content,
        })),
        inventorySummary: liveInventorySummary,
      };

      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(apiPayload),
      });

      const data = await response.json().catch(() => null);

      if (!response.ok) {
        throw new Error(
          data?.error || `Server error (${response.status}): Failed to generate response.`
        );
      }

      if (!data || !data.reply) {
        throw new Error("Received empty response from assistant.");
      }

      const assistantMessage: ChatMessage = {
        id: "msg-" + Date.now() + "-a",
        role: "assistant",
        content: data.reply,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } catch (err: any) {
      console.error("AI Assistant error:", err);
      setErrorMessage(
        err.message || "Failed to reach AI service. Please ensure GEMINI_API_KEY is configured."
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleClearChat = () => {
    if (window.confirm("Are you sure you want to reset the conversation?")) {
      if (typeof window !== "undefined" && "speechSynthesis" in window) {
        window.speechSynthesis.cancel();
      }
      setIsSpeakingId(null);
      setMessages([
        {
          ...DEFAULT_WELCOME_MESSAGE,
          timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        },
      ]);
      setErrorMessage(null);
    }
  };

  const handleCopyText = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleToggleSpeak = (id: string, text: string) => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) {
      alert("Text-to-speech is not supported in this browser.");
      return;
    }

    if (isSpeakingId === id) {
      window.speechSynthesis.cancel();
      setIsSpeakingId(null);
      return;
    }

    window.speechSynthesis.cancel();
    // Strip markdown formatting for cleaner audio
    const cleanText = text
      .replace(/[*#_`~]/g, "")
      .replace(/•/g, " ")
      .trim();

    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;
    utterance.onend = () => setIsSpeakingId(null);
    utterance.onerror = () => setIsSpeakingId(null);

    setIsSpeakingId(id);
    window.speechSynthesis.speak(utterance);
  };

  // Helper to format assistant markdown-like bold and bullet text
  const renderFormattedContent = (content: string) => {
    const lines = content.split("\n");
    return lines.map((line, idx) => {
      const isBullet = line.trim().startsWith("•") || line.trim().startsWith("-") || line.trim().startsWith("*");
      const cleanLine = isBullet ? line.replace(/^[\s•\-\*]+/, "") : line;

      const parts = cleanLine.split(/(\*\*.*?\*\*)/g);
      const renderedParts = parts.map((part, partIdx) => {
        if (part.startsWith("**") && part.endsWith("**")) {
          return (
            <strong key={partIdx} className="font-bold text-blue-700 dark:text-blue-300">
              {part.slice(2, -2)}
            </strong>
          );
        }
        return part;
      });

      if (isBullet) {
        return (
          <div key={idx} className="flex items-start gap-2 my-1">
            <span className="text-blue-600 font-bold leading-none select-none mt-1">•</span>
            <div className="flex-1 leading-relaxed">{renderedParts}</div>
          </div>
        );
      }

      if (!line.trim()) {
        return <div key={idx} className="h-2" />;
      }

      return (
        <div key={idx} className="my-1 leading-relaxed">
          {renderedParts}
        </div>
      );
    });
  };

  return (
    <>
      {/* Floating Launcher Button */}
      <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end print:hidden">
        {!isOpen && (
          <button
            onClick={() => setIsOpen(true)}
            aria-label="Open ECP AI Assistant"
            className="group relative flex items-center gap-3 px-4 py-3 rounded-full text-white font-bold text-sm shadow-2xl transition-all duration-300 transform hover:scale-105 active:scale-95 cursor-pointer bg-gradient-to-r from-emerald-700 via-teal-700 to-emerald-800 hover:from-emerald-600 hover:to-teal-600 border border-emerald-400/40 shadow-emerald-950/40"
          >
            <div className="relative flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-amber-300 animate-pulse" />
              <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-300 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-300"></span>
              </span>
            </div>
            <span className="tracking-wide text-xs uppercase font-extrabold flex items-center gap-1.5">
              <span>ECP AI Assistant</span>
              <span className="px-1.5 py-0.5 text-[9px] bg-emerald-950/80 rounded text-emerald-200 border border-emerald-400/40 font-mono">
                Gemini 3.8
              </span>
            </span>
          </button>
        )}
      </div>

      {/* Floating Chat Modal */}
      {isOpen && (
        <div
          role="dialog"
          aria-labelledby="ai-chat-header"
          className={`fixed bottom-6 right-6 z-50 flex flex-col rounded-2xl shadow-2xl overflow-hidden border transition-all duration-300 animate-in fade-in slide-in-from-bottom-5 print:hidden ${
            isExpanded
              ? "w-[720px] max-w-[calc(100vw-2rem)] h-[780px] max-h-[92vh]"
              : "w-[440px] max-w-[calc(100vw-2rem)] h-[620px] max-h-[86vh]"
          }`}
          style={{
            backgroundColor: "var(--bg-card, #ffffff)",
            color: "var(--color-text, #1e293b)",
            borderColor: "var(--border-color, #cbd5e1)",
          }}
        >
          {/* Header */}
          <div
            id="ai-chat-header"
            className="px-4 py-3.5 flex items-center justify-between text-white border-b select-none shadow-sm"
            style={{
              backgroundColor: "var(--header-bg, #142B4A)",
              borderColor: "var(--border-color, #1e3a5f)",
            }}
          >
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="relative p-2 rounded-xl bg-blue-600/30 border border-blue-400/30 text-amber-300 flex items-center justify-center shrink-0">
                <Bot className="w-5 h-5" />
                <span className="absolute -top-0.5 -right-0.5 h-2.5 w-2.5 rounded-full bg-emerald-400 ring-2 ring-navy-900"></span>
              </div>
              <div className="truncate">
                <div className="flex items-center gap-1.5">
                  <h3 className="font-extrabold text-sm tracking-wide text-white truncate">
                    ECP AI Assistant
                  </h3>
                  <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                    Online
                  </span>
                </div>
                <p className="text-[11px] text-slate-300 flex items-center gap-1 truncate">
                  <span>Gemini 3.8 Flash</span>
                  <span>•</span>
                  <span>Inventory Advisor</span>
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1 shrink-0">
              <button
                onClick={() => setIsExpanded((prev) => !prev)}
                title={isExpanded ? "Collapse to standard size" : "Expand chat window"}
                className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-white/10 transition cursor-pointer"
              >
                {isExpanded ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
              </button>
              <button
                onClick={handleClearChat}
                title="Reset conversation"
                className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-white/10 transition cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
              <button
                onClick={() => setIsOpen(false)}
                title="Close Assistant"
                className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-white/10 transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Real-time Portal Snapshot Ribbon */}
          <div
            className="px-3.5 py-2 text-[11px] flex flex-wrap items-center justify-between gap-2 border-b select-none transition-colors"
            style={{
              backgroundColor: "var(--bg-card-alt, #f8fafc)",
              borderColor: "var(--border-color, #e2e8f0)",
              color: "var(--color-text-muted, #64748b)",
            }}
          >
            <div className="flex items-center gap-2">
              <span className="flex items-center gap-1 font-bold text-slate-700 dark:text-slate-300">
                <BarChart3 className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                Live Context:
              </span>
              <span className="font-mono text-xs font-black text-blue-700 dark:text-blue-300">
                {liveInventorySummary.totalAssets} Total Assets
              </span>
            </div>
            <div className="flex items-center gap-1.5 font-mono text-[10px]">
              <span className="px-1.5 py-0.5 rounded bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 font-bold">
                {liveInventorySummary.workingCount} Working
              </span>
              <span className="px-1.5 py-0.5 rounded bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 font-bold">
                {liveInventorySummary.nonWorkingCount} Non-Working
              </span>
            </div>
          </div>

          {/* Quick Actions Tabs */}
          <div
            className="px-3 py-1.5 flex items-center gap-1.5 border-b overflow-x-auto text-[11px] select-none"
            style={{
              backgroundColor: "var(--bg-main, #f1f5f9)",
              borderColor: "var(--border-color, #e2e8f0)",
            }}
          >
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500 mr-1 shrink-0">
              Quick Tools:
            </span>
            {QUICK_ACTIONS.map((action, idx) => (
              <button
                key={idx}
                onClick={() => handleSendMessage(action.prompt)}
                className="whitespace-nowrap px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 hover:border-blue-500 hover:text-blue-600 shadow-xs"
              >
                {action.label}
              </button>
            ))}
          </div>

          {/* Messages Scroll Area */}
          <div
            className="flex-1 overflow-y-auto p-4 space-y-3.5 text-xs"
            style={{ backgroundColor: "var(--bg-main, #f1f5f9)" }}
          >
            {messages.map((message) => {
              const isUser = message.role === "user";
              const isSpeaking = isSpeakingId === message.id;

              return (
                <div
                  key={message.id}
                  className={`flex items-start gap-2.5 ${isUser ? "justify-end" : "justify-start"}`}
                >
                  {!isUser && (
                    <div className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0 bg-[#142B4A] text-white shadow-sm mt-0.5 border border-blue-400/20">
                      <Bot className="w-4 h-4 text-amber-300" />
                    </div>
                  )}

                  <div
                    className={`relative group max-w-[85%] rounded-2xl p-3.5 text-xs shadow-sm ${
                      isUser
                        ? "bg-blue-600 text-white rounded-tr-xs"
                        : "rounded-tl-xs border"
                    }`}
                    style={
                      !isUser
                        ? {
                            backgroundColor: "var(--bg-card, #ffffff)",
                            color: "var(--color-text, #1e293b)",
                            borderColor: "var(--border-color, #e2e8f0)",
                          }
                        : undefined
                    }
                  >
                    {/* Header info */}
                    <div className="flex items-center justify-between gap-3 mb-1 text-[10px] opacity-75">
                      <span className="font-bold flex items-center gap-1">
                        {isUser ? "Officer" : "ECP AI Assistant"}
                      </span>
                      <span>{message.timestamp}</span>
                    </div>

                    {/* Content */}
                    <div className="whitespace-pre-wrap leading-relaxed select-text font-normal">
                      {isUser ? message.content : renderFormattedContent(message.content)}
                    </div>

                    {/* Assistant Quick Actions (Copy, TTS read aloud) */}
                    {!isUser && (
                      <div className="flex items-center gap-1.5 mt-2.5 pt-2 border-t border-slate-100 dark:border-slate-800/60 justify-end">
                        <button
                          onClick={() => handleToggleSpeak(message.id, message.content)}
                          title={isSpeaking ? "Stop voice audio" : "Read aloud with voice"}
                          className={`p-1.5 rounded-md text-[10px] font-bold flex items-center gap-1 transition cursor-pointer ${
                            isSpeaking
                              ? "bg-amber-100 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300"
                              : "bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300"
                          }`}
                        >
                          {isSpeaking ? <VolumeX className="w-3.5 h-3.5 text-amber-600" /> : <Volume2 className="w-3.5 h-3.5" />}
                          <span>{isSpeaking ? "Stop" : "Listen"}</span>
                        </button>

                        <button
                          onClick={() => handleCopyText(message.id, message.content)}
                          title="Copy answer"
                          className="p-1.5 rounded-md text-[10px] font-bold flex items-center gap-1 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 transition cursor-pointer"
                        >
                          {copiedId === message.id ? (
                            <>
                              <Check className="w-3.5 h-3.5 text-emerald-500" />
                              <span className="text-emerald-600 font-bold">Copied</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3.5 h-3.5" />
                              <span>Copy</span>
                            </>
                          )}
                        </button>
                      </div>
                    )}
                  </div>

                  {isUser && (
                    <div className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0 bg-slate-700 text-white shadow-sm mt-0.5">
                      <User className="w-4 h-4 text-slate-200" />
                    </div>
                  )}
                </div>
              );
            })}

            {/* Loading Indicator */}
            {isLoading && (
              <div className="flex items-start gap-2.5 justify-start">
                <div className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0 bg-[#142B4A] text-white shadow-sm border border-blue-400/20">
                  <Bot className="w-4 h-4 text-amber-300" />
                </div>
                <div
                  className="rounded-2xl rounded-tl-xs p-3.5 border shadow-sm flex items-center gap-2.5 text-xs"
                  style={{
                    backgroundColor: "var(--bg-card, #ffffff)",
                    borderColor: "var(--border-color, #e2e8f0)",
                    color: "var(--color-text, #1e293b)",
                  }}
                >
                  <Loader2 className="w-4 h-4 text-blue-600 animate-spin" />
                  <span className="text-slate-600 dark:text-slate-300 font-medium animate-pulse">
                    ECP Assistant is analyzing inventory data & preparing guidance...
                  </span>
                </div>
              </div>
            )}

            {/* Error Message Notice */}
            {errorMessage && (
              <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800/50 text-red-700 dark:text-red-300 text-xs flex items-start gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-500" />
                <div className="flex-1">
                  <p className="font-bold">Assistant Error</p>
                  <p className="mt-0.5 text-[11px] leading-relaxed">{errorMessage}</p>
                </div>
                <button
                  onClick={() => setErrorMessage(null)}
                  className="text-red-500 hover:text-red-700 text-xs font-bold"
                >
                  Dismiss
                </button>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Input & Form Area */}
          <div
            className="p-3.5 border-t"
            style={{
              backgroundColor: "var(--bg-card, #ffffff)",
              borderColor: "var(--border-color, #e2e8f0)",
            }}
          >
            <div className="relative flex items-end gap-2">
              <textarea
                ref={inputRef}
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Ask about inventory counts, print formats, drafting memos, or procedures... (Enter to send)"
                rows={2}
                maxLength={2000}
                disabled={isLoading}
                className="w-full resize-none rounded-xl p-2.5 text-xs border focus:outline-none focus:ring-2 focus:ring-blue-500 transition disabled:opacity-50"
                style={{
                  backgroundColor: "var(--input-bg, #ffffff)",
                  borderColor: "var(--input-border, #cbd5e1)",
                  color: "var(--color-text, #1e293b)",
                }}
              />
              <button
                onClick={() => handleSendMessage()}
                disabled={!inputValue.trim() || isLoading}
                aria-label="Send message"
                className="h-10 w-10 shrink-0 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:bg-slate-400 text-white flex items-center justify-center transition cursor-pointer shadow-sm disabled:cursor-not-allowed"
              >
                {isLoading ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Send className="w-4 h-4" />
                )}
              </button>
            </div>

            <div className="mt-2 flex items-center justify-between text-[10px] text-slate-400">
              <span className="flex items-center gap-1">
                Press <kbd className="px-1 py-0.5 rounded bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-mono">Enter</kbd> to send &bull; Shift+Enter for newline
              </span>
              <span>{inputValue.length}/2000 chars</span>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
