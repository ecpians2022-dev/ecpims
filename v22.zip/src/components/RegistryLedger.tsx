import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import * as XLSX from 'xlsx';
import { 
  FileSpreadsheet, Printer, Trash2, Edit2, Plus, 
  CheckCircle2, Search, Filter, Download, Sofa, Layers, Cpu, Camera, Droplet, Tv, Laptop, Package,
  AlertTriangle, Shield, RotateCcw, Zap, X, FileDown
} from 'lucide-react';
import { InventoryItem } from '../types';
import { triggerPrintDocument, saveElementAsPDF } from '../utils/printHelper';

interface RegistryLedgerProps {
  key?: string;
  currentTab: "IT" | "Furniture" | "Misc";
  scopeData: InventoryItem[];
  allLocationData?: InventoryItem[];
  currentNodeLocation: string;
  isWriteAllowed: boolean;
  isSuperAdmin?: boolean;
  isLightMode?: boolean;
  onItemCommit: (payload: Omit<InventoryItem, 'timestampId'> & { timestampId?: number }) => Promise<void>;
  onItemDelete: (timestampId: number) => Promise<void>;
  onItemDeleteAll: () => Promise<void>;
  onTabChange?: (tab: "IT" | "Furniture" | "Misc") => void;
  onItemsBulkCommit?: (items: InventoryItem[]) => Promise<{ successCount: number; totalCount: number } | void>;
}

function normalizeNodeLocation(raw: string): string {
  const trimmed = (raw || "").trim();
  const lower = trimmed.toLowerCase();
  
  if (lower === "rec kohat") return "REC Kohat";
  if (lower === "dec kohat") return "DEC Kohat";
  if (lower === "dec hangu") return "DEC Hangu";
  if (lower === "dec karak") return "DEC Karak";
  if (lower === "dec orakzai") return "DEC Orakzai";
  if (lower === "dec kurram") return "DEC Kurram";
  if (lower === "system_settings") return "SYSTEM_SETTINGS";
  
  if (lower.startsWith("dec ")) {
    const rest = trimmed.substring(4).trim();
    const capitalizedRest = rest.charAt(0).toUpperCase() + rest.slice(1);
    return `DEC ${capitalizedRest}`;
  }
  if (lower.startsWith("rec ")) {
    const rest = trimmed.substring(4).trim();
    const capitalizedRest = rest.charAt(0).toUpperCase() + rest.slice(1);
    return `REC ${capitalizedRest}`;
  }
  
  return trimmed;
}

function normalizeTabContext(raw: string, category?: string): "IT" | "Furniture" | "Misc" {
  if (category) {
    const cat = category.trim().toLowerCase();
    const furnitureCats = ["chair", "table", "sofa set", "sofa", "tea table", "rack", "almarah", "almirah", "visitor chair", "cupboard", "desk", "executive table", "bench", "stool", "cabinet"];
    if (furnitureCats.some(f => cat.includes(f))) {
      return "Furniture";
    }
    const miscCats = ["generator", "camera", "water dispenser", "water dispensar", "led", "fridge", "refrigerator", "ac", "air conditioner", "ups", "vehicle", "motorcycle", "motor cycle", "bike", "fan", "cooler"];
    if (miscCats.some(m => cat.includes(m))) {
      return "Misc";
    }
    const itCats = ["computer", "laptop", "printer", "scanner", "photo state", "photostat", "monitor", "mointor", "biometric", "cpu", "mouse", "keyboard"];
    if (itCats.some(i => cat.includes(i))) {
      return "IT";
    }
  }

  const trimmed = (raw || "").trim().toLowerCase();
  if (trimmed === "furniture" || trimmed === "furniture assets" || trimmed.startsWith("furn")) {
    return "Furniture";
  }
  if (trimmed === "misc" || trimmed === "miscellaneous" || trimmed.startsWith("misc")) {
    return "Misc";
  }
  if (trimmed === "it" || trimmed === "it equipment" || trimmed === "it-equipment" || trimmed.startsWith("it")) {
    return "IT";
  }

  return "IT";
}

export default function RegistryLedger({
  currentTab,
  scopeData,
  allLocationData = [],
  currentNodeLocation,
  isWriteAllowed,
  isSuperAdmin = false,
  isLightMode = false,
  onItemCommit,
  onItemDelete,
  onItemDeleteAll,
  onTabChange,
  onItemsBulkCommit
}: RegistryLedgerProps) {
  // Input fields state
  const [assetNodeLocation, setAssetNodeLocation] = useState<string>(currentNodeLocation);
  const [assetName, setAssetName] = useState<string>("");
  const [assetSerial, setAssetSerial] = useState<string>("");
  const [assetModel, setAssetModel] = useState<string>("");
  const [assetCategory, setAssetCategory] = useState<string>("");
  const [assetQuantity, setAssetQuantity] = useState<string>("1");
  const [assetReceived, setAssetReceived] = useState<string>("");
  const [assetDate, setAssetDate] = useState<string>("");
  const [workingStatus, setWorkingStatus] = useState<string>("");
  const [workingSubStatus, setWorkingSubStatus] = useState<string>("");
  const [issueTo, setIssueTo] = useState<string>("");
  const [designation, setDesignation] = useState<string>("");
  const [issuedDate, setIssuedDate] = useState<string>("");
  const [nonWorkingSubStatus, setNonWorkingSubStatus] = useState<string>("");
  const [remarks, setRemarks] = useState<string>("");

  // Edit states
  const [editingItemId, setEditingItemId] = useState<number | null>(null);
  const [editingOriginalSerial, setEditingOriginalSerial] = useState<string | null>(null);
  const editingItemIdRef = React.useRef<number | null>(null);

  // Sync assetNodeLocation with currentNodeLocation when switching locations if not editing
  useEffect(() => {
    if (!editingItemId) {
      setAssetNodeLocation(currentNodeLocation);
    }
  }, [currentNodeLocation, editingItemId]);
  
  // Gifter / Donor states
  const [gifterName, setGifterName] = useState<string>("");
  const [gifterDesignation, setGifterDesignation] = useState<string>("");

  // Non-blocking confirmation states to circumvent iframe sandbox window.confirm restrictions
  const [confirmDeleteId, setConfirmDeleteId] = useState<number | null>(null);
  const [confirmClearAll, setConfirmClearAll] = useState<boolean>(false);

  // Auto-reset delete confirmation after 4 seconds of inactivity
  useEffect(() => {
    if (confirmDeleteId !== null) {
      const timer = setTimeout(() => {
        setConfirmDeleteId(null);
      }, 4000);
      return () => clearTimeout(timer);
    }
  }, [confirmDeleteId]);

  // Auto-reset clear all confirmation after 4 seconds of inactivity
  useEffect(() => {
    if (confirmClearAll) {
      const timer = setTimeout(() => {
        setConfirmClearAll(false);
      }, 4000);
      return () => clearTimeout(timer);
    }
  }, [confirmClearAll]);

  // Print & Save Success Dialog States
  const [saveSuccessMsg, setSaveSuccessMsg] = useState<string | null>(null);
  const [showPrintPreviewModal, setShowPrintPreviewModal] = useState<boolean>(false);
  const [isSavingPdf, setIsSavingPdf] = useState<boolean>(false);
  const [downloadModalData, setDownloadModalData] = useState<{ isOpen: boolean; html: string }>({ isOpen: false, html: "" });
  const [copiedHtml, setCopiedHtml] = useState<boolean>(false);
  const [isCompiling, setIsCompiling] = useState<boolean>(false);
  const [isCookieBlocked, setIsCookieBlocked] = useState<boolean>(false);

  const handleSavePdf = async () => {
    setIsSavingPdf(true);
    try {
      const cleanLoc = currentNodeLocation.replace(/[^a-zA-Z0-9_-]/g, '_');
      await saveElementAsPDF("printableLedgerDocumentContent", `ECP_Ledger_${cleanLoc}_${currentTab}.pdf`);
    } finally {
      setIsSavingPdf(false);
    }
  };

  // Keyboard shortcut (Escape key) to close print preview or download modal
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setShowPrintPreviewModal(false);
        setDownloadModalData({ isOpen: false, html: "" });
      }
    };
    if (showPrintPreviewModal || downloadModalData.isOpen) {
      window.addEventListener("keydown", handleKeyDown);
    }
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [showPrintPreviewModal, downloadModalData.isOpen]);

  // Category sorting state
  const [categorySortOrder, setCategorySortOrder] = useState<"none" | "asc" | "desc">("none");

  // Get categories configured per tab
  const categoriesMap = {
    IT: ["Computer", "Computer Monitor", "Laptop", "Printer", "Scanner", "Photo state", "Biometric Device", "others"],
    Furniture: ["chair", "table", "sofa set", "tea table", "rack", "almarah", "visitor chair", "other"],
    Misc: ["Generator", "camera", "AC", "water dispenser", "UPS", "LED", "Fridge", "Vehicle", "Motorcycle", "others"]
  };
  const activeCategories = categoriesMap[currentTab];

  // Helper to sum item quantities robustly
  const getSumQty = (items: InventoryItem[]) => {
    return items.reduce((sum, item) => sum + (Number(item.quantity) > 0 ? Number(item.quantity) : 1), 0);
  };

  // Scope data filtering by timestampId (supporting same serial numbers across distinct items)
  const deduplicatedScopeData = React.useMemo(() => {
    const list = scopeData || [];
    const seenIds = new Set<number>();

    return list.filter(item => {
      if (!item) return false;

      const numId = Number(item.timestampId);
      if (numId && seenIds.has(numId)) {
        return false;
      }
      if (numId) {
        seenIds.add(numId);
      }

      return true;
    });
  }, [scopeData]);

  // Category Filter state
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string>("All");

  // Pagination & Display limit states (Default: 50 records)
  const [pageSize, setPageSize] = useState<number | "All">(50);
  const [currentPage, setCurrentPage] = useState<number>(1);

  // Restricted category options strictly matching current tab
  const categoryFilterOptions = React.useMemo(() => {
    return activeCategories || [];
  }, [activeCategories]);

  // Filter deduplicatedScopeData based on selected category filter
  const filteredScopeData = React.useMemo(() => {
    let list = deduplicatedScopeData || [];
    if (selectedCategoryFilter !== "All" && selectedCategoryFilter !== "") {
      list = list.filter(item => (item.category || "").trim().toLowerCase() === selectedCategoryFilter.trim().toLowerCase());
    }
    return list;
  }, [deduplicatedScopeData, selectedCategoryFilter]);

  // Sorted scope data based on Category
  const sortedScopeData = React.useMemo(() => {
    const list = filteredScopeData || [];
    if (categorySortOrder === "none") return list;
    return [...list].sort((a, b) => {
      const catA = (a?.category || "").toLowerCase();
      const catB = (b?.category || "").toLowerCase();
      if (catA < catB) return categorySortOrder === "asc" ? -1 : 1;
      if (catA > catB) return categorySortOrder === "asc" ? 1 : -1;
      return 0;
    });
  }, [filteredScopeData, categorySortOrder]);

  // Reset category filter when switching tabs or node location
  useEffect(() => {
    setSelectedCategoryFilter("All");
  }, [currentTab, currentNodeLocation]);

  // Reset current page when tab, category filter, dataset size, category sort order, or page size changes
  useEffect(() => {
    setCurrentPage(1);
  }, [currentTab, selectedCategoryFilter, categorySortOrder, scopeData?.length, pageSize]);

  const totalRecords = sortedScopeData.length;
  const totalPages = pageSize === "All" ? 1 : Math.max(1, Math.ceil(totalRecords / (pageSize as number)));

  const paginatedData = React.useMemo(() => {
    if (pageSize === "All") return sortedScopeData;
    const size = typeof pageSize === "number" ? pageSize : 50;
    const startIndex = (currentPage - 1) * size;
    return sortedScopeData.slice(startIndex, startIndex + size);
  }, [sortedScopeData, currentPage, pageSize]);

  // Auto dismiss success notification after 3 seconds
  useEffect(() => {
    if (saveSuccessMsg) {
      const timer = setTimeout(() => {
        setSaveSuccessMsg(null);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [saveSuccessMsg]);

  const getDynamicPlaceholders = () => {
    const cat = (assetCategory || "").toLowerCase();

    // Default values:
    let assetNamePlaceholder = "e.g. Asset name or brand";
    let assetSerialPlaceholder = "e.g. S/N CNB123456";
    let assetModelPlaceholder = "e.g. Specs / Model details";

    if (cat === "laptop" || cat === "computer" || (!cat && currentTab === "IT")) {
      assetNamePlaceholder = "e.g. HP ProBook, Dell Latitude, Lenovo ThinkPad";
      assetSerialPlaceholder = "e.g. S/N CNB123456";
      assetModelPlaceholder = "e.g. Core i7, 16GB RAM, 512GB SSD";
    } else if (cat.includes("monitor")) {
      assetNamePlaceholder = "e.g. HP 24\" IPS LED Monitor, Dell Display";
      assetSerialPlaceholder = "e.g. S/N MNT987654";
      assetModelPlaceholder = "e.g. 1080p Full HD, HDMI / VGA";
    } else if (cat.includes("biometric") || cat.includes("bio")) {
      assetNamePlaceholder = "e.g. ZKTeco Biometric Terminal, Anviz Scanner";
      assetSerialPlaceholder = "e.g. S/N BIO123456";
      assetModelPlaceholder = "e.g. Fingerprint & Face Recognition, IP Network";
    } else if (cat === "printer") {
      assetNamePlaceholder = "e.g. HP LaserJet, Canon Pixma, Epson L3110";
      assetSerialPlaceholder = "e.g. S/N PRNT123456";
      assetModelPlaceholder = "e.g. Duplex Printing, 40ppm, USB/Wifi";
    } else if (cat === "scanner") {
      assetNamePlaceholder = "e.g. Fujitsu Image Scanner, HP ScanJet";
      assetSerialPlaceholder = "e.g. S/N SCN789101";
      assetModelPlaceholder = "e.g. ADF, 600 dpi, Duplex Scanner";
    } else if (cat === "photo state") {
      assetNamePlaceholder = "e.g. Toshiba e-Studio, Ricoh Aficio, Canon imageRUNNER";
      assetSerialPlaceholder = "e.g. S/N COP987654";
      assetModelPlaceholder = "e.g. Heavy Duty, A3/A4 Copy, Network Printing";
    } else if (cat === "chair" || cat === "visitor chair") {
      assetNamePlaceholder = "e.g. Executive Revolving Chair, Steel Office Chair";
      assetSerialPlaceholder = "e.g. Stock Register P.No ECP-CH-023";
      assetModelPlaceholder = "e.g. Leatherette Cushion, High Back with Armrests";
    } else if (cat === "table" || cat === "tea table" || (!cat && currentTab === "Furniture")) {
      assetNamePlaceholder = "e.g. Wooden Executive Desk, Office Side Table";
      assetSerialPlaceholder = "e.g. Stock Register P.No ECP-TB-105";
      assetModelPlaceholder = "e.g. 5x3 Feet, 3 Drawers, Oak Wood Finish";
    } else if (cat === "sofa set") {
      assetNamePlaceholder = "e.g. 3-Seater Leather Sofa, Standard Office Sofa";
      assetSerialPlaceholder = "e.g. Stock Register P.No ECP-SF-045";
      assetModelPlaceholder = "e.g. Premium Velvet, Foam Cushioning";
    } else if (cat === "rack") {
      assetNamePlaceholder = "e.g. Wooden Book Rack, Metal File Shelving Rack";
      assetSerialPlaceholder = "e.g. Stock Register P.No ECP-RC-012";
      assetModelPlaceholder = "e.g. 5-Tier, Heavy Duty Steel, Adjustable Shelves";
    } else if (cat === "almarah") {
      assetNamePlaceholder = "e.g. Steel Almarah, Wooden File Cabinet";
      assetSerialPlaceholder = "e.g. Stock Register P.No ECP-AL-089";
      assetModelPlaceholder = "e.g. 4-Shelf Glass Door, Security Lock";
    } else if (cat === "generator" || (!cat && currentTab === "Misc")) {
      assetNamePlaceholder = "e.g. Honda Generator, Perkins Diesel Generator";
      assetSerialPlaceholder = "e.g. S/N GEN654321";
      assetModelPlaceholder = "e.g. 5kVA, Key Start, Petrol/LPG Dual Fuel";
    } else if (cat === "ac") {
      assetNamePlaceholder = "e.g. Gree 1.5 Ton Inverter AC, Haier Split AC";
      assetSerialPlaceholder = "e.g. S/N AC1234567";
      assetModelPlaceholder = "e.g. Heat & Cool Inverter, R410a Gas";
    } else if (cat === "ups") {
      assetNamePlaceholder = "e.g. Homage 1000VA UPS, EcoStar Inverter";
      assetSerialPlaceholder = "e.g. S/N UPS887766";
      assetModelPlaceholder = "e.g. 1.2kW Pure Sine Wave, Dual Battery Support";
    } else if (cat === "camera") {
      assetNamePlaceholder = "e.g. Sony Alpha DSLR, Hikvision Dome CCTV";
      assetSerialPlaceholder = "e.g. S/N CAM456123";
      assetModelPlaceholder = "e.g. 24.2 MP, 4K Video / 5MP Night Vision IP Camera";
    } else if (cat === "water dispenser") {
      assetNamePlaceholder = "e.g. Homage Water Dispenser, Orient Water Dispenser";
      assetSerialPlaceholder = "e.g. Stock Register P.No ECP-WD-076";
      assetModelPlaceholder = "e.g. 3-Tap (Hot, Cold, Normal), Cabinet Fridge Space";
    } else if (cat === "led") {
      assetNamePlaceholder = "e.g. Samsung 55\" Smart LED, TCL Smart TV";
      assetSerialPlaceholder = "e.g. S/N LED112233";
      assetModelPlaceholder = "e.g. 4K UHD, HDR10+, 3x HDMI Ports";
    } else if (cat === "fridge") {
      assetNamePlaceholder = "e.g. Dawlance Refrigerator, Haier Inverter Fridge";
      assetSerialPlaceholder = "e.g. S/N FRG556677";
      assetModelPlaceholder = "e.g. 15 cu ft, Double Door, Direct Cool";
    } else if (cat === "vehicle") {
      assetNamePlaceholder = "e.g. Toyota Corolla Sedan, Suzuki Cultus Car";
      assetSerialPlaceholder = "e.g. Reg No LEG-1234 / Chassis S/N VHL8877";
      assetModelPlaceholder = "e.g. 1.6L Automatic, White Color, Model 2022";
    } else if (cat === "motorcycle" || cat === "motor cycle") {
      assetNamePlaceholder = "e.g. Honda 125 Motorcycle, Suzuki 150 Bike";
      assetSerialPlaceholder = "e.g. Reg No KHI-7890 / Engine S/N MC4455";
      assetModelPlaceholder = "e.g. 125cc 4-Stroke, Red Color, Model 2023";
    }

    return {
      name: assetNamePlaceholder,
      serial: assetSerialPlaceholder,
      model: assetModelPlaceholder
    };
  };

  // Reset category whenever tab switches unless an item is being actively loaded/edited
  useEffect(() => {
    if (!editingItemId && !editingItemIdRef.current) {
      clearForm();
    }
  }, [currentTab]);

  const clearForm = () => {
    editingItemIdRef.current = null;
    setEditingItemId(null);
    setEditingOriginalSerial(null);
    setAssetNodeLocation(currentNodeLocation);
    setAssetName("");
    setAssetSerial("");
    setAssetModel("");
    setAssetCategory("");
    setAssetQuantity("1");
    setAssetReceived("");
    setAssetDate("");
    setWorkingStatus("");
    setWorkingSubStatus("");
    setIssueTo("");
    setDesignation("");
    setIssuedDate("");
    setNonWorkingSubStatus("");
    setRemarks("");
    setGifterName("");
    setGifterDesignation("");
  };

  const handleSave = async (
    e: React.FormEvent,
    forceIsNew?: boolean,
    overrideEditingId?: number | null,
    overrideOriginalSerial?: string | null
  ) => {
    e.preventDefault();
    if (!assetName.trim() || !assetCategory || !workingStatus) {
      alert("Validation Fault: Primary parameters values (Name, Category, Status) cannot be left blank.");
      return;
    }

    let finalRemarks = remarks.trim() || "";
    if (assetReceived === "Gifted") {
      finalRemarks = `Donor: ${gifterName.trim()}, Designation: ${gifterDesignation.trim()}` + (remarks.trim() ? ` | ${remarks.trim()}` : "");
    }

    const targetEditingId = editingItemIdRef.current !== undefined ? editingItemIdRef.current : editingItemId;
    const effectiveEditingId = forceIsNew ? null : (overrideEditingId !== undefined ? overrideEditingId : targetEditingId);
    const effectiveOriginalSerial = forceIsNew ? null : (overrideOriginalSerial !== undefined ? overrideOriginalSerial : editingOriginalSerial);
    const isEditingRecord = Boolean(effectiveEditingId);

    let targetTab = currentTab;
    const catLower = (assetCategory || "").toLowerCase().trim();
    const miscCats = ["generator", "camera", "ac", "water dispenser", "water dispensar", "ups", "led", "fridge", "refrigerator", "vehicle", "motorcycle", "motor cycle", "bike"];
    const furnCats = ["chair", "table", "sofa", "tea table", "rack", "almarah", "almirah", "visitor chair", "cupboard", "desk", "executive table"];
    const itCats = ["computer", "laptop", "printer", "scanner", "photostat", "monitor", "mointor", "biometric"];

    if (miscCats.some(m => catLower.includes(m))) {
      targetTab = "Misc";
    } else if (furnCats.some(f => catLower.includes(f))) {
      targetTab = "Furniture";
    } else if (itCats.some(i => catLower.includes(i))) {
      targetTab = "IT";
    }

    const payload: Omit<InventoryItem, 'timestampId'> & { timestampId?: number; originalSerial?: string | null; isEditing?: boolean } = {
      timestampId: effectiveEditingId ? Number(effectiveEditingId) : undefined,
      isEditing: isEditingRecord,
      originalSerial: effectiveOriginalSerial,
      nodeLocation: assetNodeLocation || currentNodeLocation,
      tabContext: targetTab,
      name: assetName.trim(),
      serial: assetSerial.trim() || null,
      model: assetModel.trim() || null,
      category: assetCategory,
      quantity: assetQuantity ? (parseInt(assetQuantity, 10) || 1) : 1,
      receivedFrom: assetReceived || null,
      date: assetDate || null,
      workingStatus: workingStatus as "Working" | "Non-Working",
      workingSubStatus: workingStatus === "Working" ? (workingSubStatus as "Issued" | "In-stock" || null) : null,
      issueTo: (workingStatus === "Working" && workingSubStatus === "Issued") ? issueTo.trim() || null : null,
      designation: (workingStatus === "Working" && workingSubStatus === "Issued") ? designation.trim() || null : null,
      issuedDate: (workingStatus === "Working" && workingSubStatus === "Issued") ? issuedDate || null : null,
      nonWorkingSubStatus: workingStatus === "Non-Working" ? (nonWorkingSubStatus as "Needs to repair" | "Ready for condemnation" || null) : null,
      remarks: finalRemarks || null
    };

    try {
      await onItemCommit(payload);
      clearForm();
      if (targetTab !== currentTab && onTabChange) {
        onTabChange(targetTab);
      }
      setSaveSuccessMsg(isEditingRecord ? "Record updated successfully" : "The record has been submitted");
    } catch (err: any) {
      alert(err.message || "Failed to commit record.");
    }
  };

  const handleEditInitiate = (item: InventoryItem) => {
    if (!isWriteAllowed) return;
    
    const numId = Number(item.timestampId);
    editingItemIdRef.current = numId;

    // Switch tabs first if category is of a different tab context
    if (item.tabContext && item.tabContext !== currentTab && onTabChange) {
      onTabChange(item.tabContext as "IT" | "Furniture" | "Misc");
    }

    setEditingItemId(numId);
    setEditingOriginalSerial(item.serial || null);
    setAssetNodeLocation(item.nodeLocation || currentNodeLocation);
    setAssetName(item.name || "");
    setAssetSerial(item.serial || "");
    setAssetModel(item.model || "");
    setAssetCategory(item.category || "");
    setAssetQuantity(item.quantity !== undefined && item.quantity !== null ? String(item.quantity) : "1");
    setAssetReceived(item.receivedFrom || "");
    setAssetDate(item.date || "");
    setWorkingStatus(item.workingStatus || "");
    setWorkingSubStatus(item.workingSubStatus || "");
    setIssueTo(item.issueTo || "");
    setDesignation(item.designation || "");
    setIssuedDate(item.issuedDate || "");
    setNonWorkingSubStatus(item.nonWorkingSubStatus || "");

    if (item.receivedFrom === "Gifted" && item.remarks) {
      const donorMatch = item.remarks.match(/Donor:\s*([^,|]+)/);
      const desigMatch = item.remarks.match(/Designation:\s*([^|]+)/);
      const parts = item.remarks.split(/\s*\|\s*/);
      const otherRemarks = parts.length > 1 ? parts.slice(1).join(" | ") : "";
      
      setGifterName(donorMatch ? donorMatch[1].trim() : "");
      setGifterDesignation(desigMatch ? desigMatch[1].trim() : "");
      setRemarks(otherRemarks.trim());
    } else {
      setGifterName("");
      setGifterDesignation("");
      setRemarks(item.remarks || "");
    }

    // Scroll smoothly up to input form
    document.getElementById("registryInputsFormBlock")?.scrollIntoView({ behavior: 'smooth' });
  };

  // Export scope data to Excel matching database column schemas in user-friendly format
  const handleExportToExcel = () => {
    if (scopeData.length === 0) {
      alert("Export buffer contains empty records.");
      return;
    }

    const formattedData = scopeData.map((item, idx) => ({
      "S.No": idx + 1,
      "Asset ID": item.id || `${currentTab === "IT" ? "IT" : currentTab === "Furniture" ? "Fur" : "Mis"}${String(idx + 1).padStart(4, '0')}`,
      "Asset Name": item.name,
      "Serial No": item.serial || "",
      "Model": item.model || "",
      "Category": item.category || "",
      "Quantity": item.quantity || 1,
      "Received From": item.receivedFrom || "",
      "Receiving Date": item.date || "",
      "Working Status": item.workingStatus,
      "Working Type": item.workingSubStatus || "",
      "Issue To": item.issueTo || "",
      "Designation": item.designation || "",
      "Issued Date": item.issuedDate || "",
      "Condition Reason": item.nonWorkingSubStatus || "",
      "Remarks": item.remarks || ""
    }));

    const workbook = XLSX.utils.book_new();
    const worksheet = XLSX.utils.json_to_sheet(formattedData);
    XLSX.utils.book_append_sheet(workbook, worksheet, "Inventory Ledger");
    const safeNodeName = currentNodeLocation.replace(/\s+/g, '_');
    XLSX.writeFile(workbook, `Inventory_${safeNodeName}_${currentTab}.xlsx`);
  };

  // Helper to parse dates from Excel (handles string, Date object, or numeric timestamp)
  const parseExcelDate = (val: any): string | null => {
    if (!val) return null;
    if (val instanceof Date) {
      try {
        if (!isNaN(val.getTime())) {
          return val.toISOString().split('T')[0];
        }
      } catch (e) { return null; }
    }
    if (typeof val === 'number') {
      const dateObj = new Date(Math.round((val - 25569) * 86400 * 1000));
      if (!isNaN(dateObj.getTime())) {
        return dateObj.toISOString().split('T')[0];
      }
    }
    const str = String(val).trim();
    if (!str || str === "-" || str === "--" || str.toLowerCase() === "n/a" || str.toLowerCase() === "na" || str.toLowerCase() === "nil" || str.toLowerCase() === "none" || str.toLowerCase() === "null") return null;
    try {
      const d = new Date(str);
      if (!isNaN(d.getTime())) {
        return d.toISOString().split('T')[0];
      }
    } catch (e) {}
    return null; // Return null if not a valid ISO date, avoiding Postgres DATE column syntax errors
  };

  // Import from Excel Sheet matching columns and syncing to Supabase in a single transaction
  const handleImportExcel = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const binary = e.target?.result;
        const workbook = XLSX.read(binary, { type: 'binary', cellDates: true });

        const itemsToInsert: InventoryItem[] = [];
        const baseImportBatchTs = Date.now();

        const isGenericSerial = (s?: string | null): boolean => {
          if (s === undefined || s === null) return true;
          const clean = String(s).trim().toLowerCase();
          return (
            !clean ||
            clean === "-" ||
            clean === "--" ||
            clean === "---" ||
            clean === "n/a" ||
            clean === "na" ||
            clean === "nil" ||
            clean === "none" ||
            clean === "not available" ||
            clean === "no serial" ||
            clean === "null"
          );
        };

        const allExistingItems = (allLocationData && allLocationData.length > 0) ? allLocationData : scopeData;

        // Process ALL sheets in the Excel workbook to ensure no sheets/rows are missed
        for (const sheetName of workbook.SheetNames) {
          const sheet = workbook.Sheets[sheetName];
          if (!sheet) continue;

          // Convert sheet to 2D matrix to locate actual header row if offset by title or empty rows
          const rows2D = XLSX.utils.sheet_to_json<any[]>(sheet, { header: 1, raw: false, defval: "" });
          if (!rows2D || rows2D.length === 0) continue;

          // Scan first 15 rows to find the FIRST valid header row (first row with 2+ populated cells and keyword matches)
          let headerRowIdx = -1;

          const headerKeywords = [
            "name", "asset", "serial", "particulars", "item", "equipment", "model",
            "status", "category", "date", "issue", "sn", "description", "qty",
            "quantity", "s.no", "sr.no", "p.no", "remarks", "location", "make", "type", "tag", "hardware", "title",
            "printer", "printers", "working", "substatus", "issued", "condition", "specification", "specs"
          ];

          for (let r = 0; r < Math.min(15, rows2D.length); r++) {
            const rowArr = rows2D[r];
            if (!Array.isArray(rowArr)) continue;
            
            const nonBlankCells = rowArr.filter(cell => String(cell || "").trim().length > 0);
            if (nonBlankCells.length === 0) continue;

            let keywordMatchCount = 0;
            nonBlankCells.forEach(cell => {
              const strCell = String(cell || "").toLowerCase().trim();
              if (headerKeywords.some(kw => strCell === kw || strCell.includes(kw))) {
                keywordMatchCount++;
              }
            });

            // If a row has 2+ non-blank cells AND at least 1 keyword match, it's the header row!
            if (keywordMatchCount >= 1 && nonBlankCells.length >= 2) {
              headerRowIdx = r;
              break; // STOP searching immediately! First matching header row is the TRUE header!
            }
          }

          if (headerRowIdx === -1) {
            // Fallback: find first non-empty row
            for (let r = 0; r < Math.min(15, rows2D.length); r++) {
              const rowArr = rows2D[r];
              if (Array.isArray(rowArr) && rowArr.some(cell => String(cell || "").trim().length > 0)) {
                headerRowIdx = r;
                break;
              }
            }
          }

          let dataRows: any[] = [];
          if (headerRowIdx >= 0) {
            const range = XLSX.utils.decode_range(sheet['!ref'] || 'A1');
            range.s.r = headerRowIdx;
            const updatedRef = XLSX.utils.encode_range(range);
            const subSheet = { ...sheet, '!ref': updatedRef };
            dataRows = XLSX.utils.sheet_to_json<any>(subSheet, { defval: "" });
          } else {
            dataRows = XLSX.utils.sheet_to_json<any>(sheet, { defval: "" });
          }

          for (let idx = 0; idx < dataRows.length; idx++) {
            const row = dataRows[idx];
            if (!row || typeof row !== 'object') continue;

            const values = Object.values(row).map(v => String(v || "").trim());
            const hasData = values.some(v => v.length > 0);
            if (!hasData) continue;

            // Skip title/summary/total rows
            const rowSummaryCheck = values.join(" ").toLowerCase();
            if (
              rowSummaryCheck.startsWith("total") ||
              rowSummaryCheck.startsWith("grand total") ||
              rowSummaryCheck.startsWith("count:") ||
              rowSummaryCheck.startsWith("summary")
            ) {
              continue;
            }

            // Case-insensitive flexible key getter
            const getValueByKeys = (possibleKeys: string[]) => {
              for (const pk of possibleKeys) {
                if (row[pk] !== undefined && row[pk] !== null && String(row[pk]).trim() !== "") {
                  return String(row[pk]).trim();
                }
              }
              const rowKeys = Object.keys(row);
              for (const pk of possibleKeys) {
                const targetClean = pk.toLowerCase().replace(/[^a-z0-9]/g, "");
                const foundKey = rowKeys.find(rk => rk.toLowerCase().replace(/[^a-z0-9]/g, "") === targetClean);
                if (foundKey && row[foundKey] !== undefined && row[foundKey] !== null && String(row[foundKey]).trim() !== "") {
                  return String(row[foundKey]).trim();
                }
              }
              return "";
            };

            // Asset / Equipment Name lookup
            let rawName = getValueByKeys([
              "Asset Name", "assetName", "Asset", "asset",
              "Name", "name", "Item Name", "itemName", "Item", "item",
              "Equipment Name", "equipmentName", "Equipment", "equipment",
              "Particulars", "particulars", "Description", "description", "Asset Description",
              "Device", "device", "Device Name", "Title", "title",
              "Asset Subtype", "Category", "category", "Hardware", "Product", "Nomenclature", "Make",
              "Printer", "Printers", "Printer Name", "Printer Model", "Equipment/Item", "Particulars/Description"
            ]);

            if (!rawName) {
              // Try finding any non-empty text column
              const rowEntries = Object.entries(row);
              for (const [k, v] of rowEntries) {
                const kClean = k.toLowerCase().replace(/[^a-z0-9]/g, "");
                const vStr = String(v || "").trim();
                if (
                  vStr &&
                  !kClean.includes("sno") &&
                  !kClean.includes("serial") &&
                  !kClean.includes("date") &&
                  !kClean.includes("qty") &&
                  !kClean.includes("status") &&
                  vStr.length > 1
                ) {
                  rawName = vStr;
                  break;
                }
              }
            }

            const nameValue = rawName || `Equipment Item ${itemsToInsert.length + 1}`;

            // Serial lookup across common headers and fallbacks
            let rawSerialVal = getValueByKeys([
              "Serial / Stock Reg. P.No/ S.NO.", "Serial No", "Serial NO", "Serial No.", "Serial no",
              "Serial/Tag Number", "Serial", "serial", "serialNo", "Serial_No",
              "Serial Number", "S/N", "Stock Reg P No", "Stock Reg. P.No",
              "P.No", "Reg No", "Tag No", "Tag Number", "Sr. No", "Sr No", "Sr.No", "S.No", "S.No.", "S No", "Serial #"
            ]);

            if (!rawSerialVal) {
              const rowKeys = Object.keys(row);
              const foundKey = rowKeys.find(k => {
                const kClean = k.toLowerCase().replace(/[^a-z0-9]/g, '');
                return (
                  kClean.includes("serial") ||
                  kClean === "sn" ||
                  kClean.includes("serialno") ||
                  kClean.includes("tagno") ||
                  kClean.includes("pno") ||
                  kClean.includes("regno")
                );
              });
              if (foundKey) {
                rawSerialVal = String(row[foundKey] || "").trim();
              }
            }

            const rowSerialRaw = String(rawSerialVal || "").trim();
            const rowSerial = isGenericSerial(rowSerialRaw) ? null : rowSerialRaw;

            // Dates
            const rawDateStr = getValueByKeys([
              "Receiving Date", "receiving_date", "receivingDate",
              "Date", "date", "Date Logged", "Date Received"
            ]);
            const parsedDate = parseExcelDate(rawDateStr || row["Receiving Date"] || row["Date"]);

            const rawIssuedDateStr = getValueByKeys([
              "Issued Date", "issuedDate", "Assignment Date", "Issue Date"
            ]);
            const parsedIssuedDate = parseExcelDate(rawIssuedDateStr || row["Issued Date"]);

            // Status
            const rawStatus = getValueByKeys([
              "Working Status", "workingStatus", "Status", "status",
              "Condition", "condition", "Working / Non-Working", "Working/Non-Working",
              "Equipment Status", "Equipment Condition", "State"
            ]);

            const rawNonWorkingSub = getValueByKeys([
              "Condition Reason", "nonWorkingSubStatus", "Non Working Sub Status",
              "Non-Working Sub Status", "Non Working Reason", "Reason",
              "Fault", "Defect", "Sub Status", "Sub-Status"
            ]);

            const rawRemarks = getValueByKeys(["Remarks", "remarks", "Notes", "Comments"]);

            const statusCombinedStr = (rawStatus + " " + rawNonWorkingSub + " " + rawRemarks).toLowerCase();

            const isNonWorking =
              statusCombinedStr.includes("non") ||
              statusCombinedStr.includes("not working") ||
              statusCombinedStr.includes("fault") ||
              statusCombinedStr.includes("defect") ||
              statusCombinedStr.includes("repair") ||
              statusCombinedStr.includes("condemn") ||
              statusCombinedStr.includes("damage") ||
              statusCombinedStr.includes("dead") ||
              statusCombinedStr.includes("broken") ||
              statusCombinedStr.includes("unserviceable") ||
              statusCombinedStr.includes("scrap") ||
              statusCombinedStr.includes("bad") ||
              statusCombinedStr.includes("out of order");

            const normWorkingStatus: "Working" | "Non-Working" = isNonWorking ? "Non-Working" : "Working";

            let normWorkingSubStatus: "Issued" | "In-stock" | null = null;
            if (normWorkingStatus === "Working") {
              const rawWorkingSub = getValueByKeys(["Working Type", "workingSubStatus", "Allocation Type", "Stock Status", "Sub Status", "Sub-Status"]);
              const issueToVal = getValueByKeys(["Issue To", "issueTo", "Issued To", "Assigned To", "User", "Employee"]);
              const subStr = rawWorkingSub.toLowerCase();

              if (subStr.includes("issued") || subStr.includes("assign") || Boolean(issueToVal)) {
                normWorkingSubStatus = "Issued";
              } else {
                normWorkingSubStatus = "In-stock";
              }
            }

            let normNonWorkingSubStatus: "Needs to repair" | "Ready for Condemnation" | "Ready for condemnation" | null = null;
            if (normWorkingStatus === "Non-Working") {
              const nonWorkStr = (rawNonWorkingSub + " " + rawStatus + " " + rawRemarks).toLowerCase();
              if (
                nonWorkStr.includes("condemn") ||
                nonWorkStr.includes("ready") ||
                nonWorkStr.includes("scrap") ||
                nonWorkStr.includes("unserviceable") ||
                nonWorkStr.includes("disposal") ||
                nonWorkStr.includes("write off") ||
                nonWorkStr.includes("written off")
              ) {
                normNonWorkingSubStatus = "Ready for Condemnation";
              } else {
                normNonWorkingSubStatus = "Needs to repair";
              }
            }

            const rawCatValue = getValueByKeys(["Category", "category", "Asset Subtype", "Asset Category", "Item Category", "Type", "Equipment Type"]);
            const rawModel = getValueByKeys(["Model", "model", "Model Specifications", "Model No", "Model Number", "Specification", "Specs"]);
            const rawQty = getValueByKeys(["Quantity", "quantity", "Qty", "qty"]) || "1";
            const parsedQty = parseInt(rawQty, 10);

            // Infer category if missing or generic
            let finalCategory = rawCatValue ? rawCatValue.trim() : "";
            const combinedText = `${nameValue} ${finalCategory} ${rawModel || ""}`.toLowerCase();

            if (!finalCategory || finalCategory.toLowerCase() === "others" || finalCategory.toLowerCase() === "other") {
              if (combinedText.includes("chair")) finalCategory = "chair";
              else if (combinedText.includes("table") || combinedText.includes("desk")) finalCategory = "table";
              else if (combinedText.includes("sofa")) finalCategory = "sofa set";
              else if (combinedText.includes("rack") || combinedText.includes("shelf")) finalCategory = "rack";
              else if (combinedText.includes("almarah") || combinedText.includes("almirah") || combinedText.includes("cabinet")) finalCategory = "almarah";
              else if (combinedText.includes("generator")) finalCategory = "Generator";
              else if (combinedText.includes("camera")) finalCategory = "camera";
              else if (combinedText.includes("ac") || combinedText.includes("air conditioner")) finalCategory = "AC";
              else if (combinedText.includes("water dispenser")) finalCategory = "water dispenser";
              else if (combinedText.includes("ups") || combinedText.includes("inverter")) finalCategory = "UPS";
              else if (combinedText.includes("led") || combinedText.includes("tv")) finalCategory = "LED";
              else if (combinedText.includes("fridge") || combinedText.includes("refrigerator")) finalCategory = "Fridge";
              else if (combinedText.includes("vehicle") || combinedText.includes("car")) finalCategory = "Vehicle";
              else if (combinedText.includes("motorcycle") || combinedText.includes("bike")) finalCategory = "Motorcycle";
              else if (combinedText.includes("computer") || combinedText.includes("pc") || combinedText.includes("cpu")) finalCategory = "Computer";
              else if (combinedText.includes("laptop")) finalCategory = "Laptop";
              else if (combinedText.includes("printer")) finalCategory = "Printer";
              else if (combinedText.includes("scanner")) finalCategory = "Scanner";
              else if (combinedText.includes("photostat") || combinedText.includes("copier") || combinedText.includes("photo state")) finalCategory = "Photo state";
              else if (combinedText.includes("monitor")) finalCategory = "Computer Monitor";
              else if (combinedText.includes("biometric")) finalCategory = "Biometric Device";
              else finalCategory = activeCategories[0] || "others";
            }

            // Read location from row if present, otherwise default to currentNodeLocation
            const rawRowLoc = getValueByKeys(["Location", "location", "Office", "office", "Station", "station", "Node Location", "nodeLocation", "District", "district"]);
            const itemNodeLocation = rawRowLoc ? normalizeNodeLocation(rawRowLoc) : currentNodeLocation;

            // Route tabContext reliably based on explicit column and category keywords
            const explicitTab = getValueByKeys(["Tab Context", "tabContext", "Tab", "tab", "Section", "Category Type"]);
            const itemTabContext: "IT" | "Furniture" | "Misc" = normalizeTabContext(explicitTab || currentTab, finalCategory);

            const tabPrefix = itemTabContext === "IT" ? "IT" : itemTabContext === "Furniture" ? "Fur" : "Mis";
            const existingTabCount = allExistingItems.filter(i => (i.tabContext || "").trim().toLowerCase() === itemTabContext.toLowerCase()).length;
            // Skip rows that lack any name, serial, model, or category
            if (!rawName && !rowSerial && !rawModel && !rawCatValue) {
              continue;
            }

            const customAssetId = getValueByKeys(["Asset ID", "assetId", "id", "ID"]);

            // Deduplicate ONLY against matching non-generic serial numbers or matching explicit custom Asset IDs
            const isDuplicateInDbOrBatch = (
              allExistingItems.some(existing => {
                if (existing.nodeLocation !== itemNodeLocation) return false;
                if (rowSerial && !isGenericSerial(rowSerial) && existing.serial && !isGenericSerial(existing.serial)) {
                  return existing.serial.trim().toLowerCase() === rowSerial.trim().toLowerCase();
                }
                if (customAssetId && existing.id) {
                  return existing.id.trim().toUpperCase() === customAssetId.trim().toUpperCase();
                }
                return false;
              }) ||
              itemsToInsert.some(inserted => {
                if (inserted.nodeLocation !== itemNodeLocation) return false;
                if (rowSerial && !isGenericSerial(rowSerial) && inserted.serial && !isGenericSerial(inserted.serial)) {
                  return inserted.serial.trim().toLowerCase() === rowSerial.trim().toLowerCase();
                }
                if (customAssetId && inserted.id) {
                  return inserted.id.trim().toUpperCase() === customAssetId.trim().toUpperCase();
                }
                return false;
              })
            );

            if (isDuplicateInDbOrBatch) {
              continue;
            }

            const assetId = customAssetId || `${tabPrefix}${String(existingTabCount + itemsToInsert.length + 1).padStart(4, '0')}`;

            const payload: InventoryItem = {
              id: assetId,
              timestampId: baseImportBatchTs + (itemsToInsert.length * 50) + Math.floor(Math.random() * 40) + 1,
              nodeLocation: itemNodeLocation,
              tabContext: itemTabContext,
              name: nameValue,
              serial: rowSerial || null,
              model: rawModel ? rawModel : null,
              category: finalCategory,
              quantity: !isNaN(parsedQty) && parsedQty > 0 ? parsedQty : 1,
              receivedFrom: getValueByKeys(["Received From", "receivedFrom", "Source", "Vendor", "Donor"]) || null,
              date: parsedDate,
              workingStatus: normWorkingStatus,
              workingSubStatus: normWorkingSubStatus,
              issueTo: (normWorkingStatus === "Working" && normWorkingSubStatus === "Issued") ? (getValueByKeys(["Issue To", "issueTo", "Issued To", "Assigned To", "User"]) || null) : null,
              designation: (normWorkingStatus === "Working" && normWorkingSubStatus === "Issued") ? (getValueByKeys(["Designation", "designation", "Post", "Title"]) || null) : null,
              issuedDate: (normWorkingStatus === "Working" && normWorkingSubStatus === "Issued") ? parsedIssuedDate : null,
              nonWorkingSubStatus: normNonWorkingSubStatus,
              remarks: rawRemarks || null
            };

            itemsToInsert.push(payload);
          }
        }

        if (itemsToInsert.length > 0) {
          let savedCount = itemsToInsert.length;
          if (onItemsBulkCommit) {
            const res = await onItemsBulkCommit(itemsToInsert);
            if (res && typeof res.successCount === 'number') {
              savedCount = res.successCount;
            }
          } else {
            for (const item of itemsToInsert) {
              await onItemCommit(item);
            }
          }
          alert(`Successfully uploaded ${savedCount} of ${itemsToInsert.length} records directly to Supabase inventory database!`);
        } else {
          alert("No valid equipment records found in the uploaded file.");
        }

        event.target.value = ""; // Clear file selector input
      } catch (err) {
        console.error(err);
        alert(`Error importing file: ${err instanceof Error ? err.message : String(err)}`);
      }
    };
    reader.readAsBinaryString(file);
  };

  const handlePrint = () => {
    setShowPrintPreviewModal(true);
    setTimeout(() => {
      triggerPrintDocument("printableLedgerDocumentContent");
    }, 150);
  };

  const handleDownloadOfflineHTML = async () => {
    setIsCompiling(true);
    setIsCookieBlocked(false);
    try {
      let htmlText = "";
      
      // 1. Primary Source: Compile the latest app on-the-fly and fetch the HTML template
      try {
        const res = await fetch(`/api/compile-single-html?t=${Date.now()}`, { cache: "no-store" });
        if (res.ok) {
          const txt = await res.text();
          if (txt && txt.toLowerCase().includes("doctype html") && !txt.includes("blocking a required security cookie") && !txt.includes("Safari") && txt.includes("id=\"root\"")) {
            htmlText = txt;
          } else {
            console.warn("Fetched HTML is an auth proxy or cookie-block page. Using robust local fallback.");
            setIsCookieBlocked(true);
          }
        } else {
          setIsCookieBlocked(true);
        }
      } catch (e) {
        console.error("Server compilation fetch failed, falling back to local clone:", e);
        setIsCookieBlocked(true);
      }

      // 2. Fallback: Use active page DOM if fetch failed
      if (!htmlText) {
        const docClone = document.documentElement.cloneNode(true) as HTMLElement;
        const oldDataEl = docClone.querySelector("#preseed-inventory-data");
        if (oldDataEl) oldDataEl.remove();
        const oldStateEl = docClone.querySelector("#preseed-database-state");
        if (oldStateEl) oldStateEl.remove();
        
        // CLEAR the active React mounting container to ensure a clean, un-hydrated template!
        const rootEl = docClone.querySelector("#root");
        if (rootEl) {
          rootEl.innerHTML = "";
        }
        
        htmlText = "<!DOCTYPE html>\n" + docClone.outerHTML;
      }

      // Inject the latest synchronized dataset, users, and timestamp into the downloaded HTML
      const serializedData = JSON.stringify(allLocationData);
      const storedUsers = localStorage.getItem("system_users_db") || "{}";
      let modifiedHtml = htmlText;

      // Also inject a head-script for preseeding modern compiled React single-file offline localStorage
      const dataScriptId = "preseed-inventory-data";
      const usersScriptId = "preseed-system-users";
      const preseedScript = `
<` + `script type="application/json" id="${dataScriptId}">
${serializedData.replace(/<\/script>/g, '<\\/script>')}
</` + `script>
<` + `script type="application/json" id="${usersScriptId}">
${storedUsers.replace(/<\/script>/g, '<\\/script>')}
</` + `script>
<` + `script id="preseed-database-state">
  try {
    const preseededTimestamp = ${Date.now()};
    window.preseededTimestamp = preseededTimestamp;
    const cachedTime = localStorage.getItem("inventory_db_timestamp") || 0;
    if (preseededTimestamp > Number(cachedTime)) {
      const dataEl = document.getElementById("${dataScriptId}");
      if (dataEl) {
        const jsonStr = dataEl.textContent || "";
        localStorage.setItem("inventory_db", jsonStr);
        localStorage.setItem("inventory_db_timestamp", preseededTimestamp.toString());
        localStorage.setItem("inventory_db_offline", jsonStr);
        localStorage.setItem("inventory_db_offline_timestamp", preseededTimestamp.toString());
      }
      const usersEl = document.getElementById("${usersScriptId}");
      if (usersEl) {
        const usersJsonStr = usersEl.textContent || "";
        if (usersJsonStr && usersJsonStr !== "{}") {
          localStorage.setItem("system_users_db", usersJsonStr);
        }
      }
    }
  } catch (e) {
    console.error("Offline preseed error:", e);
  }
</` + `script>
`;
      
      if (modifiedHtml.includes("<head>")) {
        modifiedHtml = modifiedHtml.replace("<head>", `<head>${preseedScript}`);
      } else if (modifiedHtml.includes("<HEAD>")) {
        modifiedHtml = modifiedHtml.replace("<HEAD>", `<HEAD>${preseedScript}`);
      } else {
        modifiedHtml = preseedScript + modifiedHtml;
      }

      // Open download wizard modal with the generated HTML
      setDownloadModalData({ isOpen: true, html: modifiedHtml });
      setCopiedHtml(false);

    } catch (err: any) {
      console.error("Offline HTML download process error:", err);
      alert("Offline app template could not be loaded. Please try again.");
    } finally {
      setIsCompiling(false);
    }
  };

  const getCategoryIcon = (category: string) => {
    const cat = category.toLowerCase();
    if (cat.includes("monitor")) return <Tv className={`w-4.5 h-4.5 ${isLightMode ? "text-blue-700" : "text-cyan-300"}`} />;
    if (cat.includes("biometric") || cat.includes("bio")) return <Shield className={`w-4.5 h-4.5 ${isLightMode ? "text-emerald-700" : "text-emerald-400"}`} />;
    if (cat.includes("computer") || cat.includes("laptop")) return <Laptop className={`w-4.5 h-4.5 ${isLightMode ? "text-blue-700" : "text-cyan-400"}`} />;
    if (cat.includes("printer")) return <Printer className={`w-4.5 h-4.5 ${isLightMode ? "text-indigo-700" : "text-blue-400"}`} />;
    if (cat.includes("scanner")) return <Search className={`w-4.5 h-4.5 ${isLightMode ? "text-teal-700" : "text-teal-400"}`} />;
    if (cat.includes("photo") || cat.includes("state")) return <FileSpreadsheet className={`w-4.5 h-4.5 ${isLightMode ? "text-purple-700" : "text-indigo-400"}`} />;
    if (cat.includes("chair")) return <Sofa className={`w-4.5 h-4.5 ${isLightMode ? "text-amber-700" : "text-orange-400"}`} />;
    if (cat.includes("table")) return <Package className={`w-4.5 h-4.5 ${isLightMode ? "text-amber-800" : "text-amber-400"}`} />;
    if (cat.includes("sofa")) return <Sofa className={`w-4.5 h-4.5 ${isLightMode ? "text-rose-700" : "text-pink-400"}`} />;
    if (cat.includes("rack") || cat.includes("almarah")) return <Layers className={`w-4.5 h-4.5 ${isLightMode ? "text-purple-700" : "text-purple-400"}`} />;
    if (cat.includes("generator")) return <Cpu className={`w-4.5 h-4.5 ${isLightMode ? "text-rose-700" : "text-rose-400"}`} />;
    if (cat.includes("ac") || cat.includes("air")) return <Zap className={`w-4.5 h-4.5 ${isLightMode ? "text-sky-700" : "text-sky-300"}`} />;
    if (cat.includes("ups")) return <Zap className={`w-4.5 h-4.5 ${isLightMode ? "text-amber-700" : "text-amber-400"}`} />;
    if (cat.includes("camera")) return <Camera className={`w-4.5 h-4.5 ${isLightMode ? "text-emerald-700" : "text-emerald-400"}`} />;
    if (cat.includes("dispenser") || cat.includes("water")) return <Droplet className={`w-4.5 h-4.5 ${isLightMode ? "text-blue-700" : "text-sky-400"}`} />;
    if (cat.includes("led")) return <Tv className={`w-4.5 h-4.5 ${isLightMode ? "text-amber-700" : "text-yellow-400"}`} />;
    if (cat.includes("fridge") || cat.includes("refrigerator")) return <Cpu className={`w-4.5 h-4.5 ${isLightMode ? "text-indigo-700" : "text-blue-300"}`} />;
    return <Package className={`w-4.5 h-4.5 ${isLightMode ? "text-slate-700" : "text-slate-400"}`} />;
  };

  return (
    <div className="space-y-6">
      {/* EXQUISITE HEADER AND SUBTITLE */}
      <div className={isLightMode 
        ? "bg-white border-2 border-slate-200 p-4 rounded-2xl flex flex-col justify-start gap-1.5 shadow-xs print:hidden animate-fadeIn"
        : "bg-slate-800/90 backdrop-blur-xl border border-slate-700/80 p-4.5 rounded-2xl flex flex-col justify-start gap-1.5 shadow-lg print:hidden animate-fadeIn"
      }>
        <div className="flex items-center gap-2">
          <span className={`w-2.5 h-2.5 ${isLightMode ? "bg-blue-600" : "bg-blue-400"} rounded-full animate-ping`}></span>
          <h2 className={`text-sm font-black uppercase tracking-wider ${isLightMode ? "text-slate-900" : "text-white"}`}>
            Office Ledger &bull; {currentNodeLocation === "All Offices" ? "All Offices (Kohat Division Consolidated)" : currentNodeLocation}
          </h2>
        </div>
      </div>

      {/* SUPERVISOR VIEW BANNER */}
      {!isWriteAllowed && (
        <div className={isLightMode
          ? "bg-blue-50 border border-blue-200 p-3 rounded-xl flex items-center gap-2.5 animate-fadeIn text-xs text-blue-800 font-bold"
          : "bg-slate-800 border border-blue-500/40 p-3 rounded-xl flex items-center gap-2.5 animate-fadeIn text-xs text-blue-300 font-bold"
        }>
          <Shield className={`w-4 h-4 ${isLightMode ? "text-blue-700" : "text-blue-400"} shrink-0`} />
          <span>Supervisor view (Read Only)</span>
        </div>
      )}

      {/* CATEGORIES WISE AMOUNT IN OFFICE LEDGER */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3 print:hidden animate-fadeIn">
        {activeCategories.map(cat => {
          const itemsInCat = deduplicatedScopeData.filter(item => item.category.toLowerCase() === cat.toLowerCase());
          const count = getSumQty(itemsInCat);
          return (
            <div 
              key={cat} 
              className={isLightMode
                ? "bg-white border-2 border-slate-200/90 rounded-2xl p-3.5 flex items-center justify-between gap-3 shadow-xs hover:border-blue-500 hover:shadow-md transition-all duration-200"
                : "bg-slate-800/95 backdrop-blur-md border border-slate-700/80 hover:border-blue-500/60 rounded-2xl p-3.5 flex items-center justify-between gap-3 shadow-md hover:shadow-xl hover:shadow-blue-950/30 hover:-translate-y-0.5 transition-all duration-200"
              }
            >
              <div className="space-y-1 min-w-0">
                <p className={isLightMode
                  ? "text-[11px] font-black text-slate-700 uppercase tracking-wider truncate capitalize"
                  : "text-[11px] font-black text-slate-300 uppercase tracking-wider truncate capitalize"
                }>
                  {cat}
                </p>
                <p className={isLightMode
                  ? "text-2xl font-black text-slate-950 font-mono leading-none tracking-tight"
                  : "text-2xl font-black text-white font-mono leading-none tracking-tight"
                }>
                  {count}
                </p>
              </div>
              <div className={isLightMode
                ? "p-2.5 bg-blue-50/80 border border-blue-200/70 rounded-xl shrink-0 shadow-xs"
                : "p-2.5 bg-slate-900/90 border border-slate-700/80 rounded-xl shrink-0 shadow-inner"
              }>
                {getCategoryIcon(cat)}
              </div>
            </div>
          );
        })}
      </div>

      {/* INPUTS FORM PANEL BLOCK */}
      {isWriteAllowed && (
        <form 
          id="registryInputsFormBlock"
          onSubmit={handleSave} 
          className="bg-slate-900/30 backdrop-blur-2xl border border-slate-800/70 rounded-2xl p-6 shadow-xl space-y-4 print:hidden animate-fadeIn"
        >
          <div className="flex items-center justify-between border-b border-slate-800/70 pb-3">
            <h3 className="text-xs font-black text-blue-400 uppercase tracking-widest flex items-center gap-1.5">
              <span className="p-1 bg-blue-500/10 text-blue-400 rounded-md">
                <Plus className="w-4 h-4" />
              </span>
              {editingItemId ? `✏️ Modify Asset Entry (${editingItemId})` : `📝 New Asset Registration Entry`}
            </h3>
            {editingItemId && (
              <button
                type="button"
                onClick={clearForm}
                className="text-xs text-rose-400 hover:text-rose-350 underline font-semibold transition"
              >
                Reset Form
              </button>
            )}
          </div>

          {currentNodeLocation === "All Offices" && (
            <div className="bg-slate-950/40 p-3 rounded-xl border border-blue-500/20 mb-3 flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
              <label className="text-xs font-bold text-blue-300 shrink-0">Select Target Office Location:</label>
              <select
                value={assetNodeLocation}
                onChange={(e) => setAssetNodeLocation(e.target.value)}
                className="bg-slate-900 border border-slate-750 focus:border-blue-500 focus:outline-none rounded-lg p-2 text-xs text-white max-w-xs font-bold cursor-pointer"
              >
                <option value="REC Kohat">REC Kohat</option>
                <option value="DEC Kohat">DEC Kohat</option>
                <option value="DEC Hangu">DEC Hangu</option>
                <option value="DEC Karak">DEC Karak</option>
                <option value="DEC Orakzai">DEC Orakzai</option>
                <option value="DEC Kurram">DEC Kurram</option>
              </select>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">Asset Model Name</label>
              <input
                type="text"
                placeholder={getDynamicPlaceholders().name}
                value={assetName}
                onChange={(e) => setAssetName(e.target.value)}
                className="w-full bg-slate-950/45 border border-slate-800/60 focus:border-blue-500/80 focus:outline-none rounded-lg p-2.5 text-xs text-white"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">
                Serial / Stock Reg. P.No/ S.NO.
              </label>
              <input
                type="text"
                placeholder={getDynamicPlaceholders().serial}
                value={assetSerial}
                onChange={(e) => setAssetSerial(e.target.value)}
                className="w-full bg-slate-950/45 border border-slate-800/60 focus:border-blue-500/80 focus:outline-none rounded-lg p-2.5 text-xs text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">Model / Specification</label>
              <input
                type="text"
                placeholder={getDynamicPlaceholders().model}
                value={assetModel}
                onChange={(e) => setAssetModel(e.target.value)}
                className="w-full bg-slate-950/45 border border-slate-800/60 focus:border-blue-500/80 focus:outline-none rounded-lg p-2.5 text-xs text-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 transition-all duration-300">
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">Asset Category</label>
              <select
                value={assetCategory}
                onChange={(e) => setAssetCategory(e.target.value)}
                className="w-full bg-slate-950/45 border border-slate-800/60 focus:border-blue-500/80 focus:outline-none rounded-lg p-2.5 text-xs text-white font-medium"
                required
              >
                <option value="" className="bg-slate-950 text-slate-200">-- Select Category --</option>
                {activeCategories.map(cat => (
                  <option key={cat} value={cat} className="capitalize bg-slate-950 text-slate-200">{cat}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">Received From</label>
              <select
                value={assetReceived}
                onChange={(e) => {
                  setAssetReceived(e.target.value);
                  if (e.target.value !== "Gifted") {
                    setGifterName("");
                    setGifterDesignation("");
                  }
                }}
                className="w-full bg-slate-950/45 border border-slate-800/60 focus:border-blue-500/80 focus:outline-none rounded-lg p-2.5 text-xs text-white font-medium"
              >
                <option value="" className="bg-slate-950 text-slate-400">-- Choose Option --</option>
                <option value="ECP" className="bg-slate-950 text-slate-200">ECP</option>
                <option value="PEC" className="bg-slate-950 text-slate-200">PEC</option>
                <option value="REC" className="bg-slate-950 text-slate-200">REC</option>
                <option value="DEC" className="bg-slate-950 text-slate-200">DEC</option>
                <option value="Purchase Local" className="bg-slate-950 text-slate-200">Purchase Local</option>
                <option value="Gifted" className="bg-slate-950 text-slate-200">Gifted</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">Receiving Date</label>
              <input
                type="date"
                value={assetDate}
                onChange={(e) => setAssetDate(e.target.value)}
                className="w-full bg-slate-950/45 border border-slate-800/60 focus:border-blue-500/80 focus:outline-none rounded-lg p-2.5 text-xs text-white"
              />
            </div>
          </div>

          {/* Conditional Gifted Gifter/Donor Fields */}
          {assetReceived === "Gifted" && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-emerald-500/5 border border-emerald-500/10 p-4 rounded-xl animate-fadeIn">
              <div>
                <label className="block text-xs font-semibold text-emerald-400 mb-1">Name of Gifter / Donor</label>
                <input
                  type="text"
                  placeholder="e.g. Muhammad Ali"
                  value={gifterName}
                  onChange={(e) => setGifterName(e.target.value)}
                  className="w-full bg-slate-950/45 border border-emerald-500/20 focus:border-emerald-500 focus:outline-none rounded-lg p-2.5 text-xs text-white"
                  required={assetReceived === "Gifted"}
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-emerald-400 mb-1">Designation of Gifter / Donor</label>
                <input
                  type="text"
                  placeholder="e.g. CRO Office Peshawar"
                  value={gifterDesignation}
                  onChange={(e) => setGifterDesignation(e.target.value)}
                  className="w-full bg-slate-950/45 border border-emerald-500/20 focus:border-emerald-500 focus:outline-none rounded-lg p-2.5 text-xs text-white"
                  required={assetReceived === "Gifted"}
                />
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 border-t border-slate-800/40 pt-2">
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">Working Condition Status</label>
              <select
                value={workingStatus}
                onChange={(e) => {
                  setWorkingStatus(e.target.value);
                  setWorkingSubStatus("");
                  setNonWorkingSubStatus("");
                }}
                className="w-full bg-slate-950/45 border border-slate-800/60 focus:border-blue-500/80 focus:outline-none rounded-lg p-2.5 text-xs text-white font-bold"
                required
              >
                <option value="" className="bg-slate-950 text-slate-200">-- Choose Status --</option>
                <option value="Working" className="text-emerald-450 bg-slate-950 font-bold">Working</option>
                <option value="Non-Working" className="text-rose-455 bg-slate-950 font-bold">Non-Working</option>
              </select>
            </div>

            {workingStatus === "Working" && (
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1 text-emerald-400">Working Allocation Type</label>
                <select
                  value={workingSubStatus}
                  onChange={(e) => {
                    setWorkingSubStatus(e.target.value);
                    if (e.target.value !== "Issued") {
                      setIssueTo("");
                      setDesignation("");
                      setIssuedDate("");
                    }
                  }}
                  className="w-full bg-slate-950/45 border border-emerald-500/30 focus:border-blue-500/80 focus:outline-none rounded-lg p-2.5 text-xs text-white"
                  required
                >
                  <option value="" className="bg-slate-950 text-slate-200">-- Choose Type --</option>
                  <option value="Issued" className="bg-slate-950 text-slate-200">Issued (Assigned)</option>
                  <option value="In-stock" className="bg-slate-950 text-slate-200">In-Stock</option>
                </select>
              </div>
            )}

            {workingStatus === "Non-Working" && (
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1 text-rose-400">Condition Reason</label>
                <select
                  value={nonWorkingSubStatus}
                  onChange={(e) => setNonWorkingSubStatus(e.target.value)}
                  className="w-full bg-slate-950/45 border border-rose-500/30 focus:border-rose-500/80 focus:outline-none rounded-lg p-2.5 text-xs text-white"
                  required
                >
                  <option value="" className="bg-slate-950 text-slate-200">-- Condition Reason --</option>
                  <option value="Needs to repair" className="bg-slate-950 text-slate-200">Needs to repair</option>
                  <option value="Ready for Condemnation" className="bg-slate-950 text-slate-200">Ready for condemnation</option>
                </select>
              </div>
            )}
          </div>

          {/* Inline Assignment Row if working status is working/issued */}
          {workingStatus === "Working" && workingSubStatus === "Issued" && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-emerald-500/5 p-4 rounded-lg border border-emerald-500/15 animate-fadeIn">
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1">Assigned Name</label>
                <input
                  type="text"
                  placeholder="Officer / Official Username"
                  value={issueTo}
                  onChange={(e) => setIssueTo(e.target.value)}
                  className="w-full bg-slate-950/45 border border-slate-800/60 focus:border-emerald-550 focus:outline-none rounded-lg p-2.5 text-xs text-white"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1">Designation</label>
                <input
                  type="text"
                  placeholder="Officer/Official name"
                  value={designation}
                  onChange={(e) => setDesignation(e.target.value)}
                  className="w-full bg-slate-950/45 border border-slate-800/60 focus:border-emerald-550 focus:outline-none rounded-lg p-2.5 text-xs text-white"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1">Assignment Date</label>
                <input
                  type="date"
                  value={issuedDate}
                  onChange={(e) => setIssuedDate(e.target.value)}
                  className="w-full bg-slate-950/45 border border-slate-800/60 focus:border-emerald-550 focus:outline-none rounded-lg p-2.5 text-xs text-white"
                  required
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">
              Observations / Remarks
            </label>
            <input
              type="text"
              placeholder="Any critical observations or remarks notes (Optional)"
              value={remarks}
              onChange={(e) => setRemarks(e.target.value)}
              className="w-full bg-slate-950/45 border border-slate-800/60 focus:border-blue-500/80 focus:outline-none rounded-lg p-2.5 text-xs text-white"
            />
          </div>

          <div className="flex flex-col md:flex-row justify-between items-center gap-4 pt-4 border-t border-slate-800/60 mt-4 print:hidden">
            {/* Left side actions: Export Excel, Download, Import Excel, and Clear All / Delete All */}
            <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto justify-start">
              <button
                type="button"
                onClick={handleExportToExcel}
                className="bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white text-[11px] font-bold px-3.5 py-2 rounded-lg flex items-center gap-1.5 cursor-pointer transition-all active:scale-95 shadow-sm"
                title="Export active inventory records to Excel (.xlsx)"
              >
                <FileSpreadsheet className="w-3.5 h-3.5" /> Export Excel
              </button>

              <button
                type="button"
                onClick={handlePrint}
                className="bg-sky-600 hover:bg-sky-500 active:bg-sky-700 text-white text-[11px] font-bold px-3.5 py-2 rounded-lg flex items-center gap-1.5 cursor-pointer transition-all active:scale-95 shadow-sm"
                title="Official Print Preview and Save as PDF"
              >
                <Printer className="w-3.5 h-3.5" /> Print / PDF
              </button>

              {isSuperAdmin && (
                <button
                  type="button"
                  onClick={handleDownloadOfflineHTML}
                  className="bg-purple-600 hover:bg-purple-500 active:bg-purple-700 text-white text-[11px] font-bold px-3.5 py-2 rounded-lg flex items-center gap-1.5 cursor-pointer transition-all active:scale-95 shadow-sm"
                  title="Download Standalone Offline HTML or Project ZIP"
                >
                  <Download className={`w-3.5 h-3.5 ${isCompiling ? "animate-spin" : ""}`} /> 
                  {isCompiling ? "Compiling..." : "Export Offline App"}
                </button>
              )}

              {isWriteAllowed && (
                <>
                  <label className="bg-teal-700 hover:bg-teal-600 active:bg-teal-800 text-white text-[11px] font-bold px-3.5 py-2 rounded-lg flex items-center gap-1.5 cursor-pointer transition-all active:scale-95 shadow-sm">
                    <FileSpreadsheet className="w-3.5 h-3.5" />
                    Import Excel
                    <input
                      type="file"
                      accept=".xlsx, .xls"
                      onChange={handleImportExcel}
                      className="hidden"
                    />
                  </label>

                  {isSuperAdmin && (
                    <button
                      type="button"
                      onClick={() => {
                        if (confirmClearAll) {
                          onItemDeleteAll();
                          setConfirmClearAll(false);
                        } else {
                          setConfirmClearAll(true);
                        }
                      }}
                      className={`transition-all cursor-pointer flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-[11px] font-bold border ${
                        confirmClearAll
                          ? "bg-rose-600 border-transparent text-white animate-pulse"
                          : "bg-rose-600/20 hover:bg-rose-600 border-rose-500/20 text-rose-400 hover:text-white"
                      }`}
                      title={confirmClearAll ? "Click again to confirm clearing all active assets" : `Clear All ${currentTab} Assets`}
                    >
                      <Trash2 className="w-3.5 h-3.5" /> 
                      {confirmClearAll ? "Confirm Clear All?" : `Clear All ${currentTab} Assets`}
                    </button>
                  )}
                </>
              )}
            </div>

            {/* Right side: Update Record & Save Record controls */}
            <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto justify-end border-t md:border-t-0 pt-3 md:pt-0 border-slate-850">
              {editingItemId ? (
                <>
                  <button
                    type="button"
                    onClick={clearForm}
                    className="bg-slate-800 hover:bg-slate-700 border border-slate-700/60 text-slate-300 font-medium px-4 py-2.5 text-xs rounded-lg cursor-pointer transition-all active:scale-95 flex items-center gap-1"
                  >
                    Cancel Edit
                  </button>

                  {/* "Update Record" button placed to the LEFT side of Save Record */}
                  <button
                    type="submit"
                    className="bg-amber-600 hover:bg-amber-500 active:bg-amber-700 text-white font-bold px-5 py-2.5 text-xs rounded-lg cursor-pointer transition-all flex items-center gap-1.5 shadow-md shadow-amber-600/20 active:scale-95 ring-2 ring-amber-400/40"
                    title="Update and save changes for the selected record"
                  >
                    <CheckCircle2 className="w-4 h-4" /> Update Record
                  </button>

                  <button
                    type="button"
                    onClick={(e) => {
                      setEditingItemId(null);
                      setEditingOriginalSerial(null);
                      editingItemIdRef.current = null;
                      handleSave(e, true);
                    }}
                    className="bg-green-700/80 hover:bg-green-600 text-white font-semibold px-4 py-2.5 text-xs rounded-lg cursor-pointer transition-all flex items-center gap-1.5 active:scale-95"
                    title="Save current form values as a new record"
                  >
                    <Plus className="w-4 h-4" /> Save as New
                  </button>
                </>
              ) : (
                <>
                  {/* "Update Record" button placed to the LEFT side of Save Record */}
                  <button
                    type="button"
                    onClick={(e) => {
                      if (editingItemId || editingItemIdRef.current) {
                        handleSave(e);
                      } else {
                        alert("To update a record, please choose and click the ✏️ 'Edit' button next to any item in the Inventory Register table below.");
                      }
                    }}
                    className="bg-amber-600/60 hover:bg-amber-600 text-white font-bold px-4 py-2.5 text-xs rounded-lg cursor-pointer transition-all flex items-center gap-1.5 shadow-md active:scale-95"
                    title="Choose a record from the table below using the Edit button to update it"
                  >
                    <Edit2 className="w-3.5 h-3.5 text-amber-200" /> Update Record
                  </button>

                  <button
                    type="submit"
                    onClick={() => {
                      // Reset editing ID ref to guarantee creation of new record
                      setEditingItemId(null);
                      setEditingOriginalSerial(null);
                      editingItemIdRef.current = null;
                    }}
                    className="bg-green-600 hover:bg-green-500 text-white font-bold px-6 py-2.5 text-xs rounded-lg cursor-pointer transition-all flex items-center gap-1.5 shadow-md hover:shadow-green-500/20 active:scale-95"
                  >
                    <Plus className="w-4 h-4" /> Save Record
                  </button>
                </>
              )}
            </div>
          </div>
        </form>
      )}

      {/* INVENTORY REGISTER TABLE (Category-specific register table) */}
      <div className="space-y-4 pt-2">
        <div className="flex flex-wrap justify-between items-center bg-slate-950/30 backdrop-blur-md p-4 rounded-xl border border-slate-800/60 shadow-lg gap-2">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></span>
            <h3 className="text-xs font-black text-blue-400 uppercase tracking-widest">
              Inventory Register — {currentTab === "IT" ? "IT Equipment" : currentTab === "Furniture" ? "Furniture Assets" : "Miscellaneous"}
            </h3>
          </div>
          <div className="flex flex-wrap items-center gap-2 md:gap-3">
            {/* Category Filter Dropdown (Left side of Show selector) */}
            <div className="flex items-center bg-slate-900 border border-slate-800 px-2.5 py-1 rounded-lg gap-1.5 text-xs">
              <Filter className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-[10px] font-bold text-slate-400 uppercase">Category Filter:</span>
              <select
                value={selectedCategoryFilter}
                onChange={(e) => setSelectedCategoryFilter(e.target.value)}
                className="bg-slate-950 text-emerald-400 font-extrabold text-xs px-2 py-0.5 rounded border border-emerald-500/30 focus:outline-none cursor-pointer capitalize"
              >
                <option value="All">All Categories ({deduplicatedScopeData.length})</option>
                {categoryFilterOptions.map(cat => (
                  <option key={cat} value={cat} className="capitalize bg-slate-950 text-slate-200">
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            {/* Show Records Limit Selector */}
            <div className="flex items-center bg-slate-900 border border-slate-800 px-2.5 py-1 rounded-lg gap-1.5 text-xs">
              <span className="text-[10px] font-bold text-slate-400 uppercase">Show:</span>
              <select
                value={pageSize}
                onChange={(e) => {
                  const val = e.target.value;
                  setPageSize(val === "All" ? "All" : Number(val));
                }}
                className="bg-slate-950 text-blue-400 font-extrabold text-xs px-2 py-0.5 rounded border border-blue-500/30 focus:outline-none cursor-pointer"
              >
                <option value={50}>50 Records</option>
                <option value={100}>100 Records</option>
                <option value={200}>200 Records</option>
                <option value={500}>500 Records</option>
                <option value="All">All Records</option>
              </select>
            </div>

            <div className="flex items-center bg-slate-900 border border-slate-800 px-2.5 py-1 rounded-lg gap-1.5 text-xs">
              <span className="text-[10px] font-bold text-slate-400 uppercase">Category Order:</span>
              <button
                type="button"
                onClick={() => setCategorySortOrder(prev => prev === "none" ? "asc" : prev === "asc" ? "desc" : "none")}
                className="bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 font-extrabold px-2.5 py-0.5 rounded text-[11px] cursor-pointer transition flex items-center gap-1"
                title="Sort by Category Column"
              >
                {categorySortOrder === "none" && "Default ↕"}
                {categorySortOrder === "asc" && "Ascending (A-Z) ▲"}
                {categorySortOrder === "desc" && "Descending (Z-A) ▼"}
              </button>
            </div>

            <span className="text-xs bg-blue-950/40 text-blue-300 font-extrabold px-3 py-1 rounded-full border border-blue-500/20">
              {pageSize === "All"
                ? `${totalRecords} records in ${currentTab}`
                : `Showing ${totalRecords === 0 ? 0 : (currentPage - 1) * (pageSize as number) + 1}-${Math.min(currentPage * (pageSize as number), totalRecords)} of ${totalRecords}`}
            </span>
          </div>
        </div>

        <div className="overflow-x-auto rounded-xl border border-slate-800/60 bg-slate-950/20 backdrop-blur-sm shadow-xl">
          <table className="w-full text-left text-xs text-slate-300 divide-y divide-slate-800">
            <thead className="bg-slate-900/50 backdrop-blur-sm text-slate-300 uppercase font-black text-[10px] tracking-wider">
              <tr>
                <th className="px-3 py-3 border-b border-slate-800 text-center w-10 text-slate-400">Sr. #</th>
                <th className="px-4 py-3 border-b border-slate-800 text-cyan-400 font-extrabold">Asset ID</th>
                {(currentNodeLocation.toLowerCase() === "all offices") && (
                  <th className="px-4 py-3 border-b border-slate-800 text-indigo-400 font-extrabold">Office Location</th>
                )}
                <th className="px-4 py-3 border-b border-slate-800 text-blue-400">Asset Name</th>
                <th className="px-4 py-3 border-b border-slate-800">Serial / Stock Reg. P.No/ S.NO.</th>
                <th className="px-4 py-3 border-b border-slate-800">Model</th>
                <th 
                  className="px-4 py-3 border-b border-slate-800 cursor-pointer select-none hover:text-amber-400 transition-colors"
                  onClick={() => setCategorySortOrder(prev => prev === "none" ? "asc" : prev === "asc" ? "desc" : "none")}
                  title="Click to sort Category Ascending / Descending"
                >
                  <div className="flex items-center gap-1.5">
                    <span>Category</span>
                    <span className="bg-slate-800 px-1.5 py-0.5 rounded text-amber-400 font-extrabold text-[9px]">
                      {categorySortOrder === "none" && "↕"}
                      {categorySortOrder === "asc" && "▲ A-Z"}
                      {categorySortOrder === "desc" && "▼ Z-A"}
                    </span>
                  </div>
                </th>
                <th className="px-4 py-3 border-b border-slate-800">Received From</th>
                <th className="px-4 py-3 border-b border-slate-800">Receiving Date</th>
                <th className="px-4 py-3 border-b border-slate-800">Status Condition</th>
                <th className="px-4 py-3 border-b border-slate-800">Assigned To</th>
                <th className="px-4 py-3 border-b border-slate-800">Designation</th>
                <th className="px-4 py-3 border-b border-slate-800">Assignment Date</th>
                <th className="px-4 py-3 border-b border-slate-800">
                  Observations / Remarks
                </th>
                {isWriteAllowed && (
                  <th className="px-4 py-3 border-b border-slate-800 text-center">Actions</th>
                )}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 bg-[#0f172a]/10">
              {sortedScopeData.length === 0 ? (
                <tr>
                  <td colSpan={isWriteAllowed ? (currentNodeLocation.toLowerCase() === "all offices" ? 15 : 14) : (currentNodeLocation.toLowerCase() === "all offices" ? 14 : 13)} className="px-4 py-8 text-center text-slate-500 font-semibold italic">
                    No active {currentTab === "IT" ? "IT Equipment" : currentTab === "Furniture" ? "Furniture Assets" : "Miscellaneous"} records registered for this location yet.
                  </td>
                </tr>
              ) : (
                paginatedData.map((item, idx) => {
                  const isWorking = item.workingStatus === "Working";
                  const serialIndex = pageSize === "All" ? idx + 1 : (currentPage - 1) * (pageSize as number) + idx + 1;
                  const tabPrefix = currentTab === "IT" ? "IT" : currentTab === "Furniture" ? "Fur" : "Mis";
                  const formattedAssetId = item.id || `${tabPrefix}${String(serialIndex).padStart(4, '0')}`;
                  return (
                    <tr key={item.timestampId} className="hover:bg-slate-850/45 transition-colors duration-150">
                      <td className="px-3 py-3 font-mono font-extrabold text-slate-400 text-center text-xs">{serialIndex}</td>
                      <td className="px-4 py-3 font-mono font-black text-cyan-400 text-xs tracking-wider">{formattedAssetId}</td>
                      {(currentNodeLocation.toLowerCase() === "all offices") && (
                        <td className="px-4 py-3 font-bold text-indigo-300 text-xs whitespace-nowrap">
                          <span className="bg-indigo-950/80 text-indigo-300 border border-indigo-500/40 px-2 py-0.5 rounded-md text-[10px] shadow-sm font-mono">
                            {item.nodeLocation}
                          </span>
                        </td>
                      )}
                      <td className="px-4 py-3 font-bold text-slate-100">{item.name}</td>
                      <td className="px-4 py-3 font-mono text-slate-400 text-[11px]">{item.serial || "-"}</td>
                      <td className="px-4 py-3 text-slate-400">{item.model || "-"}</td>
                      <td className="px-4 py-3">
                        <span className="bg-slate-800/80 text-amber-400 px-2.5 py-0.5 rounded text-[10px] font-bold border border-slate-700/60">{item.category}</span>
                      </td>
                      <td className="px-4 py-3 text-slate-400">{item.receivedFrom || "-"}</td>
                      <td className="px-4 py-3 text-slate-400">{item.date || "-"}</td>
                      <td className="px-4 py-3">
                        <div className="space-y-1">
                          <span className={`inline-flex items-center gap-1 font-bold px-2 py-0.5 rounded text-[10px] border ${
                            isWorking 
                              ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/15' 
                              : 'bg-rose-500/10 text-rose-400 border-rose-500/15'
                          }`}>
                            {item.workingStatus}
                          </span>
                          {isWorking && item.workingSubStatus && (
                            <span className="block text-[9px] text-slate-500 font-bold bg-slate-950 px-1 py-0.5 rounded text-center max-w-[80px]">
                              {item.workingSubStatus}
                            </span>
                          )}
                          {!isWorking && item.nonWorkingSubStatus && (
                            <span className="block text-[9px] text-rose-400 font-bold bg-rose-500/5 px-1 py-0.5 rounded text-center border border-rose-500/10">
                              {item.nonWorkingSubStatus}
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="px-4 py-3 text-slate-300 font-medium">{item.issueTo || "-"}</td>
                      <td className="px-4 py-3 text-slate-400">{item.designation || "-"}</td>
                      <td className="px-4 py-3 text-slate-400">{item.issuedDate || "-"}</td>
                      <td className="px-4 py-3 text-slate-400 italic max-w-xs truncate" title={item.remarks || ""}>{item.remarks || "-"}</td>
                      {isWriteAllowed && (
                        <td className="px-4 py-3 text-center">
                          <div className="inline-flex gap-1">
                            <button
                              onClick={() => handleEditInitiate(item)}
                              className="bg-amber-600/20 hover:bg-amber-600 border border-amber-500/30 hover:border-transparent text-amber-400 hover:text-white p-1.5 rounded-lg transition-all cursor-pointer active:scale-95"
                              title="Edit Record"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            {(isSuperAdmin || isWriteAllowed) && (
                              <button
                                onClick={() => {
                                  if (confirmDeleteId === item.timestampId) {
                                    onItemDelete(item.timestampId);
                                    setConfirmDeleteId(null);
                                  } else {
                                    setConfirmDeleteId(item.timestampId);
                                  }
                                }}
                                className={`transition-all cursor-pointer active:scale-95 flex items-center gap-1.5 p-1.5 rounded-lg border ${
                                  confirmDeleteId === item.timestampId
                                    ? "bg-rose-600 text-white border-transparent text-[10px] font-bold px-2 py-1"
                                    : "bg-rose-600/20 hover:bg-rose-600 border-rose-500/30 hover:border-transparent text-rose-400 hover:text-white"
                                }`}
                                title={confirmDeleteId === item.timestampId ? "Click again to confirm delete" : "Delete Record"}
                              >
                                {confirmDeleteId === item.timestampId ? (
                                  <span className="font-bold flex items-center gap-1"><Trash2 className="w-3 h-3 animate-bounce" /> Delete?</span>
                                ) : (
                                  <Trash2 className="w-3.5 h-3.5" />
                                )}
                              </button>
                            )}
                          </div>
                        </td>
                      )}
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Navigation Controls Bar */}
        {pageSize !== "All" && totalPages > 1 && (
          <div className="flex flex-wrap items-center justify-between bg-slate-900/60 border border-slate-800 px-4 py-2.5 rounded-xl text-xs gap-3 shadow-md">
            <div className="text-slate-400 font-medium">
              Showing <span className="text-white font-bold">{totalRecords === 0 ? 0 : (currentPage - 1) * (pageSize as number) + 1}</span> to <span className="text-white font-bold">{Math.min(currentPage * (pageSize as number), totalRecords)}</span> of <span className="text-blue-400 font-extrabold">{totalRecords}</span> records
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="px-3 py-1 bg-slate-800 hover:bg-slate-700 disabled:opacity-30 disabled:cursor-not-allowed border border-slate-700 text-slate-200 font-bold rounded-lg transition active:scale-95 cursor-pointer"
              >
                ◀ Previous
              </button>

              <span className="px-3 py-1 bg-slate-950 border border-slate-800 rounded-lg text-slate-300 font-bold">
                Page <span className="text-blue-400 font-black">{currentPage}</span> of <span className="text-slate-100">{totalPages}</span>
              </span>

              <button
                type="button"
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                className="px-3 py-1 bg-slate-800 hover:bg-slate-700 disabled:opacity-30 disabled:cursor-not-allowed border border-slate-700 text-slate-200 font-bold rounded-lg transition active:scale-95 cursor-pointer"
              >
                Next ▶
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Printable Specific Layout Stamps */}
      <div className="hidden print:hidden justify-end pt-12 pb-6">
        <div className="border-2 border-dashed border-slate-300 p-4 rounded-lg text-center w-80 bg-white text-slate-950 shadow-sm leading-normal">
          <div className="h-16 border-b border-slate-300 flex items-center justify-center text-xs text-slate-400 italic"></div>
          <div className="pt-3 font-bold text-sm tracking-wide text-slate-900 uppercase">
            {currentNodeLocation.startsWith("REC") ? "Regional" : "District"} Election Commissioner
          </div>
          <div className="text-xs text-slate-600 font-medium mt-1">
            {currentNodeLocation.startsWith("REC") 
              ? `${currentNodeLocation.replace(/REC|DEC/gi, "").trim()} Division`
              : currentNodeLocation.replace(/REC|DEC/gi, "").trim()}
          </div>
        </div>
      </div>

      {/* EXQUISITE SUCCESS NOTIFICATION DIALOG POPUP */}
      {saveSuccessMsg && (
        <div id="saveSuccessModal" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-sm animate-fade-in print:hidden" onClick={() => setSaveSuccessMsg(null)}>
          <div className="bg-slate-900 border border-emerald-500/30 rounded-2xl p-6 max-w-sm w-full shadow-2xl text-center space-y-4 animate-scale-up" onClick={(e) => e.stopPropagation()}>
            <div className="w-16 h-16 bg-emerald-500/10 text-emerald-400 rounded-full flex items-center justify-center mx-auto border border-emerald-500/20">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-100">Submitted Successfully</h3>
              <p className="text-sm text-slate-350 mt-2 font-medium">{saveSuccessMsg}</p>
            </div>
            <div className="text-[10px] text-slate-500 border-t border-slate-800/80 pt-2 flex items-center justify-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
              Automatically closing...
            </div>
          </div>
        </div>
      )}

      {/* MASTERFUL ECP WORLD-CLASS PRINT PREVIEW REPORT DIALOG MODAL */}
      {showPrintPreviewModal && createPortal(
        <div 
          id="printReportModalOverlay" 
          onClick={(e) => {
            if ((e.target as HTMLElement).id === "printReportModalOverlay") {
              setShowPrintPreviewModal(false);
            }
          }}
          className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md overflow-y-auto p-4 md:p-8 flex items-start justify-center print:static print:bg-white print:p-0 print:overflow-visible"
        >
          {/* Always-visible persistent Floating Close Button at top-right corner */}
          <button
            type="button"
            onClick={() => setShowPrintPreviewModal(false)}
            className="fixed top-4 right-4 z-[60] bg-rose-600 hover:bg-rose-500 active:bg-rose-700 text-white font-bold p-2.5 rounded-full shadow-2xl flex items-center justify-center cursor-pointer transition active:scale-95 print:hidden border-2 border-white/20 hover:scale-105"
            title="Close Print Preview (Esc)"
            aria-label="Close Print Preview"
          >
            <X className="w-5 h-5 text-white" />
          </button>

          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-5xl w-full shadow-2xl overflow-hidden print:border-none print:shadow-none print:bg-white my-auto md:my-4">
            
            {/* Modal Header Controls (Sticky top bar, Invisible When Printed) */}
            <div className="bg-slate-950 px-6 py-4 border-b border-slate-800 flex flex-col md:flex-row md:items-center md:justify-between gap-3 print:hidden sticky top-0 z-30 shadow-md">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                  <Printer className="w-4 h-4 text-emerald-400" /> Official Inventory Print Preview
                </h3>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Location: <span className="text-emerald-400 font-bold">{currentNodeLocation}</span>
                </p>
              </div>
              
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={handleSavePdf}
                  disabled={isSavingPdf}
                  className="bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-black px-4 py-2 rounded-xl flex items-center gap-1.5 cursor-pointer shadow-lg transition active:scale-98"
                  title="Export official A4 landscape PDF with all single-line columns"
                >
                  <FileDown className="w-4 h-4" /> {isSavingPdf ? "Generating PDF..." : "Save as PDF"}
                </button>
                <button
                  type="button"
                  onClick={() => triggerPrintDocument("printableLedgerDocumentContent")}
                  className="bg-sky-600 hover:bg-sky-500 active:bg-sky-700 text-white text-xs font-bold px-4 py-2 rounded-xl flex items-center gap-1.5 cursor-pointer shadow-lg shadow-sky-800/10 transition active:scale-98"
                >
                  <Printer className="w-4 h-4" /> Print Document
                </button>
                
                <button
                  type="button"
                  onClick={() => setShowPrintPreviewModal(false)}
                  className="bg-rose-600 hover:bg-rose-500 active:bg-rose-700 text-white text-xs font-bold px-4 py-2 rounded-xl cursor-pointer transition active:scale-95 flex items-center gap-1.5 shadow-md"
                >
                  <X className="w-4 h-4" /> Close Preview
                </button>
              </div>
            </div>

            {/* Printable Sheet Viewport Frame */}
            <div id="printableLedgerDocumentContent" className="p-6 md:p-8 bg-white text-slate-950 min-h-[500px]">
              
              {/* Professional Office Header Identity Block */}
              <div className="border-b-2 border-slate-900 pb-3 mb-5 text-center w-full mx-auto">
                <div className="flex justify-center items-center gap-3 mb-2">
                  <img 
                    src="ecp logo1.jpeg" 
                    alt="ECP logo" 
                    onError={(e) => {
                      const target = e.currentTarget;
                      if (!target.src.includes("ecp_logo1.jpeg") && !target.src.includes("ecp%20logo1.jpeg")) {
                        target.src = "ecp_logo1.jpeg";
                      } else if (!target.src.includes("ecp_logo.jpg")) {
                        target.src = "ecp_logo.jpg";
                      }
                    }}
                    className="w-14 h-14 object-contain rounded-full bg-white p-0.5 border border-slate-300 shadow-sm"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <h1 className="text-xl md:text-2xl font-black uppercase tracking-wider text-slate-950 text-center mx-auto my-1">
                  {(() => {
                    const locStr = currentNodeLocation || "KOHAT";
                    const trimmed = locStr.replace(/REC|DEC/gi, '').trim().toUpperCase() || 'KOHAT';
                    if (locStr.toUpperCase().startsWith('REC')) {
                      return `REGIONAL ELECTION COMMISSIONER, ${trimmed}`;
                    } else if (locStr.toUpperCase().startsWith('DEC')) {
                      return `DISTRICT ELECTION COMMISSIONER, ${trimmed}`;
                    } else {
                      return `ELECTION COMMISSIONER, ${trimmed}`;
                    }
                  })()}
                </h1>
                
                <div className="flex flex-wrap items-center justify-between gap-2 mt-3 pt-2 border-t border-slate-200 text-xs text-slate-700 font-medium px-1">
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-slate-950 uppercase tracking-wide text-[10px]">Report Type:</span>
                    <span className="text-slate-900 font-semibold">{currentTab === "IT" ? "IT Equipment Inventory Ledger" : currentTab === "Furniture" ? "Furniture Asset Ledger" : "General Inventory Asset Ledger"}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-slate-950 uppercase tracking-wide text-[10px]">Date & Time of Generation:</span>
                    <span className="text-slate-900 font-semibold">{new Date().toLocaleString('en-US', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true })}</span>
                  </div>
                </div>
              </div>

              {/* COMBINATION BLOCK: Live Summary Dashboard metrics layout matches report category */}
              <div className="mb-6">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  
                  <div className="bg-slate-50 border border-slate-250 p-3 rounded-lg">
                    <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Total Stock Pool</div>
                    <div className="text-xl font-extrabold text-slate-950 mt-1 flex items-baseline gap-1.5">
                      <span>{getSumQty(scopeData)}</span>
                      <span className="text-xs font-semibold text-slate-600">
                        ({scopeData.length} {scopeData.length === 1 ? 'record' : 'records'})
                      </span>
                    </div>
                  </div>

                  <div className="bg-slate-50 border border-slate-250 p-3 rounded-lg">
                    <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Working (Issued)</div>
                    <div className="text-xl font-extrabold text-slate-950 mt-1 text-emerald-700">
                      {getSumQty(scopeData.filter(i => i.workingStatus === "Working" && i.workingSubStatus === "Issued"))}
                    </div>
                  </div>

                  <div className="bg-slate-50 border border-slate-250 p-3 rounded-lg">
                    <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Working (In-Stock)</div>
                    <div className="text-xl font-extrabold text-slate-950 mt-1 text-blue-700">
                      {getSumQty(scopeData.filter(i => i.workingStatus === "Working" && i.workingSubStatus === "In-stock"))}
                    </div>
                  </div>

                  <div className="bg-slate-50 border border-slate-250 p-3 rounded-lg">
                    <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wide flex justify-between items-center">
                      <span>Non-Working Conditions</span>
                      <span className="text-[8px] font-bold bg-rose-100 text-rose-800 px-1 py-0.2 rounded border border-rose-300">ALERT</span>
                    </div>
                    <div className="text-xl font-extrabold text-rose-700 mt-1">
                      {getSumQty(scopeData.filter(i => i.workingStatus === "Non-Working"))}
                    </div>
                    <div className="text-[8px] text-slate-600 mt-1 flex justify-between border-t border-dashed border-slate-300 pt-1">
                      <span>Repair: <strong>{getSumQty(scopeData.filter(i => i.workingStatus === "Non-Working" && (i.nonWorkingSubStatus || '').toLowerCase().includes("repair")))}</strong></span>
                      <span>Condemn: <strong>{getSumQty(scopeData.filter(i => i.workingStatus === "Non-Working" && (i.nonWorkingSubStatus || '').toLowerCase().includes("condemn")))}</strong></span>
                    </div>
                  </div>

                </div>
              </div>

              {/* COMBINATION BLOCK: Category tally counters from Live Asset Category Stock Feed */}
              <div className="mb-6">
                <div className="flex flex-wrap gap-2 pt-1">
                  {activeCategories.map(cat => {
                    const catItems = scopeData.filter(i => i.category.toLowerCase() === cat.toLowerCase());
                    const count = getSumQty(catItems);
                    return (
                      <div key={cat} className="bg-slate-100 border border-slate-300 flex items-center justify-between gap-3 px-3 py-1.5 rounded-lg text-xs font-semibold min-w-[120px]">
                        <span className="text-slate-800 capitalize font-medium">{cat}</span>
                        <span className="bg-white border border-slate-300 text-slate-950 font-black px-2 py-0.5 rounded text-[10px]">
                          {count}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* COMBINATION BLOCK: Combined dynamic search and output table matrix */}
              <div id="printableActiveLedgerTableArea" className="mb-6">
                <div className="text-xs font-black uppercase tracking-wider text-slate-500 mb-2 border-l-2 border-slate-600 pl-2 flex justify-between items-center print:hidden">
                  <span>Active Ledger Data Records List</span>
                  <span className="text-[9px] text-slate-600 normal-case italic font-medium">
                    Showing {sortedScopeData.length} records matching search filter matches
                  </span>
                </div>
                
                <div className="overflow-x-auto border border-slate-300 rounded-none mt-2">
                  <table className="w-full table-auto text-left text-[8.5px] text-slate-900 border-collapse border border-slate-300 whitespace-nowrap">
                    <thead className="bg-slate-100 border-b border-slate-300">
                      <tr>
                        <th className="px-1.5 py-1 font-bold border border-slate-300 text-center text-slate-900 w-[1%] whitespace-nowrap">Sr. #</th>
                        <th className="px-2 py-1.5 font-bold border border-slate-300 text-slate-900 whitespace-nowrap">Station</th>
                        <th className="px-2 py-1.5 font-bold border border-slate-300 text-slate-900 whitespace-nowrap">Asset Name</th>
                        <th className="px-2 py-1.5 font-bold border border-slate-300 text-slate-900 whitespace-nowrap">Serial / Reg No.</th>
                        <th className="px-2 py-1.5 font-bold border border-slate-300 text-slate-900 whitespace-nowrap">Model</th>
                        <th className="px-2 py-1.5 font-bold border border-slate-300 text-slate-900 whitespace-nowrap">Category</th>
                        {currentTab === "Furniture" && (
                          <th className="px-1.5 py-1 font-bold border border-slate-300 text-slate-900 text-center w-[1%] whitespace-nowrap">Qty</th>
                        )}
                        <th className="px-2 py-1.5 font-bold border border-slate-300 text-slate-900 whitespace-nowrap">Receiving Date</th>
                        <th className="px-2 py-1.5 font-bold border border-slate-300 text-slate-900 whitespace-nowrap">Condition Status</th>
                        <th className="px-2 py-1.5 font-bold border border-slate-300 text-slate-900 whitespace-nowrap">Issued Assignment To</th>
                        <th className="px-2 py-1.5 font-bold border border-slate-300 text-slate-900 whitespace-nowrap">Designation</th>
                        <th className="px-2 py-1.5 font-bold border border-slate-300 text-slate-900 whitespace-nowrap">
                          {currentTab === "Furniture" ? "Quantity Issued" : "Remarks"}
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-300">
                      {sortedScopeData.length === 0 ? (
                        <tr>
                          <td colSpan={currentTab === "Furniture" ? 12 : 11} className="px-4 py-8 text-center text-slate-500 italic border border-slate-300 bg-slate-50 whitespace-nowrap">
                            No matching active ledger dataset records found in export queue.
                          </td>
                        </tr>
                      ) : (
                        sortedScopeData.map((item, idx) => {
                          const isWorkingStatus = item.workingStatus === "Working";
                          return (
                            <tr key={item.timestampId} className="hover:bg-slate-50 bg-white">
                              <td className="px-1.5 py-1 font-extrabold border border-slate-300 text-slate-900 text-center w-[1%] whitespace-nowrap">{idx + 1}</td>
                              <td className="px-2 py-1 font-bold border border-slate-300 text-slate-900 whitespace-nowrap">{item.nodeLocation}</td>
                              <td className="px-2 py-1 font-semibold border border-slate-300 text-slate-900 whitespace-nowrap">{item.name}</td>
                              <td className="px-2 py-1 border border-slate-300 text-slate-800 font-mono text-[8px] whitespace-nowrap">{item.serial || '-'}</td>
                              <td className="px-2 py-1 border border-slate-300 text-slate-800 whitespace-nowrap">{item.model || '-'}</td>
                              <td className="px-2 py-1 border border-slate-300 capitalize text-slate-900 whitespace-nowrap">{item.category}</td>
                              {currentTab === "Furniture" && (
                                <td className="px-1.5 py-1 border border-slate-300 font-mono font-extrabold text-slate-900 text-center w-[1%] whitespace-nowrap">{item.quantity || 1}</td>
                              )}
                              <td className="px-2 py-1 border border-slate-300 text-slate-700 whitespace-nowrap font-mono text-[8.5px]">{item.date || '-'}</td>
                              <td className="px-2 py-1 border border-slate-300 whitespace-nowrap">
                                <div className="flex items-center gap-1 whitespace-nowrap">
                                  <span className={`text-[8px] font-extrabold px-1.5 py-0.5 rounded border ${
                                    isWorkingStatus 
                                      ? 'bg-emerald-50 text-emerald-800 border-emerald-300' 
                                      : 'bg-rose-50 text-rose-800 border-rose-300'
                                  }`}>
                                    {item.workingStatus}
                                  </span>
                                  {item.workingSubStatus && (
                                    <span className="text-[7.5px] text-slate-700 bg-slate-100 border border-slate-200 px-1 py-0.5 rounded font-medium whitespace-nowrap">
                                      {item.workingSubStatus}
                                    </span>
                                  )}
                                  {item.nonWorkingSubStatus && (
                                    <span className="text-[7.5px] text-rose-900 bg-rose-50 border border-rose-200 px-1 py-0.5 rounded font-medium whitespace-nowrap">
                                      {item.nonWorkingSubStatus}
                                    </span>
                                  )}
                                </div>
                              </td>
                              <td className="px-2 py-1 border border-slate-300 text-slate-900 font-semibold whitespace-nowrap">{item.issueTo || '-'}</td>
                              <td className="px-2 py-1 border border-slate-300 text-slate-800 whitespace-nowrap">{item.designation || '-'}</td>
                              <td className="px-2 py-1 border border-slate-300 text-slate-800 italic text-[8.5px] whitespace-nowrap">
                                {item.remarks || '-'}
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Verification signature section */}
              <div className="flex justify-end pt-8 mt-12 border-t border-dashed border-slate-300">
                <div className="border border-dashed border-slate-300 p-4 rounded-lg text-center w-80 bg-white text-slate-900 shadow-sm leading-normal">
                  <div className="h-14 border-b border-slate-200 flex items-center justify-center text-[10px] text-slate-400 italic"></div>
                  <div className="pt-2 font-black text-[11px] tracking-wide text-slate-900 uppercase">
                    {currentNodeLocation.startsWith("REC") ? "Regional" : "District"} Election Commissioner
                  </div>
                  <div className="text-[9px] text-slate-600 font-bold mt-0.5">
                    {currentNodeLocation.startsWith("REC") 
                      ? `${currentNodeLocation.replace(/REC|DEC/gi, "").trim()} Division` 
                      : currentNodeLocation.replace(/REC|DEC/gi, "").trim()}
                  </div>
                </div>
              </div>

            </div>

            {/* Modal Footer Controls */}
            <div className="bg-slate-950 px-6 py-4 border-t border-slate-800 flex items-center justify-end gap-2 print:hidden">
              <button
                type="button"
                onClick={handleSavePdf}
                disabled={isSavingPdf}
                className="bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold text-xs py-2 px-5 rounded-xl cursor-pointer transition active:scale-95 flex items-center gap-1.5 shadow-md"
                title="Save as A4 landscape PDF"
              >
                <FileDown className="w-4 h-4" /> {isSavingPdf ? "Generating..." : "Save as PDF"}
              </button>
              <button
                type="button"
                onClick={() => setShowPrintPreviewModal(false)}
                className="bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs py-2 px-5 rounded-xl cursor-pointer transition active:scale-95 flex items-center gap-1.5 shadow-md"
              >
                <X className="w-4 h-4" /> Close Preview
              </button>
              <button
                type="button"
                onClick={() => triggerPrintDocument("printableLedgerDocumentContent")}
                className="bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs py-2 px-5 rounded-xl flex items-center gap-1.5 cursor-pointer shadow-lg transition active:scale-98"
              >
                <Printer className="w-4 h-4" /> Print Document
              </button>
            </div>

          </div>
        </div>
      , document.body)}

      {downloadModalData.isOpen && (
        <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md z-50 flex items-center justify-center p-4 print:hidden">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg shadow-2xl shadow-slate-950/70 flex flex-col overflow-hidden max-h-[90vh]">
            <div className="p-6 border-b border-slate-800 flex justify-between items-center bg-slate-900/50">
              <h3 className="text-md font-bold text-white flex items-center gap-2">
                <Download className="w-5 h-5 text-amber-500 animate-bounce" /> Offline App & Backup Exporter
              </h3>
              <button 
                onClick={() => setDownloadModalData({ isOpen: false, html: "" })}
                className="text-slate-400 hover:text-white font-bold text-sm cursor-pointer"
              >
                ✕ Close
              </button>
            </div>
            
            <div className="p-6 space-y-5 overflow-y-auto text-xs leading-relaxed text-slate-300">
              <div className="p-3 bg-slate-950/50 rounded-xl border border-slate-800/80 space-y-2">
                <p className="font-semibold text-white">📦 What is this?</p>
                <p className="text-slate-400">
                  This exports a fully dynamic, self-contained single-file HTML version of the ECP Asset Inventory application pre-seeded with all <strong>{allLocationData.length}</strong> currently loaded inventory items.
                </p>
              </div>

              {/* Cookie block specific warning */}
              {isCookieBlocked && (
                <div className="p-3.5 bg-rose-500/10 border border-rose-500/20 rounded-xl space-y-2 text-rose-200">
                  <p className="font-extrabold flex items-center gap-1.5 text-xs text-rose-400">
                    ⚠️ Browser Security Cookie Block Detected!
                  </p>
                  <p className="text-[11px] leading-relaxed text-slate-300">
                    Your web browser is blocking the security session cookies required by the preview server proxy (very common in <strong>Safari, iOS devices, or Private/Incognito tabs</strong>). This causes standard server downloads to fail or download raw login error screens.
                  </p>
                  <p className="text-[11px] font-bold text-amber-200 bg-slate-950/60 p-2.5 rounded border border-rose-500/10">
                    💡 <strong>How to download instantly:</strong> Click the <strong>"Open in new tab"</strong> button at the top-right of your preview screen (or reload this page in a direct browser tab). Once open in its own tab, download options will build and save 100% perfectly with no blocks!
                  </p>
                </div>
              )}

              <div className="p-3.5 bg-amber-500/10 rounded-xl border border-amber-500/20 space-y-1.5">
                <p className="font-bold text-amber-200 flex items-center gap-1.5">⚠️ Crucial Browser Preview Notice:</p>
                <p className="text-slate-300 text-[11px] leading-relaxed">
                  Because this application is running inside a <strong>sandboxed preview iframe</strong>, web browsers often block direct file downloads (Option 1) silently or serve stale cache files.
                </p>
                <p className="text-slate-300 text-[11px] font-medium leading-relaxed bg-slate-950/50 p-2 rounded border border-slate-800/80 mt-1">
                  💡 <strong>To guarantee a perfect download:</strong> Open the live preview in a <strong>New Tab</strong> using the arrow icon at the top right of the preview pane, then download the HTML file there! Alternatively, use <strong>Option 2 (Copy Code)</strong> to save it instantly.
                </p>
              </div>

              <div className="space-y-3">
                <h4 className="font-extrabold text-slate-200">Choose an Export Method:</h4>
                
                {/* Method 1: Try Direct Download */}
                <div className="border border-slate-800 bg-slate-950/30 rounded-xl p-4 space-y-3">
                  <div className="flex items-start gap-2">
                    <span className="bg-amber-500/10 text-amber-400 px-2 py-0.5 rounded text-[10px] font-bold font-mono">Option 1</span>
                    <div>
                      <p className="font-bold text-white">Download Standalone index.html File (Recommended for GitHub Pages)</p>
                      <p className="text-slate-400 text-[11px]">Downloads a single, compiled <code className="text-amber-400">index.html</code> file with the absolute latest code representing your current preview. Upload this file directly to your GitHub repository to host it with GitHub Pages instantly!</p>
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      try {
                        const blob = new Blob([downloadModalData.html], { type: 'text/html' });
                        const url = URL.createObjectURL(blob);
                        const link = document.createElement('a');
                        link.href = url;
                        link.download = 'index.html';
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                        URL.revokeObjectURL(url);
                      } catch (e) {
                        alert("File download block encountered. Please use Option 2 below!");
                      }
                    }}
                    className="w-full bg-amber-600 hover:bg-amber-500 text-slate-950 font-black py-2.5 px-4 rounded-xl transition cursor-pointer text-center text-xs flex items-center justify-center gap-1.5"
                  >
                    <Download className="w-4 h-4" /> Save as index.html (GitHub-Ready)
                  </button>
                </div>

                {/* Method 2: Copy to Clipboard Fallback */}
                <div className="border border-slate-800 bg-slate-950/30 rounded-xl p-4 space-y-3">
                  <div className="flex items-start gap-2">
                    <span className="bg-blue-500/10 text-blue-400 px-2 py-0.5 rounded text-[10px] font-bold font-mono">Option 2</span>
                    <div>
                      <p className="font-bold text-white">Copy Code to Clipboard</p>
                      <p className="text-slate-400 text-[11px]">Copy the fully compiled standalone source code and paste it manually into a local file named <code className="text-amber-400">index.html</code>.</p>
                    </div>
                  </div>
                  <button
                    onClick={async () => {
                      try {
                        await navigator.clipboard.writeText(downloadModalData.html);
                        setCopiedHtml(true);
                        setTimeout(() => setCopiedHtml(false), 3000);
                      } catch (e) {
                        alert("Failed to copy automatically. Please try manual copy.");
                      }
                    }}
                    className={`w-full py-2.5 px-4 rounded-xl font-bold transition cursor-pointer text-center text-xs flex items-center justify-center gap-1.5 ${
                      copiedHtml 
                        ? "bg-emerald-600 text-white" 
                        : "bg-slate-800 hover:bg-slate-700 text-white border border-slate-700"
                    }`}
                  >
                    {copiedHtml ? (
                      <>✨ Copied Successfully!</>
                    ) : (
                      <>Copy Entire HTML Source Code</>
                    )}
                  </button>
                  {copiedHtml && (
                    <div className="p-3 bg-emerald-500/5 border border-emerald-500/20 rounded-lg text-emerald-400 text-[11px] animate-fade-in">
                      💡 <strong>Next steps:</strong> Open any text editor (like Notepad or VS Code), paste the code (<kbd>Ctrl+V</kbd> or <kbd>Cmd+V</kbd>), and save the file with the name <strong>index.html</strong>. You can then double click it to run it completely offline or host it anywhere!
                    </div>
                  )}
                </div>

                {/* Method 3: Download Complete Project ZIP */}
                <div className="border border-slate-800 bg-slate-950/30 rounded-xl p-4 space-y-3">
                  <div className="flex items-start gap-2">
                    <span className="bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded text-[10px] font-bold font-mono">Option 3</span>
                    <div>
                      <p className="font-bold text-white">Download Complete Project ZIP (.zip)</p>
                      <p className="text-slate-400 text-[11px]">Downloads a complete, standard zip package containing the full source code (React, Tailwind, Vite configurations, etc.). The root <code className="text-amber-400">index.html</code> inside this ZIP is the complete, pre-compiled standalone application (~300KB+) ready for instant offline use and direct GitHub Pages deployment!</p>
                    </div>
                  </div>
                  <button
                    onClick={async () => {
                      try {
                        let response = await fetch('/api/download-project-zip', {
                          method: 'POST',
                          headers: { 'Content-Type': 'application/json' },
                          body: JSON.stringify({ html: downloadModalData.html })
                        });
                        if (!response.ok) {
                          response = await fetch('/api/download-project-zip');
                        }
                        if (!response.ok) {
                          throw new Error('Failed to download project zip');
                        }
                        const contentType = response.headers.get("content-type") || "";
                        if (contentType.includes("text/html")) {
                          const text = await response.clone().text();
                          if (text.includes("blocking a required security cookie") || text.includes("Safari") || text.includes("DOCTYPE")) {
                            throw new Error("auth_cookie_blocked");
                          }
                        }
                        const blob = await response.blob();
                        const url = URL.createObjectURL(blob);
                        const link = document.createElement('a');
                        link.href = url;
                        link.download = 'ECP_Asset_Inventory_Project.zip';
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                        URL.revokeObjectURL(url);
                      } catch (e: any) {
                        console.error(e);
                        setIsCookieBlocked(true);
                        if (e.message === "auth_cookie_blocked") {
                          alert("⚠️ Security Cookie Blocked by Browser:\n\nBecause this preview is running in an iframe, your browser is blocking required authentication cookies (very common in Safari, iOS, or private browsing tabs).\n\nPlease click the 'Open in new tab' button at the top-right of your screen to open the app, then click download. It will work 100% perfectly there!");
                        } else {
                          alert("Failed to download project ZIP. Please try downloading from a New Tab.");
                        }
                      }
                    }}
                    className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-black py-2.5 px-4 rounded-xl transition cursor-pointer text-center text-xs flex items-center justify-center gap-1.5"
                  >
                    <Download className="w-4 h-4" /> Download Complete Project ZIP
                  </button>
                </div>
              </div>
            </div>

            <div className="p-4 bg-slate-950/40 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => setDownloadModalData({ isOpen: false, html: "" })}
                className="bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs px-4 py-2 rounded-xl transition cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
