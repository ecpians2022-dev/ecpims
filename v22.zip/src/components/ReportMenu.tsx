import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import * as XLSX from 'xlsx';
import { 
  FileSpreadsheet, Printer, Search, Filter, 
  CheckCircle2, AlertTriangle, Layers, Laptop, X,
  UserCheck, Building2, User, Users, Briefcase, FileDown
} from 'lucide-react';
import { InventoryItem } from '../types';
import { triggerPrintDocument, saveElementAsPDF } from '../utils/printHelper';

interface ReportMenuProps {
  currentTab: "IT" | "Furniture" | "Misc";
  currentNodeLocation: string;
  databaseStore: InventoryItem[];
  initialReportType?: "working" | "nonworking" | "person_office";
  onReportTypeChange?: (type: "working" | "nonworking" | "person_office") => void;
  initialWorkingSubFilter?: string;
  initialNonWorkingSubFilter?: string;
  isSuperAdmin?: boolean;
  isLightMode?: boolean;
}

export default function ReportMenu({
  currentTab,
  currentNodeLocation,
  databaseStore,
  initialReportType = "working",
  onReportTypeChange,
  initialWorkingSubFilter = "All",
  initialNonWorkingSubFilter = "All",
  isSuperAdmin = false,
  isLightMode = false
}: ReportMenuProps) {
  // Report type selection: "working" | "nonworking" | "person_office"
  const [selectedReport, setSelectedReport] = useState<"working" | "nonworking" | "person_office">(initialReportType);
  
  // Person / Office search state
  const [personOfficeQuery, setPersonOfficeQuery] = useState<string>("");
  const [searchTargetType, setSearchTargetType] = useState<"all" | "person" | "office">("all");
  const [personOfficeScope, setPersonOfficeScope] = useState<"all" | "current">("all");

  // Sub-filters
  const [workingSubFilter, setWorkingSubFilter] = useState<string>(initialWorkingSubFilter); // "All" | "Issued" | "In-stock"
  const [nonWorkingSubFilter, setNonWorkingSubFilter] = useState<string>(initialNonWorkingSubFilter); // "All" | "Needs to repair" | "Ready for condemnation"
  
  // Category Tab Filter: "All" | "IT" | "Furniture" | "Misc"
  const [categoryTabFilter, setCategoryTabFilter] = useState<string>("All");

  // Location Scope: "current" | "all"
  const [locationScope, setLocationScope] = useState<string>("current"); // "current" | "all"

  const [reportSearchQuery, setReportSearchQuery] = useState<string>("");
  const [showPrintModal, setShowPrintModal] = useState<boolean>(false);
  const [isSavingPdf, setIsSavingPdf] = useState<boolean>(false);

  const handleSavePdf = async () => {
    setIsSavingPdf(true);
    try {
      const cleanTitle = getReportTitle().replace(/[^a-zA-Z0-9_-]/g, '_');
      await saveElementAsPDF("printableReportDocumentContent", `ECP_${cleanTitle}_Report.pdf`);
    } finally {
      setIsSavingPdf(false);
    }
  };

  // Close print modal on Escape key press
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setShowPrintModal(false);
      }
    };
    if (showPrintModal) {
      window.addEventListener("keydown", handleKeyDown);
    }
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [showPrintModal]);

  // Category sorting state in report view
  const [reportCategorySortOrder, setReportCategorySortOrder] = useState<"none" | "asc" | "desc">("none");

  // Unique staff members (issueTo) list with item counts across database
  const staffMembersList = React.useMemo(() => {
    const map = new Map<string, number>();
    databaseStore.forEach(item => {
      const target = (item.issueTo || "").trim();
      if (
        target && 
        target !== "-" && 
        target.toLowerCase() !== "n/a" && 
        target.toLowerCase() !== "none" && 
        target.toLowerCase() !== "in stock" && 
        target.toLowerCase() !== "in-stock"
      ) {
        map.set(target, (map.get(target) || 0) + 1);
      }
    });
    return Array.from(map.entries())
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
  }, [databaseStore]);

  // Unique offices (nodeLocation) list with item counts across database
  const officesList = React.useMemo(() => {
    const map = new Map<string, number>();
    databaseStore.forEach(item => {
      const loc = (item.nodeLocation || "").trim();
      if (loc) {
        map.set(loc, (map.get(loc) || 0) + 1);
      }
    });
    return Array.from(map.entries())
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
  }, [databaseStore]);

  // Sync state with parent's header actions
  useEffect(() => {
    setSelectedReport(initialReportType);
  }, [initialReportType]);

  useEffect(() => {
    setWorkingSubFilter(initialWorkingSubFilter);
  }, [initialWorkingSubFilter]);

  useEffect(() => {
    setNonWorkingSubFilter(initialNonWorkingSubFilter);
  }, [initialNonWorkingSubFilter]);

  const handleReportToggle = (type: "working" | "nonworking" | "person_office") => {
    setSelectedReport(type);
    if (type === "working") {
      setNonWorkingSubFilter("All");
    } else if (type === "nonworking") {
      setWorkingSubFilter("All");
    }
    if (onReportTypeChange) {
      onReportTypeChange(type);
    }
  };

  // Get matching filtered data
  const getFilteredReportData = (): InventoryItem[] => {
    let items = [...databaseStore];
    
    const isAllOffices = !currentNodeLocation || 
      currentNodeLocation.trim().toLowerCase() === "all offices" || 
      currentNodeLocation.trim().toLowerCase() === "all";

    if (selectedReport === "person_office") {
      // Location scope for person/office
      if (personOfficeScope === "current" && !isAllOffices) {
        items = items.filter(
          item => (item.nodeLocation || "").trim().toLowerCase() === (currentNodeLocation || "").trim().toLowerCase()
        );
      }

      // Category Tab Filter
      if (categoryTabFilter !== "All") {
        items = items.filter(
          item => (item.tabContext || "").trim().toLowerCase() === (categoryTabFilter || "").trim().toLowerCase()
        );
      }

      // Query filter
      const q = (personOfficeQuery || "").trim().toLowerCase();
      if (q) {
        if (searchTargetType === "person") {
          items = items.filter(item => 
            (item.issueTo || "").toLowerCase().includes(q) ||
            (item.designation || "").toLowerCase().includes(q)
          );
        } else if (searchTargetType === "office") {
          items = items.filter(item => 
            (item.nodeLocation || "").toLowerCase().includes(q) ||
            (item.issueTo || "").toLowerCase().includes(q)
          );
        } else {
          items = items.filter(item => 
            (item.issueTo || "").toLowerCase().includes(q) ||
            (item.nodeLocation || "").toLowerCase().includes(q) ||
            (item.designation || "").toLowerCase().includes(q)
          );
        }
      } else {
        // Show all items that are issued to someone or have issueTo set
        items = items.filter(item => 
          item.issueTo && 
          item.issueTo.trim() !== "" && 
          item.issueTo.trim() !== "-" &&
          item.issueTo.toLowerCase() !== "in stock" &&
          item.issueTo.toLowerCase() !== "in-stock"
        );
      }

      return items;
    }

    // 1. Location scope
    if (locationScope === "current" && !isAllOffices) {
      items = items.filter(
        item => (item.nodeLocation || "").trim().toLowerCase() === (currentNodeLocation || "").trim().toLowerCase()
      );
    }

    // 2. Category Tab Filter (IT Equipment, Furniture Assets, Miscellaneous, or All)
    if (categoryTabFilter !== "All") {
      items = items.filter(
        item => (item.tabContext || "").trim().toLowerCase() === (categoryTabFilter || "").trim().toLowerCase()
      );
    }

    // 3. Report Type-specific filtering
    if (selectedReport === "working") {
      items = items.filter(item => item.workingStatus === "Working");
      if (workingSubFilter !== "All") {
        items = items.filter(item => item.workingSubStatus === workingSubFilter);
      }
    } else {
      items = items.filter(item => item.workingStatus === "Non-Working");
      if (nonWorkingSubFilter !== "All") {
        items = items.filter(item => 
          (item.nonWorkingSubStatus || "").toLowerCase() === nonWorkingSubFilter.toLowerCase() ||
          (nonWorkingSubFilter.toLowerCase().includes("condemn") && (item.nonWorkingSubStatus || "").toLowerCase().includes("condemn"))
        );
      }
    }

    return items;
  };

  const reportItems = getFilteredReportData();

  // Search filter implementation
  const searchedReportItems = reportItems.filter(item => {
    const query = reportSearchQuery.toLowerCase();
    return (
      item.name.toLowerCase().includes(query) ||
      (item.serial || "").toLowerCase().includes(query) ||
      (item.model || "").toLowerCase().includes(query) ||
      (item.nodeLocation || "").toLowerCase().includes(query) ||
      (item.category || "").toLowerCase().includes(query) ||
      (item.remarks || "").toLowerCase().includes(query) ||
      (item.issueTo || "").toLowerCase().includes(query)
    );
  });

  // Category sorted final list
  const finalReportItems = React.useMemo(() => {
    if (reportCategorySortOrder === "none") return searchedReportItems;
    return [...searchedReportItems].sort((a, b) => {
      const catA = (a.category || a.tabContext || "").toLowerCase();
      const catB = (b.category || b.tabContext || "").toLowerCase();
      if (catA < catB) return reportCategorySortOrder === "asc" ? -1 : 1;
      if (catA > catB) return reportCategorySortOrder === "asc" ? 1 : -1;
      return 0;
    });
  }, [searchedReportItems, reportCategorySortOrder]);

  // KPI Statistics counts
  const totalReportCount = reportItems.length;
  const workingCount = reportItems.filter(item => item.workingStatus === "Working").length;
  const nonWorkingCount = reportItems.filter(item => item.workingStatus === "Non-Working").length;

  // Helper to format official header title based on location
  const getReportHeaderTitle = (location?: string): string => {
    const locStr = location || "";
    const locUpper = locStr.toUpperCase();
    if (locUpper === "ALL OFFICES" || locUpper === "ALL") {
      return "ELECTION COMMISSION OF PAKISTAN, KOHAT DIVISION (ALL OFFICES)";
    }
    let distName = locStr.replace(/REC|DEC/gi, "").trim();
    if (!distName) distName = "KOHAT";

    if (locUpper.startsWith("REC")) {
      return `REGIONAL ELECTION COMMISSIONER, ${distName.toUpperCase()}`;
    } else if (locUpper.startsWith("DEC")) {
      return `DISTRICT ELECTION COMMISSIONER, ${distName.toUpperCase()}`;
    } else {
      return `ELECTION COMMISSIONER, ${distName.toUpperCase()}`;
    }
  };

  const getReportTitle = (): string => {
    const locLabel = currentNodeLocation || "REC Kohat";

    const catTag = categoryTabFilter === "All"
      ? "All"
      : categoryTabFilter === "IT"
      ? "IT"
      : categoryTabFilter === "Furniture"
      ? "Furniture"
      : "Misc";

    if (selectedReport === "person_office") {
      const targetLabel = personOfficeQuery ? personOfficeQuery : "All Staff Members & Offices";
      const scopeLabel = personOfficeScope === "all" ? "All Stations" : locLabel;
      return `Issued Assets Statement: "${targetLabel}" - ${scopeLabel} (${catTag})`;
    } else if (selectedReport === "working") {
      const subTag = workingSubFilter !== "All" ? ` (${workingSubFilter})` : "";
      return `Working Assets${subTag} - ${locLabel} (${catTag})`;
    } else {
      const subTag = nonWorkingSubFilter !== "All" ? ` (${nonWorkingSubFilter})` : "";
      return `Non-Working Assets${subTag} - ${locLabel} (${catTag})`;
    }
  };

  // Excel exporter
  const handleExportExcel = () => {
    if (reportItems.length === 0) {
      alert("No data available to export.");
      return;
    }
    const formattedData = reportItems.map((item, idx) => {
      const tabPrefix = item.tabContext === "IT" ? "IT" : item.tabContext === "Furniture" ? "Fur" : "Mis";
      const formattedAssetId = item.id || `${tabPrefix}${String(idx + 1).padStart(4, '0')}`;
      return {
        "S.No": idx + 1,
        "Asset ID": formattedAssetId,
        "Station Location": item.nodeLocation,
      "Category Tab": item.tabContext,
      "Asset Subtype": item.category,
      "Asset Name": item.name,
      "Model Specifications": item.model || "",
      "Serial/Tag Number": item.serial || "",
      "Working Status": item.workingStatus,
      "Allocation Type": item.workingSubStatus || "",
      "Condition Reason": item.nonWorkingSubStatus || "",
      "Issued To": item.issueTo || "",
      "Designation": item.designation || "",
      "Receiving Date": item.date || "",
      "Remarks": item.remarks || ""
    };
    });

    const worksheet = XLSX.utils.json_to_sheet(formattedData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Inventory Report");
    XLSX.writeFile(workbook, `ECP_Report_${getReportTitle().replace(/[^a-zA-Z0-9]/g, '_')}.xlsx`);
  };

  const handlePrint = () => {
    setShowPrintModal(true);
    setTimeout(() => {
      triggerPrintDocument("printableReportDocumentContent");
    }, 150);
  };

  return (
    <div className="space-y-6">
      {/* Simplify Menu Selector Panel */}
      <div className="bg-slate-900/35 backdrop-blur-xl border border-slate-800/60 rounded-xl p-5 shadow-xl flex flex-col xl:flex-row justify-between items-start xl:items-center gap-4 animate-fadeIn">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <FileSpreadsheet className="w-5 h-5 text-cyan-400" />
            <h3 className="text-sm font-black uppercase tracking-wider text-white">
              {currentNodeLocation} ----- Stock Report
            </h3>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3 w-full xl:w-auto">
          {/* Station location indicator */}
          <div className="flex items-center bg-slate-950/45 backdrop-blur-sm p-1.5 px-3 rounded-xl border border-slate-800/60 text-xs text-cyan-400 font-extrabold">
            <span>Station: {currentNodeLocation}</span>
          </div>

          {/* Report Selection Tab Switcher */}
          <div className="flex items-center bg-slate-950/45 backdrop-blur-sm p-1 rounded-xl border border-slate-800/60 text-xs font-bold">
            <button
              onClick={() => handleReportToggle("working")}
              className={`px-3.5 py-2 rounded-lg transition-all cursor-pointer ${
                selectedReport === "working"
                  ? "bg-emerald-600/90 text-white shadow-md font-black"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              Working Report
            </button>
            <button
              onClick={() => handleReportToggle("nonworking")}
              className={`px-3.5 py-2 rounded-lg transition-all cursor-pointer ${
                selectedReport === "nonworking"
                  ? "bg-rose-600/90 text-white shadow-md font-black"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              Non-Working Report
            </button>
            <button
              onClick={() => handleReportToggle("person_office")}
              className={`px-3.5 py-2 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                selectedReport === "person_office"
                  ? "bg-purple-600/90 text-white shadow-md font-black"
                  : "text-slate-400 hover:text-white"
              }`}
              title="Find and generate complete report of issued items for any staff member or office"
            >
              <UserCheck className="w-4 h-4 text-purple-300" />
              <span>Issued Assets (Staff / Office)</span>
            </button>
          </div>

          {/* DYNAMIC SUB-MENU SELECTORS */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Category Dropdown option for all report types */}
            <div className="flex items-center bg-cyan-950/30 border border-cyan-500/30 px-3 py-1.5 rounded-xl gap-2 animate-fadeIn">
              <span className="text-[10px] uppercase font-black text-cyan-400">Asset Category:</span>
              <select
                value={categoryTabFilter}
                onChange={(e) => setCategoryTabFilter(e.target.value)}
                className="bg-transparent text-xs text-cyan-200 font-bold focus:outline-none focus:ring-0 cursor-pointer border-none py-0 pl-0 pr-6"
              >
                <option value="All" className="bg-slate-950 text-slate-200 font-bold">All Categories</option>
                <option value="IT" className="bg-slate-950 text-slate-200 font-bold">IT Equipment</option>
                <option value="Furniture" className="bg-slate-950 text-slate-200 font-bold">Furniture Assets</option>
                <option value="Misc" className="bg-slate-950 text-slate-200 font-bold">Miscellaneous</option>
              </select>
            </div>

            {/* Category Order Reorder Button */}
            <div className="flex items-center bg-amber-950/30 border border-amber-500/30 px-3 py-1 rounded-xl gap-1.5 animate-fadeIn">
              <span className="text-[10px] uppercase font-black text-amber-400">Category Order:</span>
              <button
                type="button"
                onClick={() => setReportCategorySortOrder(prev => prev === "none" ? "asc" : prev === "asc" ? "desc" : "none")}
                className="bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 font-black px-2.5 py-1 rounded-lg text-xs cursor-pointer transition flex items-center gap-1"
                title="Reorder records by category (Printer, Computer, etc.)"
              >
                {reportCategorySortOrder === "none" && "Default ↕"}
                {reportCategorySortOrder === "asc" && "Ascending (A-Z) ▲"}
                {reportCategorySortOrder === "desc" && "Descending (Z-A) ▼"}
              </button>
            </div>

            {selectedReport === "working" && (
              /* Choose Allocation Type Dropdown */
              <div className="flex items-center bg-emerald-950/20 border border-emerald-500/20 px-3 py-1.5 rounded-xl gap-2 animate-fadeIn">
                <span className="text-[10px] uppercase font-black text-emerald-400">Allocation Type:</span>
                <select
                  value={workingSubFilter}
                  onChange={(e) => setWorkingSubFilter(e.target.value)}
                  className="bg-transparent text-xs text-emerald-200 font-bold focus:outline-none focus:ring-0 cursor-pointer border-none py-0 pl-0 pr-6"
                >
                  <option value="All" className="bg-slate-950 text-slate-200 font-bold">All Types</option>
                  <option value="Issued" className="bg-slate-950 text-slate-200 font-bold">Issued</option>
                  <option value="In-stock" className="bg-slate-950 text-slate-200 font-bold">In stock</option>
                </select>
              </div>
            )}

            {selectedReport === "nonworking" && (
              /* Choose Condition Reason Dropdown */
              <div className="flex items-center bg-rose-950/20 border border-rose-500/20 px-3 py-1.5 rounded-xl gap-2 animate-fadeIn">
                <span className="text-[10px] uppercase font-black text-rose-400">Condition Reason:</span>
                <select
                  value={nonWorkingSubFilter}
                  onChange={(e) => setNonWorkingSubFilter(e.target.value)}
                  className="bg-transparent text-xs text-rose-200 font-bold focus:outline-none focus:ring-0 cursor-pointer border-none py-0 pl-0 pr-6"
                >
                  <option value="All" className="bg-slate-950 text-slate-200 font-bold">All Reasons</option>
                  <option value="Needs to repair" className="bg-slate-950 text-slate-200 font-bold">Needs to repair</option>
                  <option value="Ready for condemnation" className="bg-slate-950 text-slate-200 font-bold">Ready for condemnation</option>
                </select>
              </div>
            )}
          </div>

          <button
            onClick={() => {
              setCategoryTabFilter("All");
              setWorkingSubFilter("All");
              setNonWorkingSubFilter("All");
              setReportSearchQuery("");
              setPersonOfficeQuery("");
            }}
            className="px-3.5 py-2 text-xs bg-slate-800/80 hover:bg-slate-700 text-slate-300 font-bold rounded-xl transition cursor-pointer select-none hover:scale-[1.02] active:scale-95"
          >
            Reset
          </button>
        </div>
      </div>

      {/* Staff Member / Office Issued Assets Search Bar Panel */}
      {selectedReport === "person_office" && (
        <div className="bg-purple-950/25 border border-purple-500/30 backdrop-blur-xl rounded-2xl p-5 shadow-xl space-y-4 animate-fadeIn">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-purple-500/20 text-purple-300 border border-purple-500/30">
                <UserCheck className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-black uppercase text-white tracking-wider flex items-center gap-2">
                  Find Issued Assets to Individual Staff Member or Office
                  {isSuperAdmin && (
                    <span className="text-[10px] bg-purple-500/20 text-purple-300 border border-purple-500/40 px-2 py-0.5 rounded-md font-mono">
                      Super Admin Mode
                    </span>
                  )}
                </h4>
                <p className="text-xs text-purple-300/80">
                  Enter staff member name, designation, or office location below to generate a comprehensive report of issued items.
                </p>
              </div>
            </div>

            {/* Scope selector: All Stations vs Current Station */}
            <div className="flex items-center bg-slate-950/60 p-1 rounded-xl border border-purple-500/30 text-xs font-bold">
              <button
                type="button"
                onClick={() => setPersonOfficeScope("all")}
                className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                  personOfficeScope === "all"
                    ? "bg-purple-600 text-white shadow-md font-black"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                All Offices (Provincial Scope)
              </button>
              <button
                type="button"
                onClick={() => setPersonOfficeScope("current")}
                className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                  personOfficeScope === "current"
                    ? "bg-purple-600 text-white shadow-md font-black"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                Current Station ({currentNodeLocation})
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-3 items-center">
            {/* Search Input Box */}
            <div className="md:col-span-8 relative">
              <Search className="absolute left-3.5 top-1/2 transform -translate-y-1/2 w-4 h-4 text-purple-400" />
              <input
                type="text"
                list="staffOfficeOptionsList"
                placeholder="Type staff member name (e.g. John, Computer Operator) or office (e.g. DEC Peshawar)..."
                value={personOfficeQuery}
                onChange={(e) => setPersonOfficeQuery(e.target.value)}
                className="w-full bg-slate-950/70 border border-purple-500/40 rounded-xl py-2.5 pl-10 pr-10 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-purple-400 focus:ring-1 focus:ring-purple-400/50 transition-all font-semibold"
              />
              {personOfficeQuery && (
                <button
                  type="button"
                  onClick={() => setPersonOfficeQuery("")}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-slate-400 hover:text-white cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
              <datalist id="staffOfficeOptionsList">
                {staffMembersList.map(s => (
                  <option key={s.name} value={s.name}>{s.name} ({s.count} items issued)</option>
                ))}
                {officesList.map(o => (
                  <option key={o.name} value={o.name}>{o.name} (Station Office)</option>
                ))}
              </datalist>
            </div>

            {/* Target Filter Type */}
            <div className="md:col-span-4 flex items-center gap-2">
              <select
                value={searchTargetType}
                onChange={(e) => setSearchTargetType(e.target.value as any)}
                className="w-full bg-slate-950/70 border border-purple-500/40 rounded-xl py-2.5 px-3 text-xs text-purple-200 font-bold focus:outline-none focus:border-purple-400 cursor-pointer"
              >
                <option value="all" className="bg-slate-950 text-white">Target: Staff Members & Offices</option>
                <option value="person" className="bg-slate-950 text-white">Target: Staff Members Only</option>
                <option value="office" className="bg-slate-950 text-white">Target: Offices / Locations Only</option>
              </select>
            </div>
          </div>

          {/* Quick Click Chips for Staff Members & Offices */}
          <div className="pt-2 border-t border-purple-500/20 space-y-2">
            <div className="text-[10px] font-black uppercase text-purple-300/80 tracking-wider flex items-center justify-between">
              <span>Quick Select Staff Member or Office:</span>
              {personOfficeQuery && (
                <button
                  type="button"
                  onClick={() => setPersonOfficeQuery("")}
                  className="text-purple-400 hover:underline cursor-pointer"
                >
                  Clear Selection
                </button>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-2 max-h-24 overflow-y-auto custom-scrollbar pr-1">
              {staffMembersList.length === 0 && officesList.length === 0 && (
                <span className="text-xs text-slate-500 italic">No issued asset records found in database.</span>
              )}

              {/* Staff chips */}
              {staffMembersList.slice(0, 10).map(staff => (
                <button
                  key={staff.name}
                  type="button"
                  onClick={() => setPersonOfficeQuery(staff.name)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 border ${
                    personOfficeQuery.toLowerCase() === staff.name.toLowerCase()
                      ? "bg-purple-600 text-white border-purple-400 shadow-md scale-105 font-black"
                      : "bg-slate-950/60 text-purple-200 border-purple-500/30 hover:bg-purple-900/40 hover:border-purple-400"
                  }`}
                >
                  <User className="w-3 h-3 text-purple-300" />
                  <span>{staff.name}</span>
                  <span className="bg-purple-950/80 text-purple-300 px-1.5 py-0.2 rounded text-[9px] border border-purple-500/30">
                    {staff.count}
                  </span>
                </button>
              ))}

              {/* Office chips */}
              {officesList.slice(0, 8).map(office => (
                <button
                  key={office.name}
                  type="button"
                  onClick={() => setPersonOfficeQuery(office.name)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 border ${
                    personOfficeQuery.toLowerCase() === office.name.toLowerCase()
                      ? "bg-blue-600 text-white border-blue-400 shadow-md scale-105 font-black"
                      : "bg-slate-950/60 text-blue-200 border-blue-500/30 hover:bg-blue-900/40 hover:border-blue-400"
                  }`}
                >
                  <Building2 className="w-3 h-3 text-blue-300" />
                  <span>{office.name}</span>
                  <span className="bg-blue-950/80 text-blue-300 px-1.5 py-0.2 rounded text-[9px] border border-blue-500/30">
                    {office.count}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Generated Report Display Table Section */}
      <div className={isLightMode ? "bg-white border-2 border-slate-200 rounded-2xl p-6 shadow-xs space-y-6 animate-fadeIn" : "bg-slate-800/90 backdrop-blur-xl border border-slate-700/80 rounded-2xl p-6 shadow-xl space-y-6 animate-fadeIn"}>
        {/* Header Summary Panel */}
        <div className={isLightMode ? "bg-slate-50 border-2 border-slate-200 p-5 rounded-xl flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6 shadow-xs" : "bg-slate-900/85 backdrop-blur-md p-5 rounded-xl border border-slate-700/70 flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6 shadow-md"}>
          <div className="space-y-1.5 flex-1">
            <div className={isLightMode ? "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-blue-100 border border-blue-200 text-blue-800 text-[10px] font-black uppercase tracking-wider" : "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-blue-500/15 border border-blue-500/30 text-blue-400 text-[10px] font-black uppercase tracking-wider"}>
              <Layers className="w-3.5 h-3.5" /> ECP Live Stock Report
            </div>
            <h2 className={isLightMode ? "text-lg font-black text-slate-900" : "text-lg font-black text-white"}>{getReportTitle()}</h2>
            <p className={isLightMode ? "text-xs text-slate-600 font-medium" : "text-xs text-slate-300 font-medium"}>
              Found <span className={isLightMode ? "text-blue-700 font-black" : "text-blue-400 font-black"}>{totalReportCount}</span> items matching selected specifications.
            </p>
          </div>

          {/* Metrics */}
          <div className="grid grid-cols-3 gap-3 shrink-0 w-full lg:w-auto font-mono">
            <div className={isLightMode ? "bg-white p-3.5 rounded-xl border-2 border-slate-200 text-center min-w-[105px] shadow-xs" : "bg-slate-800/90 p-3.5 rounded-xl border border-slate-700/80 text-center min-w-[105px] shadow-sm"}>
              <div className={isLightMode ? "text-[10px] font-extrabold text-slate-600 uppercase" : "text-[10px] font-bold text-slate-300 uppercase"}>Total Items</div>
              <div className={isLightMode ? "text-lg font-black text-slate-950 mt-1" : "text-xl font-black text-white mt-1"}>{totalReportCount}</div>
            </div>
            <div className={isLightMode ? "bg-emerald-50/90 p-3.5 rounded-xl border-2 border-emerald-200 text-center min-w-[105px] shadow-xs" : "bg-emerald-950/40 p-3.5 rounded-xl border border-emerald-600/40 text-center min-w-[105px] shadow-sm"}>
              <div className={isLightMode ? "text-[10px] font-extrabold text-emerald-800 uppercase" : "text-[10px] font-bold text-emerald-400 uppercase"}>Working</div>
              <div className={isLightMode ? "text-lg font-black text-emerald-700 mt-1" : "text-xl font-black text-emerald-300 mt-1"}>{workingCount}</div>
            </div>
            <div className={isLightMode ? "bg-rose-50/90 p-3.5 rounded-xl border-2 border-rose-200 text-center min-w-[105px] shadow-xs" : "bg-rose-950/40 p-3.5 rounded-xl border border-rose-600/40 text-center min-w-[105px] shadow-sm"}>
              <div className={isLightMode ? "text-[10px] font-extrabold text-rose-800 uppercase" : "text-[10px] font-bold text-rose-400 uppercase"}>Non-Working</div>
              <div className={isLightMode ? "text-lg font-black text-rose-700 mt-1" : "text-xl font-black text-rose-300 mt-1"}>{nonWorkingCount}</div>
            </div>
          </div>

          {/* Print and Export Buttons */}
          <div className="flex flex-wrap items-center gap-2 shrink-0 w-full lg:w-auto">
            <button
              onClick={handlePrint}
              className="bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-black px-4 py-2.5 rounded-lg flex items-center gap-1.5 cursor-pointer shadow-md transition-all flex-1 lg:flex-none justify-center active:scale-98 hover:scale-[1.02]"
            >
              <Printer className="w-4 h-4" /> Print
            </button>
            <button
              onClick={handleExportExcel}
              className="bg-blue-600 hover:bg-blue-500 text-white text-xs font-black px-4 py-2.5 rounded-lg flex items-center gap-1.5 cursor-pointer shadow-md transition-all flex-1 lg:flex-none justify-center active:scale-98 hover:scale-[1.02]"
            >
              <FileSpreadsheet className="w-4 h-4" /> Export Excel
            </button>
          </div>
        </div>

        {/* Quick Search */}
        <div className={isLightMode ? "bg-slate-50 border-2 border-slate-200 p-3 rounded-xl flex items-center justify-between gap-4 shadow-xs" : "bg-slate-900/80 backdrop-blur-md p-3 rounded-xl border border-slate-700/80 flex items-center justify-between gap-4"}>
          <span className={isLightMode ? "text-xs text-slate-700 font-bold hidden sm:inline-flex items-center gap-1" : "text-xs text-slate-300 font-bold hidden sm:inline-flex items-center gap-1"}>
            <Search className="w-4 h-4 text-blue-500" /> Filter results:
          </span>
          <div className="relative w-full sm:max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search matching report criteria..."
              value={reportSearchQuery}
              onChange={(e) => setReportSearchQuery(e.target.value)}
              className={isLightMode
                ? "w-full bg-white border border-slate-300 rounded-lg py-2 pl-9 pr-3 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-blue-500 shadow-xs"
                : "w-full bg-slate-950/70 border border-slate-700/80 rounded-lg py-2 pl-9 pr-3 text-xs text-slate-100 placeholder-slate-400 focus:outline-none focus:border-blue-400 transition-colors"
              }
            />
          </div>
        </div>

        {/* Report Grid Table */}
        <div className="overflow-x-auto rounded-lg border border-slate-800/60 bg-slate-950/20 backdrop-blur-sm custom-scrollbar">
          <table className="w-full text-left text-xs text-slate-300 divide-y divide-slate-855 min-w-[1100px]">
            <thead className="bg-slate-900/50 backdrop-blur-sm text-slate-200">
              <tr className="text-[10px] font-black uppercase tracking-wider text-slate-400">
                <th className="px-4 py-3 font-semibold text-blue-400">Station location</th>
                <th className="px-4 py-3 font-semibold text-cyan-400 font-mono">Asset ID</th>
                <th className="px-4 py-3 font-semibold">Category Tab</th>
                <th className="px-4 py-3 font-semibold">Asset Name</th>
                <th className="px-4 py-3 font-semibold">Serial / Stock Reg. P.No/ S.NO.</th>
                <th className="px-4 py-3 font-semibold">Model specifications</th>
                <th className="px-4 py-3 font-semibold">Subtype Category</th>
                <th className="px-4 py-3 font-semibold">Received From</th>
                <th className="px-4 py-3 font-semibold text-cyan-400">Receiving Date</th>
                <th className="px-4 py-3 font-semibold">Condition Status</th>
                <th className="px-4 py-3 font-semibold">Issued To</th>
                <th className="px-4 py-3 font-semibold">Designation</th>
                <th className="px-4 py-3 font-semibold">
                  Observations / Remarks
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-900/60 font-medium">
              {searchedReportItems.length === 0 ? (
                <tr>
                  <td colSpan={13} className="px-6 py-12 text-center text-slate-500 font-extrabold uppercase">
                    No matching registered assets located.
                  </td>
                </tr>
              ) : (
                searchedReportItems.map((item, idx) => {
                  const isWorking = item.workingStatus === "Working";
                  const tabPrefix = item.tabContext === "IT" ? "IT" : item.tabContext === "Furniture" ? "Fur" : "Mis";
                  const formattedAssetId = item.id || `${tabPrefix}${String(idx + 1).padStart(4, '0')}`;
                  return (
                    <tr key={item.timestampId} className="hover:bg-slate-850/30 transition text-slate-100">
                      <td className="px-4 py-3.5 font-bold text-slate-400 font-mono">{item.nodeLocation}</td>
                      <td className="px-4 py-3.5 font-mono font-black text-cyan-400 text-xs tracking-wider">{formattedAssetId}</td>
                      <td className="px-4 py-3.5 text-xs text-zinc-400 font-bold uppercase">{item.tabContext}</td>
                      <td className="px-4 py-3.5 text-white font-extrabold">{item.name}</td>
                      <td className="px-4 py-3.5 text-cyan-400 font-mono font-bold tracking-wide">{item.serial || '-'}</td>
                      <td className="px-4 py-3.5 text-slate-400">{item.model || '-'}</td>
                      <td className="px-4 py-3.5">
                        <span className="bg-slate-800 px-2 py-0.5 rounded text-amber-500 font-semibold">{item.category}</span>
                      </td>
                      <td className="px-4 py-3.5 text-slate-450">{item.receivedFrom || '-'}</td>
                      <td className="px-4 py-3.5 text-slate-400 font-mono text-xs">{item.date || '-'}</td>
                      <td className="px-4 py-3.5">
                        <div className="space-y-1">
                          <span className={`inline-flex items-center gap-1 font-bold px-2 py-0.5 rounded text-[10px] border ${
                            isWorking 
                              ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/15' 
                              : 'bg-rose-500/10 text-rose-400 border-rose-500/15'
                          }`}>
                            {item.workingStatus}
                          </span>
                          {isWorking && item.workingSubStatus && (
                            <span className="block text-[10px] text-slate-500 font-bold bg-slate-950 px-1 rounded text-center">
                              {item.workingSubStatus}
                            </span>
                          )}
                          {!isWorking && item.nonWorkingSubStatus && (
                            <span className="block text-[10px] text-rose-400 font-bold bg-rose-500/5 px-1 rounded text-center border border-rose-500/10">
                              {item.nonWorkingSubStatus}
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="px-4 py-3.5 text-slate-100 font-extrabold">{item.issueTo || '-'}</td>
                      <td className="px-4 py-3.5 text-slate-400 font-bold">{item.designation || '-'}</td>
                      <td className="px-4 py-3.5 text-slate-400 italic max-w-xs truncate" title={item.remarks || ""}>
                        {item.remarks || '-'}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* PRINT PREVIEW OVERLAY DIALOG */}
      {showPrintModal && createPortal(
        <div 
          id="printReportModalOverlay" 
          onClick={(e) => {
            if ((e.target as HTMLElement).id === "printReportModalOverlay") {
              setShowPrintModal(false);
            }
          }}
          className="fixed inset-0 z-50 bg-slate-950/95 backdrop-blur-md overflow-y-auto p-4 md:p-8 flex items-start justify-center print:static print:bg-white print:p-0 print:overflow-visible"
        >
          {/* Always-visible persistent Floating Close Button at top-right corner */}
          <button
            type="button"
            onClick={() => setShowPrintModal(false)}
            className="fixed top-4 right-4 z-[60] bg-rose-600 hover:bg-rose-500 active:bg-rose-700 text-white font-bold p-2.5 rounded-full shadow-2xl flex items-center justify-center cursor-pointer transition active:scale-95 print:hidden border-2 border-white/20 hover:scale-105"
            title="Close Print Preview (Esc)"
            aria-label="Close Print Preview"
          >
            <X className="w-5 h-5 text-white" />
          </button>

          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-5xl w-full shadow-2xl overflow-hidden print:border-none print:shadow-none print:bg-white my-auto md:my-4">
            
            {/* Toolbar controls (Sticky top bar) */}
            <div className="bg-slate-950 px-6 py-4 border-b border-slate-800 flex flex-col md:flex-row md:items-center md:justify-between gap-3 print:hidden sticky top-0 z-30 shadow-md">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                  <Printer className="w-4 h-4 text-cyan-400" /> Official Report Print / PDF Export
                </h3>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Scope: <span className="text-cyan-400 font-bold">{getReportTitle()}</span>
                </p>
              </div>
              
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={handleSavePdf}
                  disabled={isSavingPdf}
                  className="bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-black px-4 py-2 rounded-xl flex items-center gap-1.5 cursor-pointer shadow-lg transition active:scale-98"
                  title="Export official A4 landscape PDF with all single-line columns"
                >
                  <FileDown className="w-4 h-4" /> {isSavingPdf ? "Generating PDF..." : "Save as PDF"}
                </button>
                <button
                  type="button"
                  onClick={() => triggerPrintDocument("printableReportDocumentContent")}
                  className="bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-black px-4 py-2 rounded-xl flex items-center gap-1.5 cursor-pointer shadow-lg transition active:scale-98"
                >
                  <Printer className="w-4 h-4" /> Print Document
                </button>
                <button
                  type="button"
                  onClick={() => setShowPrintModal(false)}
                  className="bg-rose-600 hover:bg-rose-500 active:bg-rose-700 text-white text-xs font-bold px-4 py-2 rounded-xl cursor-pointer transition active:scale-95 flex items-center gap-1.5 shadow-md"
                >
                  <X className="w-4 h-4" /> Close Preview
                </button>
              </div>
            </div>

            {/* Print canvas */}
            <div id="printableReportDocumentContent" className="p-6 md:p-8 bg-white text-slate-950 min-h-[500px]">
              
              {/* Professional Office Header Identity Block */}
              <div className="border-b-2 border-slate-900 pb-3 mb-5 text-center w-full mx-auto">
                <div className="flex justify-center items-center gap-3 mb-2">
                  <img 
                    src="ecp logo1.jpeg" 
                    alt="ECP logo" 
                    onError={(e) => {
                      const target = e.currentTarget;
                      if (!target.src.includes("ecp_logo1.jpeg") && !target.src.includes("ecp%20logo1.jpeg")) {
                        target.src = "ecp_logo1.jpeg";
                      } else if (!target.src.includes("ecp_logo.jpg")) {
                        target.src = "ecp_logo.jpg";
                      }
                    }}
                    className="w-14 h-14 object-contain rounded-full bg-white p-0.5 border border-slate-300 shadow-sm"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <h1 className="text-xl md:text-2xl font-black uppercase tracking-wider text-slate-950 text-center mx-auto my-1">
                  {getReportHeaderTitle(currentNodeLocation)}
                </h1>

                <div className="flex flex-wrap items-center justify-between gap-2 mt-3 pt-2 border-t border-slate-200 text-xs text-slate-700 font-medium px-1">
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-slate-950 uppercase tracking-wide text-[10px]">Report Title:</span>
                    <span className="text-slate-900 font-semibold">{getReportTitle()}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-slate-950 uppercase tracking-wide text-[10px]">Date & Time of Generation:</span>
                    <span className="text-slate-900 font-semibold">{new Date().toLocaleString('en-US', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true })}</span>
                  </div>
                </div>
              </div>

              {/* Live Summary Dashboard metrics layout matching ledger print view */}
              <div className="mb-6">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <div className="bg-slate-50 border border-slate-200 p-3 rounded-lg">
                    <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Total Stock Pool</div>
                    <div className="text-xl font-extrabold text-slate-950 mt-1">{totalReportCount}</div>
                  </div>

                  <div className="bg-slate-50 border border-slate-200 p-3 rounded-lg">
                    <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Working (Issued)</div>
                    <div className="text-xl font-extrabold text-slate-950 mt-1 text-emerald-700">
                      {reportItems.filter(i => i.workingStatus === "Working" && i.workingSubStatus === "Issued").length}
                    </div>
                  </div>

                  <div className="bg-slate-50 border border-slate-200 p-3 rounded-lg">
                    <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Working (In-Stock)</div>
                    <div className="text-xl font-extrabold text-slate-950 mt-1 text-blue-700">
                      {reportItems.filter(i => i.workingStatus === "Working" && i.workingSubStatus === "In-stock").length}
                    </div>
                  </div>

                  <div className="bg-slate-50 border border-slate-200 p-3 rounded-lg">
                    <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wide flex justify-between items-center">
                      <span>Non-Working Conditions</span>
                      <span className="text-[8px] font-bold bg-rose-100 text-rose-800 px-1 py-0.2 rounded border border-rose-300">ALERT</span>
                    </div>
                    <div className="text-xl font-extrabold text-rose-700 mt-1">{nonWorkingCount}</div>
                    <div className="text-[8px] text-slate-600 mt-1 flex justify-between border-t border-dashed border-slate-300 pt-1">
                      <span>Repair: <strong>{reportItems.filter(i => i.workingStatus === "Non-Working" && (i.nonWorkingSubStatus || '').toLowerCase().includes("repair")).length}</strong></span>
                      <span>Condemn: <strong>{reportItems.filter(i => i.workingStatus === "Non-Working" && (i.nonWorkingSubStatus || '').toLowerCase().includes("condemn")).length}</strong></span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Category tally counters from Live Asset Category Stock Feed */}
              <div className="mb-6">
                <div className="flex flex-wrap gap-2 pt-1">
                  {Array.from(new Set(reportItems.map(i => i.category || "Uncategorized"))).map(cat => {
                    const count = reportItems.filter(i => (i.category || "Uncategorized").toLowerCase() === cat.toLowerCase()).length;
                    return (
                      <div key={cat} className="bg-slate-100 border border-slate-300 flex items-center justify-between gap-3 px-3 py-1.5 rounded-lg text-xs font-semibold min-w-[120px]">
                        <span className="text-slate-800 capitalize font-medium">{cat}</span>
                        <span className="bg-white border border-slate-300 text-slate-950 font-black px-2 py-0.5 rounded text-[10px]">
                          {count}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Records List */}
              <div className="mb-6">
                <div className="text-xs font-black uppercase tracking-wider text-slate-500 mb-2 pl-1">
                  Generated Inventory Records List ({finalReportItems.length} items found)
                </div>
                <div className="overflow-x-auto border border-slate-300 rounded-none mt-2">
                  <table className="w-full table-auto text-left text-[8.5px] text-slate-900 border-collapse border border-slate-300 whitespace-nowrap">
                    <thead className="bg-slate-100 border-b border-slate-300">
                      <tr>
                        <th className="px-1.5 py-1 font-bold border border-slate-300 text-center text-slate-900 w-[1%] whitespace-nowrap">Sr. #</th>
                        <th className="px-2 py-1 font-bold border border-slate-300 text-slate-900 whitespace-nowrap">Station</th>
                        <th className="px-2 py-1 font-bold border border-slate-300 text-slate-900 whitespace-nowrap">Category</th>
                        <th className="px-2 py-1 font-bold border border-slate-300 text-slate-900 whitespace-nowrap">Asset Name</th>
                        {(categoryTabFilter === "Furniture" || currentTab === "Furniture") && (
                          <th className="px-1.5 py-1 font-bold border border-slate-300 text-slate-900 text-center w-[1%] whitespace-nowrap">Qty</th>
                        )}
                        <th className="px-2 py-1 font-bold border border-slate-300 text-slate-900 whitespace-nowrap">Serial / Reg No.</th>
                        <th className="px-2 py-1 font-bold border border-slate-300 text-slate-900 whitespace-nowrap">Model</th>
                        <th className="px-2 py-1 font-bold border border-slate-300 text-slate-900 whitespace-nowrap">Received From</th>
                        <th className="px-2 py-1 font-bold border border-slate-300 text-slate-900 whitespace-nowrap">Receiving Date</th>
                        <th className="px-2 py-1 font-bold border border-slate-300 text-slate-900 whitespace-nowrap">Condition Status</th>
                        <th className="px-2 py-1 font-bold border border-slate-300 text-slate-900 whitespace-nowrap">Issued To</th>
                        <th className="px-2 py-1 font-bold border border-slate-300 text-slate-900 whitespace-nowrap">Designation</th>
                        <th className="px-2 py-1 font-bold border border-slate-300 text-slate-900 whitespace-nowrap">Observations / Remarks</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-300">
                      {finalReportItems.length === 0 ? (
                        <tr>
                          <td colSpan={13} className="px-4 py-8 text-center text-slate-500 italic border border-slate-300 bg-slate-50 whitespace-nowrap">
                            No matching records found.
                          </td>
                        </tr>
                      ) : (
                        finalReportItems.map((item, idx) => {
                          const isWorkingStatus = item.workingStatus === "Working";
                          return (
                            <tr key={item.timestampId} className="bg-white hover:bg-slate-50">
                              <td className="px-1.5 py-1 font-extrabold border border-slate-300 text-center text-slate-900 w-[1%] whitespace-nowrap">{idx + 1}</td>
                              <td className="px-2 py-1 font-bold border border-slate-300 text-slate-900 whitespace-nowrap">{item.nodeLocation}</td>
                              <td className="px-2 py-1 border border-slate-300 uppercase text-slate-900 whitespace-nowrap">{item.tabContext}</td>
                              <td className="px-2 py-1 font-semibold border border-slate-300 text-slate-900 whitespace-nowrap">{item.name}</td>
                              {(categoryTabFilter === "Furniture" || currentTab === "Furniture") && (
                                <td className="px-1.5 py-1 border border-slate-300 font-mono font-extrabold text-slate-900 text-center w-[1%] whitespace-nowrap">{item.quantity || 1}</td>
                              )}
                              <td className="px-2 py-1 border border-slate-300 text-slate-800 font-mono text-[8px] whitespace-nowrap">{item.serial || '-'}</td>
                              <td className="px-2 py-1 border border-slate-300 text-slate-800 whitespace-nowrap">{item.model || '-'}</td>
                              <td className="px-2 py-1 border border-slate-300 text-slate-800 whitespace-nowrap">{item.receivedFrom || '-'}</td>
                              <td className="px-2 py-1 border border-slate-300 text-slate-700 whitespace-nowrap font-mono text-[8.5px]">{item.date || '-'}</td>
                              <td className="px-2 py-1 border border-slate-300 whitespace-nowrap">
                                <div className="flex items-center gap-1 whitespace-nowrap">
                                  <span className={`text-[8px] font-bold px-1.5 py-0.5 rounded border ${
                                    isWorkingStatus 
                                      ? 'bg-emerald-50 text-emerald-800 border-emerald-300' 
                                      : 'bg-rose-50 text-rose-800 border-rose-300'
                                  }`}>
                                    {item.workingStatus}
                                  </span>
                                  {item.workingSubStatus && (
                                    <span className="text-[7.5px] text-slate-700 bg-slate-100 border border-slate-200 px-1 py-0.5 rounded font-medium whitespace-nowrap">
                                      {item.workingSubStatus}
                                    </span>
                                  )}
                                  {item.nonWorkingSubStatus && (
                                    <span className="text-[7.5px] text-rose-900 bg-rose-50 border border-rose-200 px-1 py-0.5 rounded font-medium whitespace-nowrap">
                                      {item.nonWorkingSubStatus}
                                    </span>
                                  )}
                                </div>
                              </td>
                              <td className="px-2 py-1 border border-slate-300 font-semibold text-slate-900 whitespace-nowrap">{item.issueTo || '-'}</td>
                              <td className="px-2 py-1 border border-slate-300 text-slate-800 whitespace-nowrap">{item.designation || '-'}</td>
                              <td className="px-2 py-1 border border-slate-300 text-slate-800 italic text-[8.5px] whitespace-nowrap">
                                {item.remarks || '-'}
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Signature space */}
              <div className="flex justify-end pt-8 mt-12 border-t border-dashed border-slate-300">
                <div className="border border-dashed border-slate-300 p-4 rounded-lg text-center w-80 bg-white text-slate-900 leading-normal">
                  <div className="h-14 border-b border-slate-200 flex items-center justify-center text-[10px] text-slate-400 italic"></div>
                  <div className="pt-2 font-black text-[11px] tracking-wide text-slate-900 uppercase">
                    {getReportHeaderTitle(currentNodeLocation)}
                  </div>
                  <div className="text-[9px] text-slate-600 font-bold mt-0.5">
                    {locationScope === "current" 
                      ? (currentNodeLocation.startsWith("REC")
                          ? `${currentNodeLocation.replace(/REC|DEC/gi, "").trim()} Division` 
                          : currentNodeLocation.replace(/REC|DEC/gi, "").trim())
                      : "Kohat Division"}
                  </div>
                </div>
              </div>

            </div>

            {/* Footer buttons */}
            <div className="bg-slate-950 px-6 py-4 border-t border-slate-800 flex items-center justify-end gap-2 print:hidden">
              <button
                type="button"
                onClick={handleSavePdf}
                disabled={isSavingPdf}
                className="bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold text-xs py-2 px-5 rounded-xl cursor-pointer transition active:scale-95 flex items-center gap-1.5 shadow-md"
                title="Save as A4 landscape PDF"
              >
                <FileDown className="w-4 h-4" /> {isSavingPdf ? "Generating..." : "Save as PDF"}
              </button>
              <button
                type="button"
                onClick={() => setShowPrintModal(false)}
                className="bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs py-2 px-5 rounded-xl cursor-pointer transition active:scale-95 flex items-center gap-1.5 shadow-md"
              >
                <X className="w-4 h-4" /> Close Preview
              </button>
              <button
                type="button"
                onClick={() => triggerPrintDocument("printableReportDocumentContent")}
                className="bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs py-2 px-5 rounded-xl flex items-center gap-1.5 cursor-pointer shadow-lg transition active:scale-98"
              >
                <Printer className="w-4 h-4" /> Print Document
              </button>
            </div>

          </div>
        </div>
      , document.body)}
    </div>
  );
}
