/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useMemo } from 'react';
import { supabase } from './lib/supabase';
import { InventoryItem, UserAccount } from './types';
import LoginScreen from './components/LoginScreen';
import AdminConsole from './components/AdminConsole';
import ReportMenu from './components/ReportMenu';
import RegistryLedger from './components/RegistryLedger';
import { LogOut, Laptop, Sofa, Package, Shield, Settings, UserCheck, Download, FileSpreadsheet, CheckCircle2, AlertTriangle, Sun, Moon, RotateCcw, Database } from 'lucide-react';

// Robust LocalStorage wrapper to prevent SecurityError/DOMException crashes under file:// protocols
const safeStorageMemory: Record<string, string> = {};
const safeStorage = {
  getItem: (key: string): string | null => {
    try {
      return localStorage.getItem(key);
    } catch (e) {
      console.warn(`localStorage.getItem failed for key "${key}":`, e);
      return safeStorageMemory[key] || null;
    }
  },
  setItem: (key: string, value: string): void => {
    try {
      localStorage.setItem(key, value);
    } catch (e) {
      console.warn(`localStorage.setItem failed for key "${key}":`, e);
      safeStorageMemory[key] = value;
    }
  },
  removeItem: (key: string): void => {
    try {
      localStorage.removeItem(key);
    } catch (e) {
      console.warn(`localStorage.removeItem failed for key "${key}":`, e);
      delete safeStorageMemory[key];
    }
  }
};

const isGenericSerial = (s?: string | null): boolean => {
  if (s === undefined || s === null) return true;
  const clean = String(s).trim().toLowerCase();
  return (
    !clean ||
    clean === "-" ||
    clean === "--" ||
    clean === "---" ||
    clean === "n/a" ||
    clean === "na" ||
    clean === "nil" ||
    clean === "none" ||
    clean === "not available" ||
    clean === "no serial" ||
    clean === "null"
  );
};

// Helper to compare if two inventory items refer to the exact same physical record
const isSameInventoryItem = (a: InventoryItem, b: InventoryItem): boolean => {
  if (!a || !b) return false;
  
  // Exact numeric timestampId match
  const numA = Number(a.timestampId);
  const numB = Number(b.timestampId);
  if (numA && numB && numA === numB) return true;

  return false;
};

// Helper to deduplicate items strictly by unique numeric timestampId
const deduplicateInventoryStore = (items: InventoryItem[]): InventoryItem[] => {
  if (!items || !Array.isArray(items)) return [];
  const seenIds = new Set<number>();

  return items.filter(item => {
    if (!item) return false;
    if (item.nodeLocation === "SYSTEM_SETTINGS") return true;

    // Deduplicate strictly by numeric timestampId
    const numId = Number(item.timestampId);
    if (numId && seenIds.has(numId)) {
      return false;
    }

    if (numId) {
      seenIds.add(numId);
    }

    return true;
  });
};

// Helper to detect any old dummy seed items (timestampId between 1700000001000 and 1700000040000)
const isDummySeedItem = (item: any): boolean => {
  if (!item) return false;
  const ts = Number(item.timestampId);
  return !isNaN(ts) && ts >= 1700000001000 && ts <= 1700000040000;
};

// Helper to retrieve initial database store without dummy data, loading purely from cache if available or returning empty array
const getInitialDatabaseStore = (): InventoryItem[] => {
  try {
    // 1. Try to read from preseeded DOM element if user generated a standalone file
    let preseededData: InventoryItem[] | null = null;
    if (typeof document !== "undefined") {
      const preseedEl = document.getElementById("preseed-inventory-data");
      if (preseedEl) {
        try {
          preseededData = JSON.parse(preseedEl.textContent || "");
          if (Array.isArray(preseededData)) {
            preseededData = preseededData
              .filter(item => !isDummySeedItem(item))
              .map(item => ({
                ...item,
                tabContext: normalizeTabContext(item.tabContext, item.category)
              }));
          }
        } catch (_) {}
      }
    }

    // 2. Try to read from localStorage
    let cachedStr = safeStorage.getItem("inventory_db");
    let cachedData: InventoryItem[] | null = null;
    if (cachedStr) {
      try {
        cachedData = JSON.parse(cachedStr);
        if (Array.isArray(cachedData)) {
          const originalLen = cachedData.length;
          cachedData = cachedData
            .filter(item => !isDummySeedItem(item))
            .map(item => ({
              ...item,
              tabContext: normalizeTabContext(item.tabContext, item.category)
            }));
          // If dummy items were purged, update local storage cache immediately
          if (cachedData.length !== originalLen) {
            safeStorage.setItem("inventory_db", JSON.stringify(cachedData));
          }
        }
      } catch (_) {}
    }

    let initial = cachedData || preseededData || [];
    if (preseededData && preseededData.length > 0) {
      const preseededTimestamp = Number((typeof window !== "undefined" && (window as any).preseededTimestamp) || 0);
      const cachedTime = Number(safeStorage.getItem("inventory_db_timestamp") || "0");
      
      if (!cachedData || cachedData.length === 0 || preseededTimestamp > cachedTime) {
        initial = preseededData;
      }
    }

    return deduplicateInventoryStore(initial.filter(item => !isDummySeedItem(item)));
  } catch (e) {
    console.error("Error loading initial database store:", e);
    return [];
  }
};

// Global helper to persist the cache and maintain robust timestamp synchronization for offline usage
const saveInventoryStore = (store: InventoryItem[]) => {
  try {
    const cleanStore = deduplicateInventoryStore(store);
    const serialized = JSON.stringify(cleanStore);
    const nowStr = Date.now().toString();
    safeStorage.setItem("inventory_db", serialized);
    safeStorage.setItem("inventory_db_timestamp", nowStr);
    
    // Maintain offline-specific keys to ensure complete backward compatibility
    safeStorage.setItem("inventory_db_offline", serialized);
    safeStorage.setItem("inventory_db_offline_timestamp", nowStr);
  } catch (e) {
    console.warn("Failed to persist inventory store:", e);
  }
};

// Robust normalization helpers to prevent database casing discrepancies
function normalizeNodeLocation(raw: string): string {
  const trimmed = (raw || "").trim();
  const lower = trimmed.toLowerCase();
  
  if (lower === "rec kohat") return "REC Kohat";
  if (lower === "dec kohat") return "DEC Kohat";
  if (lower === "dec hangu") return "DEC Hangu";
  if (lower === "dec karak") return "DEC Karak";
  if (lower === "dec orakzai") return "DEC Orakzai";
  if (lower === "dec kurram") return "DEC Kurram";
  if (lower === "system_settings") return "SYSTEM_SETTINGS";
  
  if (lower.startsWith("dec ")) {
    const rest = trimmed.substring(4).trim();
    const capitalizedRest = rest.charAt(0).toUpperCase() + rest.slice(1);
    return `DEC ${capitalizedRest}`;
  }
  if (lower.startsWith("rec ")) {
    const rest = trimmed.substring(4).trim();
    const capitalizedRest = rest.charAt(0).toUpperCase() + rest.slice(1);
    return `REC ${capitalizedRest}`;
  }
  
  return trimmed;
}

function normalizeTabContext(raw: string, category?: string): "IT" | "Furniture" | "Misc" {
  if (category) {
    const cat = category.trim().toLowerCase();
    const furnitureCats = ["chair", "table", "sofa set", "sofa", "tea table", "rack", "almarah", "almirah", "visitor chair", "cupboard", "desk", "executive table"];
    if (furnitureCats.some(f => cat.includes(f))) {
      return "Furniture";
    }
    const miscCats = ["generator", "camera", "water dispenser", "water dispensar", "led", "fridge", "refrigerator", "ac", "air conditioner", "ups", "vehicle", "motorcycle", "motor cycle", "bike"];
    if (miscCats.some(m => cat.includes(m))) {
      return "Misc";
    }
    const itCats = ["computer", "laptop", "printer", "scanner", "photo state", "photostat", "monitor", "mointor", "biometric", "bio metric"];
    if (itCats.some(i => cat.includes(i))) {
      return "IT";
    }
  }

  const trimmed = (raw || "").trim().toLowerCase();
  if (trimmed === "furniture" || trimmed === "furniture assets" || trimmed.startsWith("furn")) {
    return "Furniture";
  }
  if (trimmed === "misc" || trimmed === "miscellaneous" || trimmed.startsWith("misc")) {
    return "Misc";
  }
  if (trimmed === "it" || trimmed === "it equipment" || trimmed === "it-equipment" || trimmed.startsWith("it")) {
    return "IT";
  }

  return "IT";
}

function normalizeWorkingStatus(raw: string): "Working" | "Non-Working" {
  const trimmed = (raw || "").trim().toLowerCase();
  if (trimmed.includes("non")) {
    return "Non-Working";
  }
  return "Working";
}

function normalizeWorkingSubStatus(raw: any): "Issued" | "In-stock" | null {
  if (!raw) return null;
  const trimmed = String(raw).trim().toLowerCase();
  if (trimmed.includes("issued") || trimmed.includes("assign")) {
    return "Issued";
  }
  if (trimmed.includes("stock") || trimmed.includes("in")) {
    return "In-stock";
  }
  return null;
}

function normalizeNonWorkingSubStatus(raw: any): "Needs to repair" | "Ready for Condemnation" | null {
  if (!raw) return null;
  const trimmed = String(raw).trim().toLowerCase();
  if (trimmed.includes("repair") || trimmed.includes("fix")) {
    return "Needs to repair";
  }
  if (trimmed.includes("condemn") || trimmed.includes("ready") || trimmed.includes("unserviceable") || trimmed.includes("scrap")) {
    return "Ready for Condemnation";
  }
  return null;
}

function normalizeReceivedFrom(raw: any): "ECP" | "PEC" | "REC" | "Gifted" | null {
  if (!raw) return null;
  const s = String(raw).trim().toLowerCase();
  if (s === "ecp" || s.includes("ecp")) return "ECP";
  if (s === "pec" || s.includes("pec")) return "PEC";
  if (s === "rec" || s.includes("rec")) return "REC";
  if (s === "gifted" || s.includes("gift")) return "Gifted";
  return null;
}

const DEFAULT_USERS: Record<string, UserAccount> = {
  "Super Admin": { password: "superadmin123", type: "SuperAdmin" },
  "REC Kohat": { password: "admin123", type: "Standard" },
  "DEC Kohat": { password: "kohat123", type: "Standard" },
  "DEC Hangu": { password: "hangu123", type: "Standard" },
  "DEC Karak": { password: "karak123", type: "Standard" },
  "DEC Orakzai": { password: "orakzai123", type: "Standard" },
  "DEC Kurram": { password: "kurram123", type: "Standard" }
};

export default function App() {
  // Authentication states
  const [authenticatedUser, setAuthenticatedUser] = useState<string>("");
  const [authenticatedUserType, setAuthenticatedUserType] = useState<"Standard" | "SuperAdmin">("Standard");
  const [systemUsers, setSystemUsers] = useState<Record<string, UserAccount>>(DEFAULT_USERS);
  const lastUsersWriteTime = useRef<number>(0);
  
  // App context states
  const [currentActiveTab, setCurrentActiveTab] = useState<"IT" | "Furniture" | "Misc">("IT");
  const [currentSupervisorFilterTarget, setCurrentSupervisorFilterTarget] = useState<string>("REC Kohat");
  const [currentView, setCurrentView] = useState<"Ledger" | "Reports">("Ledger");
  const [selectedReportType, setSelectedReportType] = useState<"working" | "nonworking" | "person_office">("working");
  const [reportWorkingSubFilter, setReportWorkingSubFilter] = useState<string>("All");
  const [reportNonWorkingSubFilter, setReportNonWorkingSubFilter] = useState<string>("All");
   const [headerBg, setHeaderBg] = useState<"black" | "white">((): "black" | "white" => {
    const saved = safeStorage.getItem("header_bg_theme");
    return (saved === "white" || saved === "black") ? saved : "white";
  });

  // Ledger / Inventory records state
  const [databaseStore, setDatabaseStore] = useState<InventoryItem[]>(() => {
    return getInitialDatabaseStore();
  });
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isLiveSyncActive, setIsLiveSyncActive] = useState<boolean>(true);
  
  // Track recent local edits in memory so background polling does not overwrite instant UI updates
  const recentEditsRef = useRef<Map<number, { item: InventoryItem; time: number }>>(new Map());

  // Helper to add item to dirty set (for pending offline edits)
  const trackDirtyId = (id: number) => {
    try {
      const stored = safeStorage.getItem("inventory_db_dirty");
      const list: number[] = stored ? JSON.parse(stored) : [];
      if (!list.includes(id)) {
        list.push(id);
        safeStorage.setItem("inventory_db_dirty", JSON.stringify(list));
      }
    } catch (_) {}
  };

  // Helper to remove item from dirty set after successful remote save
  const removeDirtyId = (id: number) => {
    try {
      const stored = safeStorage.getItem("inventory_db_dirty");
      if (stored) {
        const list: number[] = JSON.parse(stored);
        const filtered = list.filter(item => item !== id);
        safeStorage.setItem("inventory_db_dirty", JSON.stringify(filtered));
      }
    } catch (_) {}
  };
  const [syncError, setSyncError] = useState<string | null>(null);
  const [showSolutionsModal, setShowSolutionsModal] = useState<boolean>(false);
  const [downloadModalData, setDownloadModalData] = useState<{ isOpen: boolean; html: string }>({ isOpen: false, html: "" });
  const [copiedHtml, setCopiedHtml] = useState<boolean>(false);
  const [isCompiling, setIsCompiling] = useState<boolean>(false);
  const [isCookieBlocked, setIsCookieBlocked] = useState<boolean>(false);
  const [detectedDbColumns, setDetectedDbColumns] = useState<string[]>([
    "id",
    "timestampId",
    "nodeLocation",
    "tabContext",
    "name",
    "serial",
    "model",
    "category",
    "quantity",
    "receivedFrom",
    "date",
    "workingStatus",
    "workingSubStatus",
    "issueTo",
    "designation",
    "issuedDate",
    "nonWorkingSubStatus",
    "remarks"
  ]);

  // Track recently deleted item IDs with a 15-second timestamp window to allow instantaneous optimistic UI delete without permanently masking Supabase rows
  const recentDeletedRef = useRef<Map<number, number>>(new Map());

  const trackDeletedId = (id: number) => {
    const numId = Number(id);
    if (!numId) return;
    recentDeletedRef.current.set(numId, Date.now());
    try { safeStorage.removeItem("deleted_items_queue"); } catch (_) {}
    // Remove from dirty queue if present
    removeDirtyId(numId);
  };

  // Helper to extract missing column name from PostgREST error and strip it from payload & detectedDbColumns
  const handlePostgrestColumnError = (errMessage?: string, payload?: any): boolean => {
    if (!errMessage) return false;
    
    // Match "Could not find the 'col_name' column" or "column 'col_name' of relation ... does not exist"
    const match = errMessage.match(/Could not find the '([^']+)' column/i) ||
                  errMessage.match(/column ["']?([^"'\s]+)["']? of relation/i) ||
                  errMessage.match(/column ["']?([^"'\s]+)["']? does not exist/i);
    
    if (match && match[1]) {
      const invalidCol = match[1];
      console.warn(`[Self-Healing] Detected missing column '${invalidCol}' in Supabase schema cache. Cleaning up...`);
      if (payload && payload[invalidCol] !== undefined) {
        delete payload[invalidCol];
      }
      setDetectedDbColumns(prev => prev.filter(col => col.toLowerCase() !== invalidCol.toLowerCase()));
      return true;
    }
    return false;
  };

  // Pre-sync validation helper ensuring required fields exist, data types match, and no undefined values
  const validateItemBeforeSync = (item: any): { valid: boolean; errorMsg?: string; cleanItem: InventoryItem } => {
    if (!item) {
      return { valid: false, errorMsg: "Item payload is null or undefined.", cleanItem: item };
    }

    const name = String(item.name || "").trim();
    if (!name) {
      return { valid: false, errorMsg: "Missing required field: name", cleanItem: item };
    }

    const category = String(item.category || "").trim();
    if (!category) {
      return { valid: false, errorMsg: "Missing required field: category", cleanItem: item };
    }

    const rawLoc = normalizeNodeLocation(String(item.nodeLocation || "REC Kohat"));
    const nodeLocation = rawLoc === "SYSTEM_SETTINGS" ? "SYSTEM_SETTINGS" : (rawLoc || "REC Kohat");

    const timestampId = Number(item.timestampId) || Date.now();
    const quantity = Math.max(1, Number(item.quantity) || 1);

    const cleanItem: InventoryItem = {
      id: item.id && typeof item.id === "string" ? item.id.trim() : undefined,
      timestampId,
      nodeLocation,
      tabContext: normalizeTabContext(item.tabContext || "", category),
      name,
      serial: item.serial && !isGenericSerial(item.serial) ? String(item.serial).trim() : null,
      model: item.model ? String(item.model).trim() : null,
      category,
      quantity,
      receivedFrom: item.receivedFrom ? String(item.receivedFrom).trim() : null,
      date: item.date ? String(item.date).trim() : null,
      workingStatus: normalizeWorkingStatus(item.workingStatus || "Working"),
      workingSubStatus: normalizeWorkingSubStatus(item.workingSubStatus),
      issueTo: item.issueTo ? String(item.issueTo).trim() : null,
      designation: item.designation ? String(item.designation).trim() : null,
      issuedDate: item.issuedDate ? String(item.issuedDate).trim() : null,
      nonWorkingSubStatus: normalizeNonWorkingSubStatus(item.nonWorkingSubStatus),
      remarks: item.remarks ? String(item.remarks).trim() : null
    };

    return { valid: true, cleanItem };
  };

  // Helper to format/generate Asset Primary Key (IT0001, Fur0001, Mis0001) per category tab
  const formatAssetId = (item: Partial<InventoryItem>, allItems: InventoryItem[] = []): string => {
    const tab = normalizeTabContext(item.tabContext, item.category);
    const prefix = tab === "IT" ? "IT" : tab === "Furniture" ? "Fur" : "Mis";

    if (item.id && new RegExp(`^${prefix}\\d{4,}$`, "i").test(item.id)) {
      return item.id.toUpperCase();
    }

    const sameTabItems = allItems.filter(i => normalizeTabContext(i.tabContext, i.category) === tab);
    let maxSeq = 0;
    sameTabItems.forEach(i => {
      if (i.id) {
        const match = i.id.match(/^(?:IT|Fur|Mis)(\d+)$/i);
        if (match) {
          const num = parseInt(match[1], 10);
          if (!isNaN(num) && num > maxSeq) maxSeq = num;
        }
      }
    });

    sameTabItems.sort((a, b) => Number(a.timestampId) - Number(b.timestampId));
    const existingIndex = sameTabItems.findIndex(i => Number(i.timestampId) === Number(item.timestampId));

    if (existingIndex >= 0) {
      return `${prefix}${String(existingIndex + 1).padStart(4, "0")}`;
    }

    return `${prefix}${String(maxSeq + 1).padStart(4, "0")}`;
  };

  // Map properties of InventoryItem to Supabase target table's exact schema
  const mapToDbPayload = (item: any): Record<string, any> => {
    const tsId = Number(item.timestampId) || Date.now();
    const rawLoc = normalizeNodeLocation(item.nodeLocation || "REC Kohat");
    const nodeLocation = rawLoc === "SYSTEM_SETTINGS" ? "SYSTEM_SETTINGS" : (rawLoc || "REC Kohat");
    const tabContext = normalizeTabContext(item.tabContext || "", item.category || "");
    const workingStatus = normalizeWorkingStatus(item.workingStatus || "Working");
    const workingSubStatus = workingStatus === "Working" 
      ? normalizeWorkingSubStatus(item.workingSubStatus)
      : null;
    const nonWorkingSubStatus = workingStatus === "Non-Working"
      ? normalizeNonWorkingSubStatus(item.nonWorkingSubStatus)
      : null;

    // Helper to validate and convert any date string to YYYY-MM-DD or null
    const formatToIsoDate = (val: any): string | null => {
      if (!val) return null;
      if (val instanceof Date) {
        return !isNaN(val.getTime()) ? val.toISOString().split('T')[0] : null;
      }
      const s = String(val).trim();
      if (!s || s === "-" || s === "--" || s === "---" || s.toLowerCase() === "n/a" || s.toLowerCase() === "na" || s.toLowerCase() === "nil" || s.toLowerCase() === "none" || s.toLowerCase() === "null" || s.toLowerCase() === "undefined") {
        return null;
      }
      // Excel 5-digit serial date support (e.g. 44900 -> 2022-12-05)
      if (/^\d{5}$/.test(s)) {
        const excelEpoch = new Date(1899, 11, 30);
        const d = new Date(excelEpoch.getTime() + Number(s) * 86400000);
        if (!isNaN(d.getTime())) return d.toISOString().split('T')[0];
      }
      // Direct ISO YYYY-MM-DD
      if (/^\d{4}-\d{2}-\d{2}$/.test(s)) {
        const d = new Date(s);
        if (!isNaN(d.getTime())) return s;
      }
      // Common DD/MM/YYYY or MM/DD/YYYY formats
      const parts = s.split(/[\/\-\.]/);
      if (parts.length === 3 && parts[2].length === 4) {
        const p0 = parseInt(parts[0], 10);
        const p1 = parseInt(parts[1], 10);
        const p2 = parseInt(parts[2], 10);
        if (p2 >= 1970 && p2 <= 2100) {
          if (p0 > 12 && p1 >= 1 && p1 <= 12) {
            return `${p2}-${String(p1).padStart(2, '0')}-${String(p0).padStart(2, '0')}`;
          }
          if (p1 >= 1 && p1 <= 12 && p0 >= 1 && p0 <= 31) {
            return `${p2}-${String(p1).padStart(2, '0')}-${String(p0).padStart(2, '0')}`;
          }
        }
      }
      try {
        const d = new Date(s);
        if (!isNaN(d.getTime())) {
          const year = d.getFullYear();
          if (year >= 1970 && year <= 2100) {
            return d.toISOString().split('T')[0];
          }
        }
      } catch (e) {}
      return null;
    };

    const isIssued = workingStatus === "Working" && workingSubStatus === "Issued";
    const cleanReceivedFrom = normalizeReceivedFrom(item.receivedFrom);

    // If item had a non-standard receivedFrom (e.g. "Purchased", "Vendor"), preserve original in remarks
    let remarks = item.remarks ? String(item.remarks).trim() : null;
    if (item.receivedFrom && !cleanReceivedFrom) {
      const srcText = `Source: ${String(item.receivedFrom).trim()}`;
      if (!remarks) {
        remarks = srcText;
      } else if (!remarks.toLowerCase().includes(String(item.receivedFrom).toLowerCase())) {
        remarks = `${remarks} (${srcText})`;
      }
    }

    return {
      timestampId: tsId,
      nodeLocation,
      tabContext,
      name: String(item.name || "").trim(),
      serial: (item.serial && !isGenericSerial(item.serial)) ? String(item.serial).trim() : null,
      model: item.model ? String(item.model).trim() : null,
      category: String(item.category || "General").trim(),
      receivedFrom: cleanReceivedFrom,
      date: formatToIsoDate(item.date),
      workingStatus,
      workingSubStatus,
      issueTo: (isIssued && item.issueTo) ? String(item.issueTo).trim() : null,
      designation: (isIssued && item.designation) ? String(item.designation).trim() : null,
      issuedDate: (isIssued && item.issuedDate) ? formatToIsoDate(item.issuedDate) : null,
      nonWorkingSubStatus,
      remarks
    };
  };

  const getTimestampColKey = (): string => "timestampId";

  // 1. Initial User accounts setup
  useEffect(() => {
    const storedUsers = safeStorage.getItem("system_users_db");
    if (storedUsers) {
      try {
        setSystemUsers(JSON.parse(storedUsers));
      } catch (e) {
        setSystemUsers(DEFAULT_USERS);
      }
    } else {
      safeStorage.setItem("system_users_db", JSON.stringify(DEFAULT_USERS));
    }
  }, []);

  // 2. Load cached inventory immediately (Offline First!)
  useEffect(() => {
    setDatabaseStore(getInitialDatabaseStore());
  }, []);

  // 3. User Session persistence check
  // Synchronize theme class to body and documentElement for project-wide light/dark toggle
  useEffect(() => {
    if (headerBg === "white") {
      document.body.classList.add("light-theme");
      document.documentElement.classList.add("light-theme");
      document.body.classList.remove("dark-theme");
      document.documentElement.classList.remove("dark-theme");
    } else {
      document.body.classList.add("dark-theme");
      document.documentElement.classList.add("dark-theme");
      document.body.classList.remove("light-theme");
      document.documentElement.classList.remove("light-theme");
    }
  }, [headerBg]);

  useEffect(() => {
    const savedUser = safeStorage.getItem("active_auth_user");
    const savedType = safeStorage.getItem("active_auth_type") as "Standard" | "SuperAdmin" | null;
    const savedFilter = safeStorage.getItem("active_supervisor_filter");

    if (savedUser && savedType) {
      setAuthenticatedUser(savedUser);
      setAuthenticatedUserType(savedType);
      
      if (savedUser.toUpperCase().startsWith("REC") || savedType === "SuperAdmin") {
        if (savedFilter) {
          setCurrentSupervisorFilterTarget(savedFilter);
        } else {
          setCurrentSupervisorFilterTarget(savedUser);
        }
      } else {
        // DEC users are always authoritatively forced to their own division target!
        setCurrentSupervisorFilterTarget(savedUser);
        safeStorage.setItem("active_supervisor_filter", savedUser);
      }
    }
  }, []);

  // 4. Real-time Subscription & Polling Fallback Logic
  useEffect(() => {
    let channel: any;

    if (isLiveSyncActive) {
      // Direct load on mount / activation
      loadInventoryFromSupabase();

      // Establish live changes broadcast from Supabase inventory table
      try {
        channel = supabase
          .channel('realtime-inventory-sync')
          .on(
            'postgres_changes',
            {
              event: '*',
              schema: 'public',
              table: 'inventory'
            },
            (payload) => {
              console.log('Real-time database payload detected:', payload);
              if (payload.eventType === 'DELETE' && payload.old) {
                const oldRow = payload.old;
                const delId = Number(oldRow.timestampId || oldRow.timestampid || oldRow.timestamp_id || oldRow.id);
                if (delId) {
                  trackDeletedId(delId);
                }
              }
              loadInventoryFromSupabase();
            }
          )
          .subscribe((status) => {
            console.log(`Supabase Realtime state: ${status}`);
          });
      } catch (err) {
        console.error("Supabase channel config error:", err);
      }

      // 6-second high-density background pull to guarantee updates across any other systems or browsers
      const pollingTimer = setInterval(() => {
        loadInventoryFromSupabase();
      }, 6000);

      return () => {
        if (channel) {
          supabase.removeChannel(channel);
        }
        clearInterval(pollingTimer);
      };
    } else {
      // Just fallback load once when disabled to make sure everything has correct representation
      loadInventoryFromSupabase();
    }
  }, [isLiveSyncActive]);

  // Supabase Load with Normalization: Database is the Authoritative Single Source of Truth
  const loadInventoryFromSupabase = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('inventory')
        .select('*');

      if (error) {
        console.warn("Supabase API loaded status warning:", error);
        setSyncError(`Load info: ${error.message || JSON.stringify(error)}`);
        
        // Fallback to offline cached data on database load failure
        const fallbackData = getInitialDatabaseStore();
        setDatabaseStore(fallbackData);
        console.log("Loaded fallback inventory from robust loader (Supabase error).");
      } else if (data) {
        setSyncError(null);
        if (data.length > 0) {
          setDetectedDbColumns(Object.keys(data[0]));
        }

        // Normalization Layer for DB Column Case & Type differences
        const remoteItemsNormalized: InventoryItem[] = data.map((row: any) => {
          const rawLoc = normalizeNodeLocation(row.nodeLocation || row.nodelocation || row.node_location || "");
          const finalLoc = rawLoc === "SYSTEM_SETTINGS" ? "SYSTEM_SETTINGS" : (rawLoc || "REC Kohat");
          const rawId = row.id || row.asset_id || row.assetid || null;
          
          let parsedTsId = Number(row.timestampId ?? row.timestampid ?? row.timestamp_id);
          if (isNaN(parsedTsId) || !parsedTsId) {
            const numId = Number(row.id);
            if (!isNaN(numId) && numId > 0) {
              parsedTsId = numId;
            } else {
              const strToHash = String(row.id || `${row.name || ''}_${row.nodelocation || row.nodeLocation || ''}_${row.category || ''}_${row.serial || ''}`);
              let hash = 0;
              for (let i = 0; i < strToHash.length; i++) {
                hash = ((hash << 5) - hash) + strToHash.charCodeAt(i);
                hash |= 0;
              }
              parsedTsId = Math.abs(hash) + 100000;
            }
          }

          return {
            id: (rawId && typeof rawId === 'string' && /^(IT|Fur|Mis)\d+$/i.test(rawId)) ? String(rawId) : undefined,
            timestampId: parsedTsId,
            nodeLocation: finalLoc,
            tabContext: normalizeTabContext(row.tabContext || row.tabcontext || row.tab_context || "", row.category || ""),
            name: row.name || "",
            serial: (row.serial && !isGenericSerial(row.serial)) ? String(row.serial).trim() : null,
            model: row.model || null,
            category: row.category || "General",
            quantity: 1,
            receivedFrom: row.receivedFrom || row.receivedfrom || row.received_from || null,
            date: row.date || null,
            workingStatus: normalizeWorkingStatus(row.workingStatus || row.workingstatus || row.working_status || "Working"),
            workingSubStatus: normalizeWorkingSubStatus(row.workingSubStatus || row.workingsubstatus || row.working_sub_status),
            issueTo: row.issueTo || row.issueto || row.issue_to || null,
            designation: row.designation || null,
            issuedDate: row.issuedDate || row.issueddate || row.issued_date || null,
            nonWorkingSubStatus: normalizeNonWorkingSubStatus(row.nonWorkingSubStatus || row.nonworkingsubstatus || row.non_working_sub_status),
            remarks: row.remarks || null
          };
        });

        // 1. Filter out deleted items: only suppress items deleted in the last 15 seconds to allow optimistic UI without permanently masking Supabase rows
        const pruneNow = Date.now();
        for (const [delId, delTs] of recentDeletedRef.current.entries()) {
          if (pruneNow - delTs > 15000) {
            recentDeletedRef.current.delete(delId);
          }
        }
        const activeRemoteItems = remoteItemsNormalized.filter(item => !recentDeletedRef.current.has(Number(item.timestampId)));

        // 2. Read what is currently stored in local state/localStorage
        let currentLocalItems: InventoryItem[] = [];
        try {
          const cached = safeStorage.getItem("inventory_db");
          currentLocalItems = cached ? JSON.parse(cached) : [];
        } catch (e) {
          currentLocalItems = databaseStore;
        }

        // Read dirty items list (edited offline and pending sync)
        let currentDirtyIds: number[] = [];
        try {
          const storedDirty = safeStorage.getItem("inventory_db_dirty");
          currentDirtyIds = storedDirty ? JSON.parse(storedDirty).map(Number) : [];
        } catch (_) {}

        // If we successfully reached Supabase, proactively sync pending offline items
        if (currentDirtyIds.length > 0) {
          console.log(`[Online Sync] Found ${currentDirtyIds.length} pending offline modifications. Syncing to Supabase...`);

          for (const id of currentDirtyIds) {
            const numId = Number(id);
            const localItem = currentLocalItems.find(item => Number(item.timestampId) === numId);
            if (localItem) {
              const { valid, cleanItem } = validateItemBeforeSync(localItem);
              if (!valid) {
                removeDirtyId(numId);
                continue;
              }

              const isInsert = !remoteItemsNormalized.some(r => Number(r.timestampId) === numId);
              const dbPayload = mapToDbPayload(cleanItem);

              try {
                if (isInsert) {
                  const { error: insErr } = await supabase.from('inventory').insert([dbPayload]);
                  if (!insErr) {
                    removeDirtyId(numId);
                    console.log(`[Online Sync] Synced pending insert item ${numId}`);
                  } else {
                    const isDup = insErr.code === '23505' || (insErr as any).status === 409 || insErr.message?.includes('duplicate key') || insErr.message?.includes('unique constraint');
                    if (isDup) {
                      const { timestampId: _, ...updateFields } = dbPayload;
                      const { error: updErr } = await supabase.from('inventory').update(updateFields).eq('timestampId', numId);
                      if (!updErr) {
                        removeDirtyId(numId);
                        console.log(`[Online Sync] Synced pending insert as update ${numId}`);
                      }
                    }
                  }
                } else {
                  const { timestampId: _, ...updateFields } = dbPayload;
                  const { error: updErr } = await supabase.from('inventory').update(updateFields).eq('timestampId', numId);
                  if (!updErr) {
                    removeDirtyId(numId);
                    console.log(`[Online Sync] Synced pending update item ${numId}`);
                  }
                }
              } catch (e) {
                console.error("Supabase sync exception for dirty item:", e);
              }
            } else {
              removeDirtyId(numId);
            }
          }
          
          try {
            const storedDirty = safeStorage.getItem("inventory_db_dirty");
            currentDirtyIds = storedDirty ? JSON.parse(storedDirty).map(Number) : [];
          } catch (_) {}
        }

        // 3. Merge: Supabase is authoritative, but newly created offline items in dirty queue are preserved
        const mergedStore: InventoryItem[] = [];
        const now = Date.now();
        
        activeRemoteItems.forEach(remoteItem => {
          const remoteId = Number(remoteItem.timestampId);
          const recentEdit = recentEditsRef.current.get(remoteId);

          if (recentEdit && (now - recentEdit.time < 5000)) {
            mergedStore.push(recentEdit.item);
          } else {
            const dirtyLocal = currentLocalItems.find(l => 
              isSameInventoryItem(l, remoteItem) && currentDirtyIds.includes(Number(l.timestampId))
            );
            if (dirtyLocal) {
              mergedStore.push({ ...dirtyLocal, timestampId: remoteItem.timestampId || dirtyLocal.timestampId });
            } else {
              mergedStore.push(remoteItem);
            }
          }
        });

        // ONLY add local items that were created offline and are still pending initial sync to Supabase
        currentLocalItems.forEach(localItem => {
          const localNumId = Number(localItem.timestampId);
          const isPendingOffline = currentDirtyIds.includes(localNumId);
          const wasDeleted = recentDeletedRef.current.has(localNumId);
          const matchesMerged = mergedStore.some(m => isSameInventoryItem(m, localItem));
          const isDummy = isDummySeedItem(localItem);

          if (isPendingOffline && !matchesMerged && !wasDeleted && !isDummy && localItem.nodeLocation !== "SYSTEM_SETTINGS") {
            mergedStore.push(localItem);
          } else if (matchesMerged) {
            removeDirtyId(localNumId);
          }
        });

        // Extract cloud synchronized accounts settings
        const settingsRow = remoteItemsNormalized.find(row => row.nodeLocation === "SYSTEM_SETTINGS");
        if (settingsRow && settingsRow.remarks) {
          if (Date.now() - lastUsersWriteTime.current >= 15000) {
            try {
              const parsedUsers = JSON.parse(settingsRow.remarks);
              setSystemUsers(parsedUsers);
              safeStorage.setItem("system_users_db", JSON.stringify(parsedUsers));
            } catch (e) {
              console.error("Cloud synced settings parse error:", e);
            }
          } else {
            console.log("Skipped loading cloud user settings to avoid race condition with recent local update.");
          }
        }

        // Filter out SYSTEM_SETTINGS and dummy seed items, then apply deep deduplication
        const cleanStore = deduplicateInventoryStore(
          mergedStore.filter(row => row.nodeLocation !== "SYSTEM_SETTINGS" && !isDummySeedItem(row))
        );

        // Format and assign category-specific primary keys (IT0001, Fur0001, Mis0001) for all stored assets
        (["IT", "Furniture", "Misc"] as const).forEach(tabKey => {
          const tabItems = cleanStore.filter(i => normalizeTabContext(i.tabContext, i.category) === tabKey);
          tabItems.sort((a, b) => Number(a.timestampId) - Number(b.timestampId));
          const prefix = tabKey === "IT" ? "IT" : tabKey === "Furniture" ? "Fur" : "Mis";

          tabItems.forEach((item, index) => {
            item.id = `${prefix}${String(index + 1).padStart(4, '0')}`;
          });
        });

        // Set the database store
        setDatabaseStore(cleanStore);
        saveInventoryStore(cleanStore);
      }
    } catch (err) {
      console.warn("Loader transaction log:", err);
      
      // Fallback to offline cached data on network error (offline file load)
      const fallbackData = getInitialDatabaseStore();
      setDatabaseStore(fallbackData);
      console.log("Loaded fallback inventory from robust loader (Network exception).");
    } finally {
      setIsLoading(false);
    }
  };

  const syncSystemUsersToSupabase = async (users: Record<string, UserAccount>) => {
    try {
      const settingsPayload: InventoryItem = {
        timestampId: 1,
        nodeLocation: "SYSTEM_SETTINGS",
        tabContext: "IT",
        name: "ACCOUNTS",
        category: "SYSTEM",
        workingStatus: "Working",
        remarks: JSON.stringify(users)
      };

      const dbPayload = mapToDbPayload(settingsPayload);
      const timestampColKey = getTimestampColKey();

      // Resilient upsert for settings row with timestampId = 1
      const { error: updErr } = await supabase
        .from('inventory')
        .update(dbPayload)
        .eq(timestampColKey, 1);

      if (updErr) {
        const { error: insErr } = await supabase
          .from('inventory')
          .insert([dbPayload]);
        if (insErr && (insErr.code === '23505' || (insErr as any).status === 409 || insErr.message?.includes('duplicate key'))) {
          await supabase.from('inventory').update(dbPayload).eq(timestampColKey, 1);
        }
      }
    } catch (err) {
      console.error("Failed to push user updates to cloud DB:", err);
    }
  };

  const handleToggleLiveSync = async () => {
    const nextState = !isLiveSyncActive;
    setIsLiveSyncActive(nextState);
    await loadInventoryFromSupabase();
  };

  const handleForceSync = async () => {
    setIsLiveSyncActive(true);
    await loadInventoryFromSupabase();
  };

  const handleLoginSuccess = (username: string, accountType: "Standard" | "SuperAdmin") => {
    setAuthenticatedUser(username);
    setAuthenticatedUserType(accountType);
    
    let defaultFilter = username;
    if (accountType === "SuperAdmin") {
      const firstStandardNode = Object.keys(systemUsers).find(u => systemUsers[u].type === "Standard");
      defaultFilter = firstStandardNode || "REC Kohat";
    }

    setCurrentSupervisorFilterTarget(defaultFilter);
    safeStorage.setItem("active_auth_user", username);
    safeStorage.setItem("active_auth_type", accountType);
    safeStorage.setItem("active_supervisor_filter", defaultFilter);
  };

  const handleLogout = () => {
    setAuthenticatedUser("");
    setAuthenticatedUserType("Standard");
    safeStorage.removeItem("active_auth_user");
    safeStorage.removeItem("active_auth_type");
    safeStorage.removeItem("active_supervisor_filter");
  };

  const handlePasswordChanged = async (updated: Record<string, UserAccount>) => {
    lastUsersWriteTime.current = Date.now();
    setSystemUsers(updated);
    safeStorage.setItem("system_users_db", JSON.stringify(updated));
    await syncSystemUsersToSupabase(updated);
  };

  const handleSupervisorFilterChange = async (val: string) => {
    setCurrentSupervisorFilterTarget(val);
    safeStorage.setItem("active_supervisor_filter", val);
    await loadInventoryFromSupabase();
  };

  const handleTabChange = async (tab: "IT" | "Furniture" | "Misc") => {
    setCurrentActiveTab(tab);
    await loadInventoryFromSupabase();
  };

  const handleDownloadHtml = async () => {
    setIsCompiling(true);
    setIsCookieBlocked(false);
    try {
      let htmlText = "";
      
      // 1. Primary Source: Compile the latest app on-the-fly and fetch the HTML template
      try {
        const res = await fetch(`/api/compile-single-html?t=${Date.now()}`, { cache: "no-store" });
        if (res.ok) {
          const txt = await res.text();
          if (txt && txt.toLowerCase().includes("doctype html") && !txt.includes("blocking a required security cookie") && !txt.includes("Safari") && txt.includes("id=\"root\"")) {
            htmlText = txt;
          } else {
            console.warn("Fetched HTML is an auth proxy or cookie-block page. Using robust local fallback.");
            setIsCookieBlocked(true);
          }
        } else {
          setIsCookieBlocked(true);
        }
      } catch (e) {
        console.error("Server compilation fetch failed, falling back to local clone:", e);
        setIsCookieBlocked(true);
      }

      // 2. Fallback: Use active page DOM if fetch failed
      if (!htmlText) {
        const docClone = document.documentElement.cloneNode(true) as HTMLElement;
        const oldDataEl = docClone.querySelector("#preseed-inventory-data");
        if (oldDataEl) oldDataEl.remove();
        const oldStateEl = docClone.querySelector("#preseed-database-state");
        if (oldStateEl) oldStateEl.remove();
        
        // CLEAR the active React mounting container to ensure a clean, un-hydrated template!
        const rootEl = docClone.querySelector("#root");
        if (rootEl) {
          rootEl.innerHTML = "";
        }
        
        htmlText = "<!DOCTYPE html>\n" + docClone.outerHTML;
      }

      // Inject the latest synchronized dataset, users, and timestamp into the downloaded HTML
      const serializedData = JSON.stringify(databaseStore);
      const serializedUsers = JSON.stringify(systemUsers || {});
      let modifiedHtml = htmlText;

      // Also inject a head-script for preseeding modern compiled React single-file offline localStorage
      const dataScriptId = "preseed-inventory-data";
      const usersScriptId = "preseed-system-users";
      const preseedScript = `
<` + `script type="application/json" id="${dataScriptId}">
${serializedData.replace(/<\/script>/g, '<\\/script>')}
</` + `script>
<` + `script type="application/json" id="${usersScriptId}">
${serializedUsers.replace(/<\/script>/g, '<\\/script>')}
</` + `script>
<` + `script id="preseed-database-state">
  try {
    const preseededTimestamp = ${Date.now()};
    window.preseededTimestamp = preseededTimestamp;
    const cachedTime = localStorage.getItem("inventory_db_timestamp") || 0;
    if (preseededTimestamp > Number(cachedTime)) {
      const dataEl = document.getElementById("${dataScriptId}");
      if (dataEl) {
        const jsonStr = dataEl.textContent || "";
        localStorage.setItem("inventory_db", jsonStr);
        localStorage.setItem("inventory_db_timestamp", preseededTimestamp.toString());
        
        // Also seed offline_db if it uses index_single.html offline variables
        localStorage.setItem("inventory_db_offline", jsonStr);
        localStorage.setItem("inventory_db_offline_timestamp", preseededTimestamp.toString());
      }
      const usersEl = document.getElementById("${usersScriptId}");
      if (usersEl) {
        const usersJsonStr = usersEl.textContent || "";
        if (usersJsonStr && usersJsonStr !== "{}") {
          localStorage.setItem("system_users_db", usersJsonStr);
        }
      }
    }
  } catch (e) {
    console.error("Offline preseed error:", e);
  }
</` + `script>
`;
      
      if (modifiedHtml.includes("<head>")) {
        modifiedHtml = modifiedHtml.replace("<head>", `<head>${preseedScript}`);
      } else if (modifiedHtml.includes("<HEAD>")) {
        modifiedHtml = modifiedHtml.replace("<HEAD>", `<HEAD>${preseedScript}`);
      } else {
        modifiedHtml = preseedScript + modifiedHtml;
      }

      // Open download wizard modal with the generated HTML
      setDownloadModalData({ isOpen: true, html: modifiedHtml });
      setCopiedHtml(false);

    } catch (err: any) {
      console.error("Dynamic download failed:", err);
      alert("Offline app template could not be loaded. Please try again.");
    } finally {
      setIsCompiling(false);
    }
  };

  // Helper to format official header title based on location
  const getReportHeaderTitle = (location?: string): string => {
    const locStr = location || "";
    const locUpper = locStr.toUpperCase();
    if (locUpper === "ALL OFFICES" || locUpper === "ALL") {
      return "ELECTION COMMISSION OF PAKISTAN, KOHAT DIVISION (ALL OFFICES)";
    }
    let distName = locStr.replace(/REC|DEC/gi, "").trim();
    if (!distName) distName = "KOHAT";

    if (locUpper.startsWith("REC")) {
      return `REGIONAL ELECTION COMMISSIONER (${distName.toUpperCase()})`;
    } else if (locUpper.startsWith("DEC")) {
      return `DISTRICT ELECTION COMMISSIONER (${distName.toUpperCase()})`;
    } else {
      return `ELECTION COMMISSION OF PAKISTAN (${locStr ? locStr.toUpperCase() : "KOHAT"})`;
    }
  };

  // Check if active session allows modification of chosen Location
  const checkWritePrivileges = (): boolean => {
    if (authenticatedUserType === "SuperAdmin") return true;
    if (!authenticatedUser) return false;
    // REC accounts: only have write/edit/delete rights when inspecting their OWN home location (e.g. REC Kohat).
    // When REC account views subordinate offices (DEC Kohat, DEC Hangu, DEC Orakzai), return false (read-only view/ready rights).
    return (currentSupervisorFilterTarget || "").trim().toLowerCase() === authenticatedUser.trim().toLowerCase();
  };

  // CREATE / UPDATE operation matching database
  const handleItemCommit = async (payload: Omit<InventoryItem, 'timestampId'> & { timestampId?: number; originalSerial?: string | null; isEditing?: boolean }) => {
    if (authenticatedUserType !== "SuperAdmin" && !checkWritePrivileges()) {
      alert("Action Restricted: You do not have permission to modify records for this office location.");
      return;
    }

    const isEditingForm = payload.isEditing === true || (payload.isEditing !== false && Boolean(payload.timestampId) && databaseStore.some(r => Number(r.timestampId) === Number(payload.timestampId)));
    let timestampId = (isEditingForm && payload.timestampId) ? Number(payload.timestampId) : (payload.isEditing === false ? Date.now() : (payload.timestampId ? Number(payload.timestampId) : Date.now()));
    const origSerial = payload.originalSerial ? payload.originalSerial.trim() : (payload.serial ? payload.serial.trim() : null);

    // Check if an existing item matches strictly by timestampId
    let existingIdx = isEditingForm ? databaseStore.findIndex(r => Number(r.timestampId) === timestampId) : -1;
    const isInsert = !isEditingForm || existingIdx < 0;

    const targetLoc = (payload.nodeLocation || currentSupervisorFilterTarget || "REC Kohat").trim();
    const cleanItem: InventoryItem = {
      ...payload,
      nodeLocation: normalizeNodeLocation(targetLoc === "All Offices" ? "REC Kohat" : targetLoc),
      tabContext: normalizeTabContext(payload.tabContext, payload.category),
      workingStatus: normalizeWorkingStatus(payload.workingStatus || "Working"),
      workingSubStatus: normalizeWorkingSubStatus(payload.workingSubStatus),
      nonWorkingSubStatus: normalizeNonWorkingSubStatus(payload.nonWorkingSubStatus),
      receivedFrom: normalizeReceivedFrom(payload.receivedFrom) || (payload.receivedFrom ? String(payload.receivedFrom).trim() : null),
      timestampId
    };
    cleanItem.id = formatAssetId(cleanItem, databaseStore);
    delete (cleanItem as any).originalSerial;
    delete (cleanItem as any).isEditing;

    // Track in recentEdits map and dirty IDs list
    recentEditsRef.current.set(timestampId, { item: cleanItem, time: Date.now() });
    trackDirtyId(timestampId);

    // 1. Immediately update Local View & Local Storage (Zero Wait UI!)
    setDatabaseStore(prevStore => {
      let matched = false;
      const nextStore: InventoryItem[] = [];
      for (const item of prevStore) {
        const itemNumId = Number(item.timestampId);
        if (itemNumId === timestampId) {
          if (!matched) {
            nextStore.push(cleanItem);
            matched = true;
          }
        } else {
          nextStore.push(item);
        }
      }

      if (!matched) {
        nextStore.push(cleanItem);
      }

      saveInventoryStore(nextStore);
      return nextStore;
    });

    // 2. Perform Supabase database query
    try {
      let syncErr: string | null = null;
      const dbPayload = mapToDbPayload(cleanItem);

      if (isInsert) {
        const { error } = await supabase.from('inventory').insert([dbPayload]);
        if (error) {
          const isDuplicate = error.code === '23505' || (error as any).status === 409 || error.message?.includes('duplicate key') || error.message?.includes('unique constraint');
          if (isDuplicate) {
            const { timestampId: _, ...updateFields } = dbPayload;
            const { error: updErr } = await supabase
              .from('inventory')
              .update(updateFields)
              .or(`timestampId.eq.${timestampId},id.eq.${timestampId}`);
            if (updErr) {
              syncErr = updErr.message;
            } else {
              removeDirtyId(timestampId);
            }
          } else {
            console.error("Supabase insert error:", error);
            syncErr = error.message;
          }
        } else {
          removeDirtyId(timestampId);
        }
      } else {
        const { timestampId: _, ...updateFields } = dbPayload;
        const { data: updData, error: updErr } = await supabase
          .from('inventory')
          .update(updateFields)
          .or(`timestampId.eq.${timestampId},id.eq.${timestampId}`)
          .select();

        if (updErr) {
          console.warn("Supabase update error, falling back to insert:", updErr);
          const { error: insErr } = await supabase.from('inventory').insert([dbPayload]);
          if (insErr) {
            console.error("Supabase insert fallback error:", insErr);
            syncErr = insErr.message;
          } else {
            removeDirtyId(timestampId);
          }
        } else if (!updData || updData.length === 0) {
          // If no rows matched for update in remote db, insert it to ensure it is saved
          const { error: insErr } = await supabase.from('inventory').insert([dbPayload]);
          if (insErr) {
            console.error("Supabase insert fallback error:", insErr);
            syncErr = insErr.message;
          } else {
            removeDirtyId(timestampId);
          }
        } else {
          removeDirtyId(timestampId);
        }
      }

      if (syncErr) {
        setSyncError(`Save to cloud: ${syncErr}`);
      } else {
        setSyncError(null);
      }

      await loadInventoryFromSupabase();
      recentEditsRef.current.delete(timestampId);
    } catch (err: any) {
      console.error("Sync transaction failed:", err);
      setSyncError(`Sync error: ${err.message || err}`);
    }
  };

  // BULK CREATE / COMMIT operation matching database - PRIORITY TO SAVE TO SUPABASE FIRST
  const handleItemsBulkCommit = async (items: InventoryItem[]): Promise<{ successCount: number; totalCount: number }> => {
    if (items.length === 0) return { successCount: 0, totalCount: 0 };

    // Clean, validate, and assign unique non-colliding IDs across databaseStore + batch
    const accumulativeStore = [...databaseStore];
    const baseBatchTs = Date.now();

    const cleanedItems: InventoryItem[] = items.map((item, idx) => {
      const tsId = (item.timestampId && Number(item.timestampId) > 0) ? Number(item.timestampId) : (baseBatchTs + idx * 50 + Math.floor(Math.random() * 40) + 1);
      const { cleanItem } = validateItemBeforeSync({ ...item, timestampId: tsId });

      const isTaken = cleanItem.id ? accumulativeStore.some(
        i => i.id?.toUpperCase() === cleanItem.id?.toUpperCase() && Number(i.timestampId) !== Number(cleanItem.timestampId)
      ) : true;

      if (!cleanItem.id || isTaken) {
        cleanItem.id = formatAssetId(cleanItem, accumulativeStore);
      }

      accumulativeStore.push(cleanItem);
      return cleanItem;
    });

    // STEP 0: Immediately update Local View & Local Storage (Zero-Wait UI!)
    cleanedItems.forEach(cleanItem => {
      recentEditsRef.current.set(Number(cleanItem.timestampId), { item: cleanItem, time: Date.now() });
      trackDirtyId(Number(cleanItem.timestampId));
    });

    setDatabaseStore(prevStore => {
      const nextStore = [...prevStore];
      cleanedItems.forEach(cleanItem => {
        const itemNumId = Number(cleanItem.timestampId);
        let existingIdx = nextStore.findIndex(r => Number(r.timestampId) === itemNumId);
        
        if (existingIdx < 0 && cleanItem.serial && !isGenericSerial(cleanItem.serial)) {
          existingIdx = nextStore.findIndex(r => 
            r.nodeLocation === cleanItem.nodeLocation && 
            r.serial && cleanItem.serial && 
            r.serial.trim().toLowerCase() === cleanItem.serial.trim().toLowerCase()
          );
        }

        if (existingIdx >= 0) {
          const origTs = Number(nextStore[existingIdx].timestampId || itemNumId);
          nextStore[existingIdx] = { ...cleanItem, timestampId: origTs };
        } else {
          nextStore.push({ ...cleanItem, timestampId: itemNumId });
        }
      });
      const cleanNext = deduplicateInventoryStore(nextStore);
      saveInventoryStore(cleanNext);
      return cleanNext;
    });

    let successCount = 0;
    let syncErr: string | null = null;
    const dbPayloads = cleanedItems.map(item => mapToDbPayload(item));

    // STEP 1: Direct batch insertion to Supabase with resilient conflict handling
    try {
      const CHUNK_SIZE = 50;
      for (let i = 0; i < dbPayloads.length; i += CHUNK_SIZE) {
        const chunk = dbPayloads.slice(i, i + CHUNK_SIZE);
        const { error: chunkErr } = await supabase.from('inventory').insert(chunk);

        if (!chunkErr) {
          successCount += chunk.length;
          chunk.forEach(item => removeDirtyId(Number(item.timestampId)));
        } else {
          console.warn("Chunk insert encountered issue, falling back to individual item processing:", chunkErr);
          for (const singleItem of chunk) {
            const { error: singleErr } = await supabase.from('inventory').insert([singleItem]);
            if (!singleErr) {
              successCount++;
              removeDirtyId(Number(singleItem.timestampId));
            } else {
              const isDuplicate = singleErr.code === '23505' || (singleErr as any).status === 409 || singleErr.message?.includes('duplicate key') || singleErr.message?.includes('unique constraint');
              if (isDuplicate) {
                const { timestampId: _, ...updateFields } = singleItem;
                const { error: updErr } = await supabase
                  .from('inventory')
                  .update(updateFields)
                  .eq('timestampId', singleItem.timestampId);
                if (!updErr) {
                  successCount++;
                  removeDirtyId(Number(singleItem.timestampId));
                } else {
                  syncErr = updErr.message;
                }
              } else {
                syncErr = singleErr.message;
              }
            }
          }
        }
      }
    } catch (err: any) {
      console.error("Supabase bulk upload transaction failed:", err);
      syncErr = err.message || String(err);
    }

    if (successCount > 0) {
      setSyncError(null);
    } else if (syncErr) {
      setSyncError(`Bulk upload to Supabase info: ${syncErr}`);
      if (syncErr.includes("violates row-level security") || syncErr.includes("401") || syncErr.includes("permission denied")) {
        setShowSolutionsModal(true);
      }
    }

    // STEP 3: Refresh inventory state from Supabase to guarantee authoritative sync
    await loadInventoryFromSupabase();

    return {
      successCount,
      totalCount: cleanedItems.length
    };
  };

  // DELETE operation
  const handleItemDelete = async (timestampId: number) => {
    if (authenticatedUserType !== "SuperAdmin" && !checkWritePrivileges()) {
      alert("Action Restricted: You do not have permission to delete records for this office location.");
      return;
    }

    const targetId = Number(timestampId);
    if (!targetId) return;

    // Clear from recentEdits cache if present
    recentEditsRef.current.delete(targetId);

    // 1. Instantly delete locally & track deleted id
    trackDeletedId(targetId);
    setDatabaseStore(prevStore => {
      const nextStore = prevStore.filter(item => Number(item.timestampId) !== targetId);
      saveInventoryStore(nextStore);
      return nextStore;
    });

    // 2. Delete from Supabase by timestampId or id
    try {
      const { error } = await supabase
        .from('inventory')
        .delete()
        .or(`timestampId.eq.${targetId},id.eq.${targetId}`);

      if (error) {
        console.error("Delete error:", error);
        setSyncError(`Delete sync error: ${error.message}`);
      } else {
        setSyncError(null);
      }

      await loadInventoryFromSupabase();
    } catch (err: any) {
      console.error("Delete transaction error:", err);
      setSyncError(`Delete sync error: ${err.message || err}`);
    }
  };

  // DELETE ALL (Clear all items inside current supervisor node & tab) - SUPERADMIN ONLY
  const handleItemDeleteAll = async () => {
    if (authenticatedUserType !== "SuperAdmin") {
      alert("Action Restricted: Only Super Admin users have permission to Clear All records.");
      return;
    }

    const activeSectionItems = databaseStore.filter(
      item => 
        (item.nodeLocation || "").trim().toLowerCase() === (currentSupervisorFilterTarget || "").trim().toLowerCase() && 
        normalizeTabContext(item.tabContext, item.category) === currentActiveTab
    );

    if (activeSectionItems.length === 0) return;

    // 1. Update instantly locally and track deleted IDs
    activeSectionItems.forEach(item => trackDeletedId(Number(item.timestampId)));
    const itemsToKeep = databaseStore.filter(
      item => !(
        (item.nodeLocation || "").trim().toLowerCase() === (currentSupervisorFilterTarget || "").trim().toLowerCase() && 
        normalizeTabContext(item.tabContext, item.category) === currentActiveTab
      )
    );
    setDatabaseStore(itemsToKeep);
    saveInventoryStore(itemsToKeep);

    // 2. Delete on Supabase using exact location + tab matching
    try {
      const idsToDelete = activeSectionItems.map(item => Number(item.timestampId)).filter(Boolean);
      const targetLoc = currentSupervisorFilterTarget.trim();
      const targetTab = currentActiveTab;

      // Delete by nodeLocation and tabContext
      await supabase
        .from('inventory')
        .delete()
        .eq('nodeLocation', targetLoc)
        .eq('tabContext', targetTab);

      // Also ensure any matched timestamp IDs are deleted
      if (idsToDelete.length > 0) {
        await supabase
          .from('inventory')
          .delete()
          .in('timestampId', idsToDelete);
      }

      setSyncError(null);
      await loadInventoryFromSupabase();
    } catch (err: any) {
      console.error("Mass delete transaction failure:", err);
      setSyncError(`Clear All error: ${err.message || err}`);
    }
  };

  // Filter current active scope data
  const isAllOfficesSelected = (currentSupervisorFilterTarget || "").trim().toLowerCase() === "all offices" || (currentSupervisorFilterTarget || "").trim().toLowerCase() === "all";

  const activeScopeData = databaseStore.filter(
    item => 
      (isAllOfficesSelected || (item.nodeLocation || "").trim().toLowerCase() === (currentSupervisorFilterTarget || "").trim().toLowerCase()) && 
      normalizeTabContext(item.tabContext, item.category) === currentActiveTab
  );

  // All items for this office location across all categories
  const allLocationData = databaseStore.filter(
    item => 
      (isAllOfficesSelected || (item.nodeLocation || "").trim().toLowerCase() === (currentSupervisorFilterTarget || "").trim().toLowerCase()) &&
      (item.nodeLocation || "").trim().toUpperCase() !== "SYSTEM_SETTINGS"
  );

  // Live station counts across all subordinate offices and regional headquarters
  const stationCounts = useMemo(() => {
    const counts: Record<string, number> = {
      "All Offices": 0
    };
    Object.keys(systemUsers).forEach(u => {
      if (systemUsers[u].type === "Standard") {
        counts[u] = 0;
      }
    });

    databaseStore.forEach(item => {
      if (item.nodeLocation && item.nodeLocation.toUpperCase() !== "SYSTEM_SETTINGS") {
        const norm = normalizeNodeLocation(item.nodeLocation);
        counts[norm] = (counts[norm] || 0) + 1;
        counts["All Offices"] = (counts["All Offices"] || 0) + 1;
      }
    });

    return counts;
  }, [databaseStore, systemUsers]);

  // Tab-specific item counts for active station scope
  const itTabCount = useMemo(() => {
    return allLocationData.filter(item => normalizeTabContext(item.tabContext, item.category) === "IT").length;
  }, [allLocationData]);

  const furnitureTabCount = useMemo(() => {
    return allLocationData.filter(item => normalizeTabContext(item.tabContext, item.category) === "Furniture").length;
  }, [allLocationData]);

  const miscTabCount = useMemo(() => {
    return allLocationData.filter(item => normalizeTabContext(item.tabContext, item.category) === "Misc").length;
  }, [allLocationData]);

  if (!authenticatedUser) {
    return (
      <LoginScreen
        systemUsers={systemUsers}
        onLoginSuccess={handleLoginSuccess}
        onPasswordChanged={handlePasswordChanged}
      />
    );
  }

  // Active user writes privileges
  const isWriteAllowed = checkWritePrivileges();

  return (
    <div 
      id="appWrapper" 
      className={`min-h-screen transition-colors duration-300 flex flex-col font-sans relative overflow-hidden ${
        headerBg === "white" 
          ? "light-theme light-mode-active bg-white text-slate-800" 
          : "dark-theme dark-mode-active bg-[#0F172A] text-slate-100 relative overflow-hidden"
      }`}
    >
      
      {/* Exquisite ambient glows (dark mode only) */}
      {headerBg !== "white" && (
        <>
          <div className="ambient-glow-top print:hidden"></div>
          <div className="ambient-glow-bottom print:hidden"></div>
        </>
      )}
      

      {/* App Header Bar with Top Modern Accent Line */}
      <header className={`backdrop-blur-xl border-b shadow-sm print:hidden transition-colors duration-300 relative ${
        headerBg === "white" 
          ? "bg-white/95 border-slate-200 text-slate-800 shadow-slate-900/5" 
          : "bg-slate-800/95 border-slate-700/80 text-slate-100 shadow-lg shadow-black/20"
      }`}>
        {/* Top vibrant accent gradient line */}
        <div className={`h-[2.5px] w-full ${
          headerBg === "white"
            ? "bg-gradient-to-r from-emerald-600 via-teal-500 to-blue-600"
            : "bg-gradient-to-r from-blue-500 via-indigo-500 to-emerald-500"
        }`} />

        <div className="max-w-7xl mx-auto px-4 py-3.5 grid grid-cols-1 md:grid-cols-3 items-center gap-4">
          
          {/* LEFT SECTION: Logo and ECP Title */}
          <div className="flex items-center gap-3 justify-center md:justify-start">
            <div className={`relative w-12 h-12 flex items-center justify-center shrink-0 rounded-full p-1 border shadow-sm transition-all ${
              headerBg === "white"
                ? "bg-white border-emerald-600/40 shadow-emerald-900/10 ring-1 ring-emerald-500/20"
                : "bg-white border-emerald-500/70 shadow-emerald-950/60 ring-2 ring-emerald-500/30"
            }`}>
              <img 
                src="ecp logo1.jpeg" 
                alt="Election Commission of Pakistan Official Logo" 
                onError={(e) => {
                  const target = e.currentTarget;
                  if (!target.src.includes("ecp_logo1.jpeg") && !target.src.includes("ecp%20logo1.jpeg")) {
                    target.src = "ecp_logo1.jpeg";
                  } else if (!target.src.includes("ecp_logo1_07982337.jpeg")) {
                    target.src = "/assets/aistudio/ecp_logo1_07982337.jpeg";
                  } else if (!target.src.includes("ecp_logo.jpg")) {
                    target.src = "ecp_logo.jpg";
                  } else {
                    target.style.display = "none";
                    const fallback = target.nextSibling as HTMLElement;
                    if (fallback) fallback.style.display = "flex";
                  }
                }}
                className="w-full h-full object-contain rounded-full"
              />
              <div className="hidden w-10 h-10 bg-emerald-800 rounded-full flex items-center justify-center font-extrabold text-white text-xs">
                ECP
              </div>
            </div>
            <div>
              <h1 className={`text-base sm:text-lg font-black uppercase tracking-wider text-center md:text-left transition-colors duration-200 ${
                headerBg === "white" 
                  ? "text-emerald-700 drop-shadow-xs" 
                  : "text-emerald-400 drop-shadow-[0_0_10px_rgba(52,211,153,0.35)]"
              }`}>
                Election Commission of Pakistan
              </h1>
              <p className={`text-[11px] font-semibold tracking-tight text-center md:text-left ${
                headerBg === "white" ? "text-emerald-800/90 font-mono font-bold" : "text-slate-400 font-mono font-semibold"
              }`}>
                Inventory Management System
              </p>
            </div>
          </div>

          {/* CENTER SECTION: Standalone Navigation Menus */}
          <div className={`flex items-center justify-center gap-2 p-1.5 rounded-2xl shadow-inner w-fit mx-auto border transition-colors duration-300 ${
            headerBg === "white" 
              ? "bg-slate-100 border-slate-300/90 shadow-slate-200/50" 
              : "bg-slate-900/90 border-slate-700/80 shadow-black/30"
          }`}>
            {/* Standalone Ledger Menu */}
            <button
              id="headerLedgerButton"
              onClick={() => {
                setCurrentView("Ledger");
              }}
              className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all duration-200 cursor-pointer flex items-center gap-2 border select-none ${
                currentView === "Ledger"
                  ? headerBg === "white"
                    ? "bg-blue-600 border-blue-600 text-white shadow-md shadow-blue-500/30 ring-2 ring-blue-400/25"
                    : "bg-gradient-to-r from-blue-600 to-indigo-600 border-blue-400 text-white shadow-lg shadow-blue-900/50"
                  : headerBg === "white"
                    ? "bg-white border-slate-300 text-slate-900 hover:text-blue-700 hover:bg-blue-50/70 shadow-xs font-extrabold"
                    : "bg-slate-800/90 border-slate-700/80 text-slate-300 hover:text-white hover:bg-slate-700/80 hover:border-blue-400/50"
              }`}
            >
              <Package className={`w-3.5 h-3.5 ${currentView === "Ledger" ? "text-white" : headerBg === "white" ? "text-blue-600" : "text-blue-400"}`} />
              <span>Ledger</span>
            </button>

            {/* Standalone Reports Button */}
            <button
              id="headerReportsButton"
              onClick={() => {
                setCurrentView("Reports");
              }}
              className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all duration-200 cursor-pointer flex items-center gap-2 border select-none ${
                currentView === "Reports"
                  ? headerBg === "white"
                    ? "bg-emerald-600 border-emerald-600 text-white shadow-md shadow-emerald-500/30 ring-2 ring-emerald-400/25"
                    : "bg-gradient-to-r from-emerald-600 to-teal-600 border-emerald-400 text-white shadow-lg shadow-emerald-950/60"
                  : headerBg === "white"
                    ? "bg-white border-slate-300 text-slate-900 hover:text-emerald-700 hover:bg-emerald-50/70 shadow-xs font-extrabold"
                    : "bg-slate-800/90 border-slate-700/80 text-slate-300 hover:text-white hover:bg-slate-700/80 hover:border-emerald-400/50"
              }`}
            >
              <FileSpreadsheet className={`w-3.5 h-3.5 ${currentView === "Reports" ? "text-white" : headerBg === "white" ? "text-emerald-600" : "text-emerald-400"}`} />
              <span>Reports</span>
            </button>
          </div>

          {/* RIGHT SECTION: Profile badge and Actions */}
          <div className="flex flex-col sm:flex-row items-center gap-2.5 justify-center md:justify-end w-full md:w-auto">
            {/* Icon-Only Mode Switch Button */}
            <button
              id="themeModeSwitchButton"
              onClick={() => {
                const nextBg = headerBg === "black" ? "white" : "black";
                setHeaderBg(nextBg);
                safeStorage.setItem("header_bg_theme", nextBg);
              }}
              className={`p-2.5 rounded-xl border transition-all duration-200 cursor-pointer flex items-center justify-center select-none shadow-sm hover:scale-105 active:scale-95 ${
                headerBg === "white"
                  ? "bg-slate-100 hover:bg-slate-200 text-slate-800 border-slate-300 shadow-slate-300/50 ring-1 ring-slate-200/80"
                  : "bg-slate-800 hover:bg-slate-700 text-amber-300 border-slate-700/80 shadow-md ring-1 ring-slate-600/40"
              }`}
              title={`Switch to ${headerBg === "white" ? "Dark Mode" : "Light Mode"}`}
              aria-label="Toggle Theme"
            >
              <Moon className={`w-4 h-4 ${headerBg === "white" ? "text-slate-800" : "text-amber-300"} shrink-0`} />
            </button>

            {/* User Profile Badge */}
            <div className={`flex items-center gap-2 p-2 px-3 rounded-xl shadow-xs text-xs font-mono shrink-0 border transition-colors duration-300 ${
              headerBg === "white" 
                ? "bg-slate-50 border-slate-300 text-slate-800" 
                : "bg-slate-800/90 border-slate-700/80 text-slate-200"
            }`}>
              <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse shadow-md shadow-emerald-500/40"></span>
              <span className={headerBg === "white" ? "text-slate-900 font-extrabold" : "text-white font-bold"}>{authenticatedUser}</span>
              <span className={headerBg === "white" ? "text-slate-400 font-bold" : "text-slate-500 font-bold"}>|</span>
              <span className={headerBg === "white" ? "text-blue-700 font-black capitalize" : "text-blue-400 font-black capitalize"}>{authenticatedUserType}</span>
            </div>

            {authenticatedUserType === "SuperAdmin" && (
              <button
                onClick={handleDownloadHtml}
                className={`py-1.5 px-3 rounded-lg text-xs font-bold flex items-center gap-1 transition cursor-pointer border ${
                  headerBg === "white"
                    ? "bg-purple-50 border-purple-200 text-purple-700 hover:bg-purple-600 hover:text-white"
                    : "bg-slate-800/90 hover:bg-purple-700 text-purple-300 hover:text-white border border-slate-700/80"
                }`}
                title="Download Standalone Offline HTML or Project ZIP"
              >
                <Download className={`w-3.5 h-3.5 ${isCompiling ? "animate-spin" : ""}`} />
                {isCompiling ? "Compiling..." : "Export"}
              </button>
            )}

            {authenticatedUserType === "SuperAdmin" && (
              <button
                onClick={() => setShowSolutionsModal(true)}
                className={`py-1.5 px-3 rounded-lg text-xs font-bold flex items-center gap-1 transition cursor-pointer border ${
                  headerBg === "white"
                    ? "bg-emerald-50 border-emerald-200 text-emerald-700 hover:bg-emerald-600 hover:text-white"
                    : "bg-slate-800/90 hover:bg-emerald-700 text-emerald-300 hover:text-white border border-slate-700/80"
                }`}
                title="Supabase Connection Status & RLS Solutions Guide"
              >
                <Database className="w-3.5 h-3.5" />
                <span>Sync</span>
              </button>
            )}

            <button
              onClick={handleLogout}
              className={`py-1.5 px-3 rounded-lg text-xs font-bold flex items-center gap-1 transition cursor-pointer border ${
                headerBg === "white"
                  ? "bg-rose-50 border-rose-200 text-rose-700 hover:bg-rose-600 hover:text-white"
                  : "bg-slate-800/90 hover:bg-rose-700 text-rose-300 hover:text-white border border-slate-700/80"
              }`}
            >
              <LogOut className="w-3.5 h-3.5" /> Logout
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 py-6 space-y-6">

        {syncError && (() => {
          const isNetworkOffline = syncError.toLowerCase().includes("fetch") || 
                                   syncError.toLowerCase().includes("network") || 
                                   syncError.toLowerCase().includes("failed to load") ||
                                   syncError.toLowerCase().includes("failed");
          if (isNetworkOffline) {
            return (
              <div className={`rounded-2xl p-4 flex flex-col md:flex-row items-center justify-between gap-4 shadow-sm backdrop-blur-sm print:hidden border ${
                headerBg === "white"
                  ? "bg-sky-50 border-sky-200 text-sky-900"
                  : "bg-sky-950/40 border-sky-500/30 text-sky-200 shadow-lg shadow-sky-950/20"
              }`}>
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 border ${
                    headerBg === "white"
                      ? "bg-sky-100 text-sky-700 border-sky-300"
                      : "bg-sky-500/10 text-sky-400 border-sky-500/20"
                  }`}>
                    <span className="text-xl font-bold font-mono">i</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className={`text-sm font-black ${headerBg === "white" ? "text-sky-900" : "text-sky-200"}`}>
                      Offline Mode Active — Running Local Database Backup
                    </p>
                    <p className={`text-xs mt-0.5 max-w-4xl leading-relaxed ${headerBg === "white" ? "text-sky-800" : "text-sky-400"}`}>
                      Detail: <code className={`font-mono font-bold px-1 py-0.5 rounded ${
                        headerBg === "white" ? "bg-sky-100 text-sky-900 border border-sky-200" : "bg-sky-950/60 text-sky-300"
                      }`}>Network Disconnected / Offline</code>. 
                      You are loaded locally under offline mode. All assets can still be viewed, edited, created, and deleted! Changes are stored securely in your browser's Local Storage and will sync to Supabase automatically when your internet connection is restored.
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    loadInventoryFromSupabase();
                  }}
                  className={`font-black text-xs px-4 py-2.5 rounded-xl transition shadow-md whitespace-nowrap cursor-pointer hover:scale-[1.02] ${
                    headerBg === "white"
                      ? "bg-sky-600 hover:bg-sky-700 text-white shadow-sky-600/20"
                      : "bg-sky-500 hover:bg-sky-600 text-slate-950"
                  }`}
                >
                  Force Retry Sync
                </button>
              </div>
            );
          }

          return (
            <div className={`rounded-2xl p-4 flex flex-col md:flex-row items-center justify-between gap-4 shadow-sm backdrop-blur-sm print:hidden border ${
              headerBg === "white"
                ? "bg-amber-50 border-amber-200 text-amber-900"
                : "bg-amber-950/40 border-amber-500/30 text-amber-200 shadow-lg shadow-amber-950/20"
            }`}>
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 border ${
                  headerBg === "white"
                    ? "bg-amber-100 text-amber-700 border-amber-300"
                    : "bg-amber-500/10 text-amber-400 border-amber-500/20"
                }`}>
                  <span className="text-xl font-bold font-mono">!</span>
                </div>
                <div className="flex-1 min-w-0">
                  <p className={`text-sm font-black ${headerBg === "white" ? "text-amber-900" : "text-amber-200"}`}>
                    Database Synchronization is Restricted by Row-Level Security
                  </p>
                  <p className={`text-xs mt-0.5 max-w-4xl leading-relaxed ${headerBg === "white" ? "text-amber-800" : "text-amber-400"}`}>
                    Detail: <code className={`font-mono font-bold px-1 py-0.5 rounded ${
                      headerBg === "white" ? "bg-amber-100 text-amber-900 border border-amber-200" : "bg-amber-950/60 text-amber-300"
                    }`}>{syncError}</code>. 
                    All records are currently safely stored on your local computer, but won't be saved on Supabase or synced to other systems until the RLS rules are updated.
                  </p>
                </div>
              </div>
              {authenticatedUserType === "SuperAdmin" && (
                <button
                  onClick={() => setShowSolutionsModal(true)}
                  className={`font-black text-xs px-4 py-2.5 rounded-xl transition shadow-md whitespace-nowrap cursor-pointer hover:scale-[1.02] ${
                    headerBg === "white"
                      ? "bg-amber-600 hover:bg-amber-700 text-white shadow-amber-600/20"
                      : "bg-amber-500 hover:bg-amber-600 text-slate-950"
                  }`}
                >
                  How to Fix in 10 Seconds
                </button>
              )}
            </div>
          );
        })()}
        
        {/* Render Super Admin console control panels */}
        {authenticatedUserType === "SuperAdmin" && (
          <AdminConsole
            systemUsers={systemUsers}
            activeUser={authenticatedUser}
            onUsersUpdate={handlePasswordChanged}
          />
        )}

        {currentView === "Ledger" ? (
          <>
            {/* CATEGORY TABS: IT, FURNITURE & MISCELLANEOUS */}
            <div className={`p-3 rounded-2xl border shadow-sm print:hidden animate-fadeIn flex flex-col sm:flex-row items-center justify-between gap-3 transition-colors duration-200 ${
              headerBg === "white"
                ? "bg-white border-2 border-slate-200 shadow-xs"
                : "bg-slate-800/85 backdrop-blur-xl border border-slate-700/80 shadow-lg"
            }`}>
              {/* Left Side: Three Category Tabs */}
              <div className="flex items-center gap-3 sm:gap-3.5 flex-wrap w-full sm:w-auto justify-start">
                {/* IT Equipments Tab */}
                <button
                  type="button"
                  id="tabButtonIT"
                  onClick={() => handleTabChange("IT")}
                  className={`px-5 py-3 sm:px-6 sm:py-3.5 rounded-2xl text-sm sm:text-base font-black uppercase tracking-wider flex items-center gap-3 border-2 transition-all duration-200 cursor-pointer select-none active:scale-[0.98] hover:scale-[1.02] ${
                    currentActiveTab === "IT"
                      ? headerBg === "white"
                        ? "bg-blue-600 border-blue-600 text-white shadow-lg shadow-blue-500/30 ring-2 ring-blue-400/40"
                        : "bg-gradient-to-r from-blue-600 to-indigo-600 border-blue-400 text-white shadow-xl shadow-blue-900/50 ring-2 ring-blue-400/50"
                      : headerBg === "white"
                        ? "bg-white hover:bg-blue-50/90 border-slate-300 text-slate-900 hover:text-blue-700 shadow-sm font-black"
                        : "bg-slate-900/80 hover:bg-slate-800 border-slate-700/80 hover:border-blue-500/50 text-slate-200 hover:text-white font-extrabold shadow-sm"
                  }`}
                  title="Switch to IT Equipment & Hardware Inventory"
                >
                  <Laptop className={`w-5 h-5 sm:w-5.5 sm:h-5.5 shrink-0 ${currentActiveTab === "IT" ? "text-white" : headerBg === "white" ? "text-blue-600" : "text-blue-400"}`} />
                  <span>IT Equipments</span>
                  <span className={`px-2.5 py-1 rounded-full text-xs font-mono font-black ${
                    currentActiveTab === "IT"
                      ? "bg-white/25 text-white"
                      : headerBg === "white"
                        ? "bg-blue-100 text-blue-900 border border-blue-200"
                        : "bg-blue-950/90 text-blue-300 border border-blue-800/80"
                  }`}>
                    {itTabCount}
                  </span>
                </button>

                {/* Furniture Tab */}
                <button
                  type="button"
                  id="tabButtonFurniture"
                  onClick={() => handleTabChange("Furniture")}
                  className={`px-5 py-3 sm:px-6 sm:py-3.5 rounded-2xl text-sm sm:text-base font-black uppercase tracking-wider flex items-center gap-3 border-2 transition-all duration-200 cursor-pointer select-none active:scale-[0.98] hover:scale-[1.02] ${
                    currentActiveTab === "Furniture"
                      ? headerBg === "white"
                        ? "bg-amber-600 border-amber-600 text-white shadow-lg shadow-amber-500/30 ring-2 ring-amber-400/40"
                        : "bg-gradient-to-r from-amber-600 to-orange-600 border-amber-400 text-white shadow-xl shadow-amber-900/50 ring-2 ring-amber-400/50"
                      : headerBg === "white"
                        ? "bg-white hover:bg-amber-50/90 border-slate-300 text-slate-900 hover:text-amber-800 shadow-sm font-black"
                        : "bg-slate-900/80 hover:bg-slate-800 border-slate-700/80 hover:border-amber-500/50 text-slate-200 hover:text-white font-extrabold shadow-sm"
                  }`}
                  title="Switch to Furniture & Fixtures Inventory"
                >
                  <Sofa className={`w-5 h-5 sm:w-5.5 sm:h-5.5 shrink-0 ${currentActiveTab === "Furniture" ? "text-white" : headerBg === "white" ? "text-amber-600" : "text-amber-400"}`} />
                  <span>Furniture</span>
                  <span className={`px-2.5 py-1 rounded-full text-xs font-mono font-black ${
                    currentActiveTab === "Furniture"
                      ? "bg-white/25 text-white"
                      : headerBg === "white"
                        ? "bg-amber-100 text-amber-950 border border-amber-200"
                        : "bg-amber-950/90 text-amber-300 border border-amber-800/80"
                  }`}>
                    {furnitureTabCount}
                  </span>
                </button>

                {/* Miscellaneous Tab */}
                <button
                  type="button"
                  id="tabButtonMisc"
                  onClick={() => handleTabChange("Misc")}
                  className={`px-5 py-3 sm:px-6 sm:py-3.5 rounded-2xl text-sm sm:text-base font-black uppercase tracking-wider flex items-center gap-3 border-2 transition-all duration-200 cursor-pointer select-none active:scale-[0.98] hover:scale-[1.02] ${
                    currentActiveTab === "Misc"
                      ? headerBg === "white"
                        ? "bg-emerald-700 border-emerald-700 text-white shadow-lg shadow-emerald-600/30 ring-2 ring-emerald-500/40"
                        : "bg-gradient-to-r from-emerald-600 to-teal-600 border-emerald-400 text-white shadow-xl shadow-emerald-950/60 ring-2 ring-emerald-400/50"
                      : headerBg === "white"
                        ? "bg-white hover:bg-emerald-50/90 border-slate-300 text-slate-900 hover:text-emerald-800 shadow-sm font-black"
                        : "bg-slate-900/80 hover:bg-slate-850 border-slate-700/80 hover:border-emerald-500/50 text-slate-200 hover:text-white font-extrabold shadow-sm"
                  }`}
                  title="Switch to Miscellaneous & Utility Equipment"
                >
                  <Package className={`w-5 h-5 sm:w-5.5 sm:h-5.5 shrink-0 ${currentActiveTab === "Misc" ? "text-white" : headerBg === "white" ? "text-emerald-600" : "text-emerald-400"}`} />
                  <span>Miscellaneous</span>
                  <span className={`px-2.5 py-1 rounded-full text-xs font-mono font-black ${
                    currentActiveTab === "Misc"
                      ? "bg-white/25 text-white"
                      : headerBg === "white"
                        ? "bg-emerald-100 text-emerald-950 border border-emerald-200"
                        : "bg-emerald-950/90 text-emerald-300 border border-emerald-800/80"
                  }`}>
                    {miscTabCount}
                  </span>
                </button>
              </div>

              {/* Right Side: Divisional Scope Filter Dropdown */}
              <div className="flex items-center gap-2.5 w-full sm:w-auto justify-end">
                {(authenticatedUserType === "SuperAdmin" || (authenticatedUser && authenticatedUser.toUpperCase().startsWith("REC"))) ? (
                  <div className={`flex items-center gap-2 px-3 py-2 rounded-xl border text-xs shadow-sm transition-colors ${
                    headerBg === "white"
                      ? "bg-white border-slate-300 text-slate-800 shadow-xs font-bold"
                      : "bg-slate-800/90 border-slate-700/80 text-slate-200"
                  }`} title="Switch Divisional Station View">
                    <Shield className="w-4 h-4 text-emerald-500 shrink-0" />
                    <span className={`text-[11px] font-black uppercase tracking-wider select-none ${
                      headerBg === "white" ? "text-slate-600" : "text-slate-400 font-mono"
                    }`}>
                      Division:
                    </span>
                    <select
                      value={currentSupervisorFilterTarget}
                      onChange={(e) => handleSupervisorFilterChange(e.target.value)}
                      className={`bg-transparent text-xs font-black focus:outline-none cursor-pointer ${
                        headerBg === "white" ? "text-blue-700" : "text-blue-400"
                      }`}
                    >
                      <option value="All Offices" className={headerBg === "white" ? "text-slate-900 font-bold" : "bg-slate-900 text-slate-100 font-bold"}>
                        🏢 All Offices ({stationCounts["All Offices"] || 0})
                      </option>
                      {Object.keys(systemUsers)
                        .filter(u => systemUsers[u].type === "Standard")
                        .map(node => (
                          <option key={node} value={node} className={headerBg === "white" ? "text-slate-900 font-bold" : "bg-slate-900 text-slate-100 font-bold"}>
                            {node} ({stationCounts[node] || 0})
                          </option>
                        ))}
                    </select>
                  </div>
                ) : (
                  <div className={`flex items-center gap-2 px-3 py-1.5 rounded-xl border text-xs font-mono ${
                    headerBg === "white"
                      ? "bg-white border-slate-200 text-slate-700 shadow-xs"
                      : "bg-slate-800/90 border-slate-700/80 text-slate-200"
                  }`}>
                    <span className={`text-xs font-bold ${headerBg === "white" ? "text-[#263445]" : "text-slate-300"}`}>
                      Station: <strong className={headerBg === "white" ? "text-blue-600" : "text-blue-400 font-bold"}>{authenticatedUser}</strong>
                    </span>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono border ${
                      headerBg === "white"
                        ? "bg-blue-100 text-blue-700 border-blue-300"
                        : "bg-slate-900/90 text-blue-300 border-slate-700/80"
                    }`}>
                      {stationCounts[authenticatedUser] || 0} Records
                    </span>
                  </div>
                )}
              </div>
            </div>
            <div className="hidden print:block text-slate-900 mb-6 border-b-2 border-slate-800 pb-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <img 
                    src="ecp logo1.jpeg" 
                    alt="ECP Logo" 
                    onError={(e) => {
                      const target = e.currentTarget;
                      if (!target.src.includes("ecp_logo1.jpeg") && !target.src.includes("ecp%20logo1.jpeg")) {
                        target.src = "ecp_logo1.jpeg";
                      } else if (!target.src.includes("ecp_logo.jpg")) {
                        target.src = "ecp_logo.jpg";
                      }
                    }}
                    className="w-16 h-16 object-contain rounded-full bg-white p-1 border border-slate-300 shadow-sm" 
                  />
                  <div>
                    <h1 className="text-xl font-black uppercase tracking-wide text-slate-950">
                      {getReportHeaderTitle(currentSupervisorFilterTarget || authenticatedUser)}
                    </h1>
                    <p className="text-xs font-bold text-emerald-700 tracking-widest uppercase">
                      INVENTORY LEGER AND TRACKING REPORT
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-[10px] font-black uppercase tracking-wide text-slate-500 block">
                    Active Location
                  </span>
                  <span className="text-sm font-black text-blue-700 block mt-0.5">
                    {currentSupervisorFilterTarget}
                  </span>
                </div>
              </div>
              <div className="flex justify-between items-center mt-4 pt-2 border-t border-slate-200 text-xs text-slate-600">
                <div>
                  Report Category: <strong className="text-slate-900">{currentActiveTab === "IT" ? "IT Equipment" : currentActiveTab === "Furniture" ? "Furniture Assets" : "Miscellaneous"}</strong>
                </div>
                <div>
                  Date Generated: <strong className="text-slate-900">{new Date().toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' })}</strong>
                </div>
              </div>
            </div>

            {/* Ledger actions spreadsheet and CRUD controls */}
             <RegistryLedger
              key={currentSupervisorFilterTarget}
              currentTab={currentActiveTab}
              scopeData={activeScopeData}
              allLocationData={databaseStore}
              currentNodeLocation={currentSupervisorFilterTarget}
              isWriteAllowed={isWriteAllowed}
              isSuperAdmin={authenticatedUserType === "SuperAdmin"}
              isLightMode={headerBg === "white"}
              onItemCommit={handleItemCommit}
              onItemsBulkCommit={handleItemsBulkCommit}
              onItemDelete={handleItemDelete}
              onItemDeleteAll={handleItemDeleteAll}
              onTabChange={handleTabChange}
            />
          </>
        ) : (
          <div className="animate-fadeIn">
            <ReportMenu
              currentTab={currentActiveTab}
              currentNodeLocation={currentSupervisorFilterTarget}
              databaseStore={databaseStore}
              initialReportType={selectedReportType}
              onReportTypeChange={setSelectedReportType}
              initialWorkingSubFilter={reportWorkingSubFilter}
              initialNonWorkingSubFilter={reportNonWorkingSubFilter}
              isSuperAdmin={authenticatedUserType === "SuperAdmin"}
              isLightMode={headerBg === "white"}
            />
          </div>
        )}

      </main>



      {showSolutionsModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 print:hidden">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-2xl shadow-xl shadow-slate-950/50 flex flex-col overflow-hidden max-h-[90vh]">
            <div className="p-6 border-b border-slate-800 flex justify-between items-center bg-slate-900/50">
              <h3 className="text-md font-black text-white flex items-center gap-2">
                <Shield className="w-5 h-5 text-amber-400" /> Supabase Database RLS Repair Panel
              </h3>
              <button 
                onClick={() => setShowSolutionsModal(false)}
                className="text-slate-400 hover:text-white font-bold text-sm cursor-pointer"
              >
                ✕ Close
              </button>
            </div>
            
            <div className="p-6 space-y-4 overflow-y-auto text-xs leading-relaxed">
              <p className="text-slate-300">
                The error <code className="bg-slate-950 px-1 py-0.5 rounded text-rose-400 font-mono">violates row-level security policy</code> occurs when Supabase Row-Level Security (RLS) is enabled but does not authorize anonymous clients to read or write database items.
              </p>

              <div className="bg-amber-500/5 border border-amber-500/20 rounded-xl p-3.5 space-y-2">
                <h4 className="font-extrabold text-amber-200">How to Fix This in Your Supabase Console:</h4>
                <ol className="list-decimal list-inside space-y-1.5 text-slate-300">
                  <li>Go to your <a href="https://supabase.com/dashboard" target="_blank" rel="noopener noreferrer" className="text-cyan-400 underline hover:text-cyan-300 font-bold inline-flex items-center gap-0.5">Supabase Dashboard ↗</a>.</li>
                  <li>Click on your project, then open the <strong>SQL Editor</strong> tab on the left sidebar.</li>
                  <li>Click <strong>New Query</strong>, paste the SQL commands below, and click <strong>Run</strong>:</li>
                </ol>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between items-center text-[10px] text-slate-400 font-mono">
                  <span>sql schema patches</span>
                  <button
                    onClick={() => {
                      const sqlCode = `-- Enable permissions for anonymous connections on the inventory table\nALTER TABLE inventory DISABLE ROW LEVEL SECURITY;\n\n-- Direct alternative (if you want RLS enabled, run this instead):\n-- CREATE POLICY "Allow anon select" ON inventory FOR SELECT TO anon USING (true);\n-- CREATE POLICY "Allow anon insert" ON inventory FOR INSERT TO anon WITH CHECK (true);\n-- CREATE POLICY "Allow anon update" ON inventory FOR UPDATE TO anon USING (true) WITH CHECK (true);\n-- CREATE POLICY "Allow anon delete" ON inventory FOR DELETE TO anon USING (true);`;
                      navigator.clipboard.writeText(sqlCode);
                      alert("SQL command copied to clipboard!");
                    }}
                    className="bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold px-2 py-1 rounded transition cursor-pointer"
                  >
                    Copy SQL
                  </button>
                </div>
                <pre className="bg-slate-950 p-4 rounded-xl font-mono text-[11px] text-emerald-400 overflow-x-auto border border-slate-850">
{`-- SQL to remove database permission restrictions on inventory table
ALTER TABLE inventory DISABLE ROW LEVEL SECURITY;

-- Alternative: Keep RLS enabled but allow public anonymous reads and writes
CREATE POLICY "Allow anon select" ON inventory FOR SELECT TO anon USING (true);
CREATE POLICY "Allow anon insert" ON inventory FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "Allow anon update" ON inventory FOR UPDATE TO anon USING (true) WITH CHECK (true);
CREATE POLICY "Allow anon delete" ON inventory FOR DELETE TO anon USING (true);`}
                </pre>
              </div>
              
              <div className="text-slate-400 text-[11px]">
                💡 Running either of these SQL statements on your Supabase project instantly enables seamless offline-first synchronization, making records saved from any device immediately appear in your remote table and on the live dashboards!
              </div>
            </div>

            <div className="p-4 bg-slate-950/40 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => setShowSolutionsModal(false)}
                className="bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs px-4 py-2 rounded-xl transition cursor-pointer"
              >
                Close Panel
              </button>
            </div>
          </div>
        </div>
      )}

      {downloadModalData.isOpen && (
        <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md z-50 flex items-center justify-center p-4 print:hidden">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg shadow-2xl shadow-slate-950/70 flex flex-col overflow-hidden max-h-[90vh]">
            <div className="p-6 border-b border-slate-800 flex justify-between items-center bg-slate-900/50">
              <h3 className="text-md font-bold text-white flex items-center gap-2">
                <Download className="w-5 h-5 text-amber-500 animate-bounce" /> Offline App & Backup Exporter
              </h3>
              <button 
                onClick={() => setDownloadModalData({ isOpen: false, html: "" })}
                className="text-slate-400 hover:text-white font-bold text-sm cursor-pointer"
              >
                ✕ Close
              </button>
            </div>
            
            <div className="p-6 space-y-5 overflow-y-auto text-xs leading-relaxed text-slate-300">
              <div className="p-3 bg-slate-950/50 rounded-xl border border-slate-800/80 space-y-2">
                <p className="font-semibold text-white">📦 What is this?</p>
                <p className="text-slate-400">
                  This exports a fully dynamic, self-contained single-file HTML version of the ECP Asset Inventory application pre-seeded with all <strong>{databaseStore.length}</strong> currently loaded inventory items.
                </p>
              </div>

              {/* Cookie block specific warning */}
              {isCookieBlocked && (
                <div className="p-3.5 bg-rose-500/10 border border-rose-500/20 rounded-xl space-y-2 text-rose-200">
                  <p className="font-extrabold flex items-center gap-1.5 text-xs text-rose-400">
                    ⚠️ Browser Security Cookie Block Detected!
                  </p>
                  <p className="text-[11px] leading-relaxed text-slate-300">
                    Your web browser is blocking the security session cookies required by the preview server proxy (very common in <strong>Safari, iOS devices, or Private/Incognito tabs</strong>). This causes standard server downloads to fail or download raw login error screens.
                  </p>
                  <p className="text-[11px] font-bold text-amber-200 bg-slate-950/60 p-2.5 rounded border border-rose-500/10">
                    💡 <strong>How to download instantly:</strong> Click the <strong>"Open in new tab"</strong> button at the top-right of your preview screen (or reload this page in a direct browser tab). Once open in its own tab, download options will build and save 100% perfectly with no blocks!
                  </p>
                </div>
              )}

              <div className="p-3.5 bg-amber-500/10 rounded-xl border border-amber-500/20 space-y-1.5">
                <p className="font-bold text-amber-200 flex items-center gap-1.5">⚠️ Crucial Browser Preview Notice:</p>
                <p className="text-slate-300 text-[11px] leading-relaxed">
                  Because this application is running inside a <strong>sandboxed preview iframe</strong>, web browsers often block direct file downloads (Option 1) silently or serve stale cache files.
                </p>
                <p className="text-slate-300 text-[11px] font-medium leading-relaxed bg-slate-950/50 p-2 rounded border border-slate-800/80 mt-1">
                  💡 <strong>To guarantee a perfect download:</strong> Open the live preview in a <strong>New Tab</strong> using the arrow icon at the top right of the preview pane, then download the HTML file there! Alternatively, use <strong>Option 2 (Copy Code)</strong> to save it instantly.
                </p>
              </div>

              <div className="space-y-3">
                <h4 className="font-extrabold text-slate-200">Choose an Export Method:</h4>
                
                {/* Method 1: Try Direct Download */}
                <div className="border border-slate-800 bg-slate-950/30 rounded-xl p-4 space-y-3">
                  <div className="flex items-start gap-2">
                    <span className="bg-amber-500/10 text-amber-400 px-2 py-0.5 rounded text-[10px] font-bold font-mono">Option 1</span>
                    <div>
                      <p className="font-bold text-white">Download Standalone index.html File (Recommended for GitHub Pages)</p>
                      <p className="text-slate-400 text-[11px]">Downloads a single, compiled <code className="text-amber-400">index.html</code> file with the absolute latest code representing your current preview. Upload this file directly to your GitHub repository to host it with GitHub Pages instantly!</p>
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      try {
                        const blob = new Blob([downloadModalData.html], { type: 'text/html' });
                        const url = URL.createObjectURL(blob);
                        const link = document.createElement('a');
                        link.href = url;
                        link.download = 'index.html';
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                        URL.revokeObjectURL(url);
                      } catch (e) {
                        alert("File download block encountered. Please use Option 2 below!");
                      }
                    }}
                    className="w-full bg-amber-600 hover:bg-amber-500 text-slate-950 font-black py-2.5 px-4 rounded-xl transition cursor-pointer text-center text-xs flex items-center justify-center gap-1.5"
                  >
                    <Download className="w-4 h-4" /> Save as index.html (GitHub-Ready)
                  </button>
                </div>

                {/* Method 2: Copy to Clipboard Fallback */}
                <div className="border border-slate-800 bg-slate-950/30 rounded-xl p-4 space-y-3">
                  <div className="flex items-start gap-2">
                    <span className="bg-blue-500/10 text-blue-400 px-2 py-0.5 rounded text-[10px] font-bold font-mono">Option 2</span>
                    <div>
                      <p className="font-bold text-white">Copy Code to Clipboard</p>
                      <p className="text-slate-400 text-[11px]">Copy the fully compiled standalone source code and paste it manually into a local file named <code className="text-amber-400">index.html</code>.</p>
                    </div>
                  </div>
                  <button
                    onClick={async () => {
                      try {
                        await navigator.clipboard.writeText(downloadModalData.html);
                        setCopiedHtml(true);
                        setTimeout(() => setCopiedHtml(false), 3000);
                      } catch (e) {
                        alert("Failed to copy automatically. Please try manual copy.");
                      }
                    }}
                    className={`w-full py-2.5 px-4 rounded-xl font-bold transition cursor-pointer text-center text-xs flex items-center justify-center gap-1.5 ${
                      copiedHtml 
                        ? "bg-emerald-600 text-white" 
                        : "bg-slate-800 hover:bg-slate-700 text-white border border-slate-700"
                    }`}
                  >
                    {copiedHtml ? (
                      <>✨ Copied Successfully!</>
                    ) : (
                      <>Copy Entire HTML Source Code</>
                    )}
                  </button>
                  {copiedHtml && (
                    <div className="p-3 bg-emerald-500/5 border border-emerald-500/20 rounded-lg text-emerald-400 text-[11px] animate-fade-in">
                      💡 <strong>Next steps:</strong> Open any text editor (like Notepad or VS Code), paste the code (<kbd>Ctrl+V</kbd> or <kbd>Cmd+V</kbd>), and save the file with the name <strong>index.html</strong>. You can then double click it to run it completely offline or host it anywhere!
                    </div>
                  )}
                </div>

                {/* Method 3: Download Complete Project ZIP */}
                <div className="border border-slate-800 bg-slate-950/30 rounded-xl p-4 space-y-3">
                  <div className="flex items-start gap-2">
                    <span className="bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded text-[10px] font-bold font-mono">Option 3</span>
                    <div>
                      <p className="font-bold text-white">Download Complete Project ZIP (.zip)</p>
                      <p className="text-slate-400 text-[11px]">Downloads a complete, standard zip package containing the full source code (React, Tailwind, Vite configurations, etc.). The root <code className="text-amber-400">index.html</code> inside this ZIP is the complete, pre-compiled standalone application (~300KB+) ready for instant offline use and direct GitHub Pages deployment!</p>
                    </div>
                  </div>
                  <button
                    onClick={async () => {
                      try {
                        let response = await fetch('/api/download-project-zip', {
                          method: 'POST',
                          headers: { 'Content-Type': 'application/json' },
                          body: JSON.stringify({ html: downloadModalData.html })
                        });
                        if (!response.ok) {
                          response = await fetch('/api/download-project-zip');
                        }
                        if (!response.ok) {
                          throw new Error('Failed to download project zip');
                        }
                        const contentType = response.headers.get("content-type") || "";
                        if (contentType.includes("text/html")) {
                          const text = await response.clone().text();
                          if (text.includes("blocking a required security cookie") || text.includes("Safari") || text.includes("DOCTYPE")) {
                            throw new Error("auth_cookie_blocked");
                          }
                        }
                        const blob = await response.blob();
                        const url = URL.createObjectURL(blob);
                        const link = document.createElement('a');
                        link.href = url;
                        link.download = 'ECP_Asset_Inventory_Project.zip';
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                        URL.revokeObjectURL(url);
                      } catch (e: any) {
                        console.error(e);
                        setIsCookieBlocked(true);
                        if (e.message === "auth_cookie_blocked") {
                          alert("⚠️ Security Cookie Blocked by Browser:\n\nBecause this preview is running in an iframe, your browser is blocking required authentication cookies (very common in Safari, iOS, or private browsing tabs).\n\nPlease click the 'Open in new tab' button at the top-right of your screen to open the app, then click download. It will work 100% perfectly there!");
                        } else {
                          alert("Failed to download project ZIP. Please try downloading from a New Tab.");
                        }
                      }
                    }}
                    className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-black py-2.5 px-4 rounded-xl transition cursor-pointer text-center text-xs flex items-center justify-center gap-1.5"
                  >
                    <Download className="w-4 h-4" /> Download Complete Project ZIP
                  </button>
                </div>
              </div>
            </div>

            <div className="p-4 bg-slate-950/40 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => setDownloadModalData({ isOpen: false, html: "" })}
                className="bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs px-4 py-2 rounded-xl transition cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}

