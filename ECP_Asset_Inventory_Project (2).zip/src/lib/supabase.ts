import { createClient } from '@supabase/supabase-js';

const supabaseUrl = "https://zxseanhiuuoglxtecuoh.supabase.co";
const supabaseKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inp4c2VhbmhpdXVvZ2x4dGVjdW9oIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODE2NDEzOTgsImV4cCI6MjA5NzIxNzM5OH0.VjYSKGrUI9nUZS7Idwuy5gCy2j2Sh4zaAVD7WXrjCI8";

export const supabase = createClient(supabaseUrl, supabaseKey);
