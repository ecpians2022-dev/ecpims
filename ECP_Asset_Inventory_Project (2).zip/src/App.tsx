/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { supabase } from './lib/supabase';
import { InventoryItem, UserAccount } from './types';
import LoginScreen from './components/LoginScreen';
import AdminConsole from './components/AdminConsole';
import ReportMenu from './components/ReportMenu';
import RegistryLedger from './components/RegistryLedger';
import { LogOut, Laptop, Sofa, Package, Shield, Settings, UserCheck, Download, FileSpreadsheet, CheckCircle2, AlertTriangle, Sun, Moon, RotateCcw } from 'lucide-react';

// Robust LocalStorage wrapper to prevent SecurityError/DOMException crashes under file:// protocols
const safeStorageMemory: Record<string, string> = {};
const safeStorage = {
  getItem: (key: string): string | null => {
    try {
      return localStorage.getItem(key);
    } catch (e) {
      console.warn(`localStorage.getItem failed for key "${key}":`, e);
      return safeStorageMemory[key] || null;
    }
  },
  setItem: (key: string, value: string): void => {
    try {
      localStorage.setItem(key, value);
    } catch (e) {
      console.warn(`localStorage.setItem failed for key "${key}":`, e);
      safeStorageMemory[key] = value;
    }
  },
  removeItem: (key: string): void => {
    try {
      localStorage.removeItem(key);
    } catch (e) {
      console.warn(`localStorage.removeItem failed for key "${key}":`, e);
      delete safeStorageMemory[key];
    }
  }
};

// Helper to retrieve initial database store robustly, preferring preseeded dataset when run offline or if cache is empty/blocked
const getInitialDatabaseStore = (): InventoryItem[] => {
  try {
    // 1. Try to read from preseeded DOM element first (highest priority for standalone/offline files)
    let preseededData: InventoryItem[] | null = null;
    if (typeof document !== "undefined") {
      const preseedEl = document.getElementById("preseed-inventory-data");
      if (preseedEl) {
        try {
          preseededData = JSON.parse(preseedEl.textContent || "");
        } catch (_) {}
      }
    }

    // 2. Try to read from localStorage
    let cachedStr = safeStorage.getItem("inventory_db");
    let cachedData: InventoryItem[] | null = null;
    if (cachedStr) {
      try {
        cachedData = JSON.parse(cachedStr);
      } catch (_) {}
    }

    if (preseededData && preseededData.length > 0) {
      const preseededTimestamp = Number((typeof window !== "undefined" && (window as any).preseededTimestamp) || 0);
      const cachedTime = Number(safeStorage.getItem("inventory_db_timestamp") || "0");
      
      // Prioritize preseeded data ONLY if cached data is empty or if the preseeded file contains explicitly newer data
      if (!cachedData || cachedData.length === 0 || preseededTimestamp > cachedTime) {
        return preseededData;
      }
    }

    return cachedData || preseededData || [];
  } catch (e) {
    console.error("Error loading initial database store:", e);
    return [];
  }
};

// Global helper to persist the cache and maintain robust timestamp synchronization for offline usage
const saveInventoryStore = (store: InventoryItem[]) => {
  try {
    const serialized = JSON.stringify(store);
    const nowStr = Date.now().toString();
    safeStorage.setItem("inventory_db", serialized);
    safeStorage.setItem("inventory_db_timestamp", nowStr);
    
    // Maintain offline-specific keys to ensure complete backward compatibility
    safeStorage.setItem("inventory_db_offline", serialized);
    safeStorage.setItem("inventory_db_offline_timestamp", nowStr);
  } catch (e) {
    console.warn("Failed to persist inventory store:", e);
  }
};

// Robust normalization helpers to prevent database casing discrepancies
function normalizeNodeLocation(raw: string): string {
  const trimmed = (raw || "").trim();
  const lower = trimmed.toLowerCase();
  
  if (lower === "rec kohat") return "REC Kohat";
  if (lower === "dec kohat") return "DEC Kohat";
  if (lower === "dec hangu") return "DEC Hangu";
  if (lower === "dec karak") return "DEC Karak";
  if (lower === "dec orakzai") return "DEC Orakzai";
  if (lower === "dec kurram") return "DEC Kurram";
  if (lower === "system_settings") return "SYSTEM_SETTINGS";
  
  if (lower.startsWith("dec ")) {
    const rest = trimmed.substring(4).trim();
    const capitalizedRest = rest.charAt(0).toUpperCase() + rest.slice(1);
    return `DEC ${capitalizedRest}`;
  }
  if (lower.startsWith("rec ")) {
    const rest = trimmed.substring(4).trim();
    const capitalizedRest = rest.charAt(0).toUpperCase() + rest.slice(1);
    return `REC ${capitalizedRest}`;
  }
  
  return trimmed;
}

function normalizeTabContext(raw: string): "IT" | "Furniture" | "Misc" {
  const trimmed = (raw || "").trim().toLowerCase();
  if (trimmed === "it" || trimmed === "it equipment" || trimmed.includes("it")) {
    return "IT";
  }
  if (trimmed === "furniture" || trimmed === "furniture assets" || trimmed.includes("furn")) {
    return "Furniture";
  }
  if (trimmed === "misc" || trimmed === "miscellaneous" || trimmed.includes("misc")) {
    return "Misc";
  }
  return "IT";
}

function normalizeWorkingStatus(raw: string): "Working" | "Non-Working" {
  const trimmed = (raw || "").trim().toLowerCase();
  if (trimmed.includes("non")) {
    return "Non-Working";
  }
  return "Working";
}

function normalizeWorkingSubStatus(raw: any): "Issued" | "In-stock" | null {
  if (!raw) return null;
  const trimmed = String(raw).trim().toLowerCase();
  if (trimmed.includes("issued") || trimmed.includes("assign")) {
    return "Issued";
  }
  if (trimmed.includes("stock") || trimmed.includes("in")) {
    return "In-stock";
  }
  return null;
}

function normalizeNonWorkingSubStatus(raw: any): "Needs to repair" | "Ready for condemnation" | null {
  if (!raw) return null;
  const trimmed = String(raw).trim().toLowerCase();
  if (trimmed.includes("repair") || trimmed.includes("fix")) {
    return "Needs to repair";
  }
  if (trimmed.includes("condemn") || trimmed.includes("ready")) {
    return "Ready for condemnation";
  }
  return null;
}

const DEFAULT_USERS: Record<string, UserAccount> = {
  "Super Admin": { password: "superadmin123", type: "SuperAdmin" },
  "REC Kohat": { password: "admin123", type: "Standard" },
  "DEC Kohat": { password: "kohat123", type: "Standard" },
  "DEC Hangu": { password: "hangu123", type: "Standard" },
  "DEC Karak": { password: "karak123", type: "Standard" },
  "DEC Orakzai": { password: "orakzai123", type: "Standard" },
  "DEC Kurram": { password: "kurram123", type: "Standard" }
};

export default function App() {
  // Authentication states
  const [authenticatedUser, setAuthenticatedUser] = useState<string>("");
  const [authenticatedUserType, setAuthenticatedUserType] = useState<"Standard" | "SuperAdmin">("Standard");
  const [systemUsers, setSystemUsers] = useState<Record<string, UserAccount>>(DEFAULT_USERS);
  const lastUsersWriteTime = useRef<number>(0);
  
  // App context states
  const [currentActiveTab, setCurrentActiveTab] = useState<"IT" | "Furniture" | "Misc">("IT");
  const [currentSupervisorFilterTarget, setCurrentSupervisorFilterTarget] = useState<string>("REC Kohat");
  const [currentView, setCurrentView] = useState<"Ledger" | "Reports">("Ledger");
  const [selectedReportType, setSelectedReportType] = useState<"working" | "nonworking">("working");
  const [reportWorkingSubFilter, setReportWorkingSubFilter] = useState<string>("All");
  const [reportNonWorkingSubFilter, setReportNonWorkingSubFilter] = useState<string>("All");
  const [reportsDropdownOpen, setReportsDropdownOpen] = useState<boolean>(false);
   const [headerBg, setHeaderBg] = useState<"black" | "white">((): "black" | "white" => {
    const saved = safeStorage.getItem("header_bg_theme");
    return (saved === "white" || saved === "black") ? saved : "black";
  });

  // Ledger / Inventory records state
  const [databaseStore, setDatabaseStore] = useState<InventoryItem[]>(() => {
    return getInitialDatabaseStore();
  });
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isLiveSyncActive, setIsLiveSyncActive] = useState<boolean>(true);

  // Helper to add item to dirty set (for pending offline edits)
  const trackDirtyId = (id: number) => {
    try {
      const stored = safeStorage.getItem("inventory_db_dirty");
      const list: number[] = stored ? JSON.parse(stored) : [];
      if (!list.includes(id)) {
        list.push(id);
        safeStorage.setItem("inventory_db_dirty", JSON.stringify(list));
      }
    } catch (_) {}
  };

  // Helper to remove item from dirty set after successful remote save
  const removeDirtyId = (id: number) => {
    try {
      const stored = safeStorage.getItem("inventory_db_dirty");
      if (stored) {
        const list: number[] = JSON.parse(stored);
        const filtered = list.filter(item => item !== id);
        safeStorage.setItem("inventory_db_dirty", JSON.stringify(filtered));
      }
    } catch (_) {}
  };
  const [syncError, setSyncError] = useState<string | null>(null);
  const [showSolutionsModal, setShowSolutionsModal] = useState<boolean>(false);
  const [downloadModalData, setDownloadModalData] = useState<{ isOpen: boolean; html: string }>({ isOpen: false, html: "" });
  const [copiedHtml, setCopiedHtml] = useState<boolean>(false);
  const [isCompiling, setIsCompiling] = useState<boolean>(false);
  const [isCookieBlocked, setIsCookieBlocked] = useState<boolean>(false);
  const [detectedDbColumns, setDetectedDbColumns] = useState<string[]>([]);

  // Persistent list of locally deleted item IDs to prevent ghost restoration on sync errors / empty db RLS select queries
  const [deletedIds, setDeletedIds] = useState<number[]>(() => {
    try {
      const stored = safeStorage.getItem("deleted_items_queue");
      return stored ? JSON.parse(stored) : [];
    } catch (e) {
      return [];
    }
  });

  const trackDeletedId = (id: number) => {
    setDeletedIds(prev => {
      if (prev.includes(id)) return prev;
      const next = [...prev, id];
      safeStorage.setItem("deleted_items_queue", JSON.stringify(next));
      return next;
    });
  };

  // Dynamically map camelCase properties of InventoryItem to target table's columns (handles case-insensitive columns in DB)
  const mapToDbPayload = (item: any) => {
    const payload: any = {};
    const fieldMappings: Record<string, string[]> = {
      timestampId: ["timestampid", "timestamp_id", "timestampId", "id"],
      nodeLocation: ["nodelocation", "node_location", "nodeLocation"],
      tabContext: ["tabcontext", "tab_context", "tabContext"],
      name: ["name"],
      serial: ["serial"],
      model: ["model"],
      category: ["category"],
      receivedFrom: ["receivedfrom", "received_from", "receivedFrom"],
      date: ["date"],
      workingStatus: ["workingstatus", "working_status", "workingStatus"],
      workingSubStatus: ["workingsubstatus", "working_sub_status", "workingSubStatus"],
      issueTo: ["issueto", "issue_to", "issueTo"],
      designation: ["designation"],
      issuedDate: ["issueddate", "issued_date", "issuedDate"],
      nonWorkingSubStatus: ["nonworkingsubstatus", "non_working_sub_status", "nonWorkingSubStatus"],
      remarks: ["remarks"]
    };

    if (!detectedDbColumns || detectedDbColumns.length === 0) {
      return item;
    }

    for (const [camelKey, possibleDbKeys] of Object.entries(fieldMappings)) {
      if (item[camelKey] !== undefined) {
        const matchedDbKey = possibleDbKeys.find(dbKey => 
          detectedDbColumns.includes(dbKey) ||
          detectedDbColumns.some(col => col.toLowerCase() === dbKey.toLowerCase())
        );

        if (matchedDbKey) {
          const exactDbKey = detectedDbColumns.find(col => col.toLowerCase() === matchedDbKey.toLowerCase()) || matchedDbKey;
          payload[exactDbKey] = item[camelKey];
        } else {
          payload[possibleDbKeys[0]] = item[camelKey];
        }
      }
    }

    return payload;
  };

  const getTimestampColKey = (): string => {
    if (!detectedDbColumns || detectedDbColumns.length === 0) return "timestampid";
    return detectedDbColumns.find(k => 
      ["timestampid", "timestamp_id", "id", "timestampId"].includes(k.toLowerCase())
    ) || "timestampid";
  };

  // 1. Initial User accounts setup
  useEffect(() => {
    const storedUsers = safeStorage.getItem("system_users_db");
    if (storedUsers) {
      try {
        setSystemUsers(JSON.parse(storedUsers));
      } catch (e) {
        setSystemUsers(DEFAULT_USERS);
      }
    } else {
      safeStorage.setItem("system_users_db", JSON.stringify(DEFAULT_USERS));
    }
  }, []);

  // 2. Load cached inventory immediately (Offline First!)
  useEffect(() => {
    setDatabaseStore(getInitialDatabaseStore());
  }, []);

  // 3. User Session persistence check
  // Synchronize theme class to body and documentElement for project-wide light/dark toggle
  useEffect(() => {
    if (headerBg === "white") {
      document.body.classList.add("light-theme");
      document.documentElement.classList.add("light-theme");
    } else {
      document.body.classList.remove("light-theme");
      document.documentElement.classList.remove("light-theme");
    }
  }, [headerBg]);

  useEffect(() => {
    const savedUser = safeStorage.getItem("active_auth_user");
    const savedType = safeStorage.getItem("active_auth_type") as "Standard" | "SuperAdmin" | null;
    const savedFilter = safeStorage.getItem("active_supervisor_filter");

    if (savedUser && savedType) {
      setAuthenticatedUser(savedUser);
      setAuthenticatedUserType(savedType);
      
      if (savedUser.toUpperCase().startsWith("REC") || savedType === "SuperAdmin") {
        if (savedFilter) {
          setCurrentSupervisorFilterTarget(savedFilter);
        } else {
          setCurrentSupervisorFilterTarget(savedUser);
        }
      } else {
        // DEC users are always authoritatively forced to their own division target!
        setCurrentSupervisorFilterTarget(savedUser);
        safeStorage.setItem("active_supervisor_filter", savedUser);
      }
    }
  }, []);

  // 4. Real-time Subscription & Polling Fallback Logic
  useEffect(() => {
    let channel: any;

    if (isLiveSyncActive) {
      // Direct load on mount / activation
      loadInventoryFromSupabase();

      // Establish live changes broadcast from Supabase inventory table
      try {
        channel = supabase
          .channel('realtime-inventory-sync')
          .on(
            'postgres_changes',
            {
              event: '*',
              schema: 'public',
              table: 'inventory'
            },
            (payload) => {
              console.log('Real-time database payload detected:', payload);
              loadInventoryFromSupabase();
            }
          )
          .subscribe((status) => {
            console.log(`Supabase Realtime state: ${status}`);
          });
      } catch (err) {
        console.error("Supabase channel config error:", err);
      }

      // 6-second high-density background pull to guarantee updates across any other systems or browsers
      const pollingTimer = setInterval(() => {
        loadInventoryFromSupabase();
      }, 6000);

      return () => {
        if (channel) {
          supabase.removeChannel(channel);
        }
        clearInterval(pollingTimer);
      };
    } else {
      // Just fallback load once when disabled to make sure everything has correct representation
      loadInventoryFromSupabase();
    }
  }, [isLiveSyncActive]);

  // Supabase Load with Normalization: Database is the Authoritative Single Source of Truth
  const loadInventoryFromSupabase = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('inventory')
        .select('*');

      if (error) {
        console.warn("Supabase API loaded status warning:", error);
        setSyncError(`Load info: ${error.message || JSON.stringify(error)}`);
        
        // Fallback to offline cached data on database load failure
        const fallbackData = getInitialDatabaseStore();
        if (fallbackData && fallbackData.length > 0) {
          setDatabaseStore(fallbackData);
          console.log("Loaded fallback inventory from robust loader (Supabase error).");
        }
      } else if (data) {
        setSyncError(null);
        let cols = detectedDbColumns;
        if (data.length > 0) {
          cols = Object.keys(data[0]);
          setDetectedDbColumns(cols);
        } else if (cols.length === 0) {
          try {
            const url = (supabase as any).supabaseUrl;
            const key = (supabase as any).supabaseKey;
            if (url && key) {
              const res = await fetch(`${url}/rest/v1/?apikey=${key}`);
              if (res.ok) {
                const schema = await res.json();
                if (schema?.definitions?.inventory?.properties) {
                  cols = Object.keys(schema.definitions.inventory.properties);
                  console.log("Dynamically detected columns from OpenAPI:", cols);
                  setDetectedDbColumns(cols);
                }
              }
            }
          } catch (e) {
            console.error("Failed to detect columns via OpenAPI:", e);
          }
        }

        // Normalization Layer for DB Column Case & Type differences
        const remoteItemsNormalized: InventoryItem[] = data.map((row: any) => {
          const rawLoc = normalizeNodeLocation(row.nodeLocation || row.nodelocation || row.node_location || "");
          const finalLoc = rawLoc === "SYSTEM_SETTINGS" ? "SYSTEM_SETTINGS" : (rawLoc || "REC Kohat");
          return {
            timestampId: Number(row.timestampId || row.timestampid || row.timestamp_id || row.id || Date.now()),
            nodeLocation: finalLoc,
            tabContext: normalizeTabContext(row.tabContext || row.tabcontext || row.tab_context || "IT"),
            name: row.name || "",
            serial: row.serial || null,
            model: row.model || null,
            category: row.category || "",
            receivedFrom: row.receivedFrom || row.receivedfrom || row.received_from || null,
            date: row.date || null,
            workingStatus: normalizeWorkingStatus(row.workingStatus || row.workingstatus || row.working_status || "Working"),
            workingSubStatus: normalizeWorkingSubStatus(row.workingSubStatus || row.workingsubstatus || row.working_sub_status),
            issueTo: row.issueTo || row.issueto || row.issue_to || null,
            designation: row.designation || null,
            issuedDate: row.issuedDate || row.issueddate || row.issued_date || null,
            nonWorkingSubStatus: normalizeNonWorkingSubStatus(row.nonWorkingSubStatus || row.nonworkingsubstatus || row.non_working_sub_status),
            remarks: row.remarks || null
          };
        });

        // 1. Filter out deleted items from remote using up-to-date localStorage queue
        let currentDeletedIds: number[] = [];
        try {
          const storedDeleted = safeStorage.getItem("deleted_items_queue");
          currentDeletedIds = storedDeleted ? JSON.parse(storedDeleted) : [];
        } catch (e) {
          currentDeletedIds = deletedIds;
        }

        const activeRemoteItems = remoteItemsNormalized.filter(item => !currentDeletedIds.includes(item.timestampId));

        // 2. Read what is currently stored in local state/localStorage
        let currentLocalItems: InventoryItem[] = [];
        try {
          const cached = safeStorage.getItem("inventory_db");
          currentLocalItems = cached ? JSON.parse(cached) : [];
        } catch (e) {
          currentLocalItems = databaseStore;
        }

        // Read dirty items list (edited offline and pending sync)
        let currentDirtyIds: number[] = [];
        try {
          const storedDirty = safeStorage.getItem("inventory_db_dirty");
          currentDirtyIds = storedDirty ? JSON.parse(storedDirty) : [];
        } catch (_) {}

        // If we successfully reached Supabase, we are online. Proactively attempt background sync of those dirty items!
        if (currentDirtyIds.length > 0) {
          console.log(`[Online Sync] Found ${currentDirtyIds.length} pending offline modifications. Syncing to Supabase...`);
          const timestampColKey = getTimestampColKey();
          for (const id of currentDirtyIds) {
            const localItem = currentLocalItems.find(item => item.timestampId === id);
            if (localItem) {
              const dbItem = mapToDbPayload(localItem);
              const isInsert = !remoteItemsNormalized.some(r => r.timestampId === id);
              try {
                if (isInsert) {
                  await supabase.from('inventory').insert([dbItem]);
                } else {
                  await supabase.from('inventory').update(dbItem).eq(timestampColKey, id);
                }
                removeDirtyId(id);
                console.log(`[Online Sync] Successfully synced pending item ${id} to Supabase.`);
              } catch (e) {
                console.warn(`[Online Sync] Sync attempt failed for item ${id}:`, e);
              }
            } else {
              // Local item no longer exists, clean up dirty queue
              removeDirtyId(id);
            }
          }
          
          // Re-fetch clean list of dirty items after sync attempts
          try {
            const storedDirty = safeStorage.getItem("inventory_db_dirty");
            currentDirtyIds = storedDirty ? JSON.parse(storedDirty) : [];
          } catch (_) {}
        }

        // 3. Merge: Keep all remote items as authority EXCEPT if they are in the dirty list (since the local dirty version is newer!)
        const mergedStore: InventoryItem[] = [];
        
        // Push remote items that are NOT currently dirty and NOT deleted
        activeRemoteItems.forEach(remoteItem => {
          if (!currentDirtyIds.includes(remoteItem.timestampId)) {
            mergedStore.push(remoteItem);
          }
        });

        // Add local items (both dirty ones, and those not yet present in remote)
        currentLocalItems.forEach(localItem => {
          const existsInMerged = mergedStore.some(m => m.timestampId === localItem.timestampId);
          const wasDeleted = currentDeletedIds.includes(localItem.timestampId);
          
          if (!existsInMerged && !wasDeleted && localItem.nodeLocation !== "SYSTEM_SETTINGS") {
            mergedStore.push(localItem);
          }
        });

        // Extract cloud synchronized accounts settings
        const settingsRow = remoteItemsNormalized.find(row => row.nodeLocation === "SYSTEM_SETTINGS");
        if (settingsRow && settingsRow.remarks) {
          if (Date.now() - lastUsersWriteTime.current >= 15000) {
            try {
              const parsedUsers = JSON.parse(settingsRow.remarks);
              setSystemUsers(parsedUsers);
              safeStorage.setItem("system_users_db", JSON.stringify(parsedUsers));
            } catch (e) {
              console.error("Cloud synced settings parse error:", e);
            }
          } else {
            console.log("Skipped loading cloud user settings to avoid race condition with recent local update.");
          }
        }

        // Filter out SYSTEM_SETTINGS from asset list calculations
        const cleanStore = mergedStore.filter(row => row.nodeLocation !== "SYSTEM_SETTINGS");

        // Set the database store
        setDatabaseStore(cleanStore);
        saveInventoryStore(cleanStore);
      }
    } catch (err) {
      console.warn("Loader transaction log:", err);
      
      // Fallback to offline cached data on network error (offline file load)
      const fallbackData = getInitialDatabaseStore();
      if (fallbackData && fallbackData.length > 0) {
        setDatabaseStore(fallbackData);
        console.log("Loaded fallback inventory from robust loader (Network exception).");
      }
    } finally {
      setIsLoading(false);
    }
  };

  const syncSystemUsersToSupabase = async (users: Record<string, UserAccount>) => {
    try {
      const settingsPayload: InventoryItem = {
        timestampId: 1,
        nodeLocation: "SYSTEM_SETTINGS",
        tabContext: "IT",
        name: "ACCOUNTS",
        category: "SYSTEM",
        workingStatus: "Working",
        remarks: JSON.stringify(users)
      };

      const dbPayload = mapToDbPayload(settingsPayload);
      const timestampColKey = getTimestampColKey();

      const { data } = await supabase
        .from('inventory')
        .select(timestampColKey)
        .eq(timestampColKey, 1);

      if (data && data.length > 0) {
        await supabase
          .from('inventory')
          .update(dbPayload)
          .eq(timestampColKey, 1);
      } else {
        await supabase
          .from('inventory')
          .insert([dbPayload]);
      }
    } catch (err) {
      console.error("Failed to push user updates to cloud DB:", err);
    }
  };

  const handleToggleLiveSync = async () => {
    const nextState = !isLiveSyncActive;
    setIsLiveSyncActive(nextState);
    await loadInventoryFromSupabase();
  };

  const handleForceSync = async () => {
    setIsLiveSyncActive(true);
    await loadInventoryFromSupabase();
  };

  const handleLoginSuccess = (username: string, accountType: "Standard" | "SuperAdmin") => {
    setAuthenticatedUser(username);
    setAuthenticatedUserType(accountType);
    
    let defaultFilter = username;
    if (accountType === "SuperAdmin") {
      const firstStandardNode = Object.keys(systemUsers).find(u => systemUsers[u].type === "Standard");
      defaultFilter = firstStandardNode || "REC Kohat";
    }

    setCurrentSupervisorFilterTarget(defaultFilter);
    safeStorage.setItem("active_auth_user", username);
    safeStorage.setItem("active_auth_type", accountType);
    safeStorage.setItem("active_supervisor_filter", defaultFilter);
  };

  const handleLogout = () => {
    setAuthenticatedUser("");
    setAuthenticatedUserType("Standard");
    safeStorage.removeItem("active_auth_user");
    safeStorage.removeItem("active_auth_type");
    safeStorage.removeItem("active_supervisor_filter");
  };

  const handlePasswordChanged = async (updated: Record<string, UserAccount>) => {
    lastUsersWriteTime.current = Date.now();
    setSystemUsers(updated);
    safeStorage.setItem("system_users_db", JSON.stringify(updated));
    await syncSystemUsersToSupabase(updated);
  };

  const handleSupervisorFilterChange = async (val: string) => {
    setCurrentSupervisorFilterTarget(val);
    safeStorage.setItem("active_supervisor_filter", val);
    await loadInventoryFromSupabase();
  };

  const handleTabChange = async (tab: "IT" | "Furniture" | "Misc") => {
    setCurrentActiveTab(tab);
    await loadInventoryFromSupabase();
  };

  const handleDownloadHtml = async () => {
    setIsCompiling(true);
    setIsCookieBlocked(false);
    try {
      let htmlText = "";
      
      // 1. Primary Source: Compile the latest app on-the-fly and fetch the HTML template
      try {
        const res = await fetch(`/api/compile-single-html?t=${Date.now()}`, { cache: "no-store" });
        if (res.ok) {
          const txt = await res.text();
          if (txt && txt.toLowerCase().includes("doctype html") && !txt.includes("blocking a required security cookie") && !txt.includes("Safari") && txt.includes("id=\"root\"")) {
            htmlText = txt;
          } else {
            console.warn("Fetched HTML is an auth proxy or cookie-block page. Using robust local fallback.");
            setIsCookieBlocked(true);
          }
        } else {
          setIsCookieBlocked(true);
        }
      } catch (e) {
        console.error("Server compilation fetch failed, falling back to local clone:", e);
        setIsCookieBlocked(true);
      }

      // 2. Fallback: Use active page DOM if fetch failed
      if (!htmlText) {
        const docClone = document.documentElement.cloneNode(true) as HTMLElement;
        const oldDataEl = docClone.querySelector("#preseed-inventory-data");
        if (oldDataEl) oldDataEl.remove();
        const oldStateEl = docClone.querySelector("#preseed-database-state");
        if (oldStateEl) oldStateEl.remove();
        
        // CLEAR the active React mounting container to ensure a clean, un-hydrated template!
        const rootEl = docClone.querySelector("#root");
        if (rootEl) {
          rootEl.innerHTML = "";
        }
        
        htmlText = "<!DOCTYPE html>\n" + docClone.outerHTML;
      }

      // Inject the latest synchronized dataset and timestamp into the downloaded HTML
      const serializedData = JSON.stringify(databaseStore);
      let modifiedHtml = htmlText;

      // Also inject a head-script for preseeding modern compiled React single-file offline localStorage
      const dataScriptId = "preseed-inventory-data";
      const preseedScript = `
<` + `script type="application/json" id="${dataScriptId}">
${serializedData.replace(/<\/script>/g, '<\\/script>')}
</` + `script>
<` + `script id="preseed-database-state">
  try {
    const preseededTimestamp = ${Date.now()};
    window.preseededTimestamp = preseededTimestamp;
    const cachedTime = localStorage.getItem("inventory_db_timestamp") || 0;
    if (preseededTimestamp > Number(cachedTime)) {
      const dataEl = document.getElementById("${dataScriptId}");
      if (dataEl) {
        const jsonStr = dataEl.textContent || "";
        localStorage.setItem("inventory_db", jsonStr);
        localStorage.setItem("inventory_db_timestamp", preseededTimestamp.toString());
        
        // Also seed offline_db if it uses index_single.html offline variables
        localStorage.setItem("inventory_db_offline", jsonStr);
        localStorage.setItem("inventory_db_offline_timestamp", preseededTimestamp.toString());
      }
    }
  } catch (e) {
    console.error("Offline preseed error:", e);
  }
</` + `script>
`;
      
      if (modifiedHtml.includes("<head>")) {
        modifiedHtml = modifiedHtml.replace("<head>", `<head>${preseedScript}`);
      } else if (modifiedHtml.includes("<HEAD>")) {
        modifiedHtml = modifiedHtml.replace("<HEAD>", `<HEAD>${preseedScript}`);
      } else {
        modifiedHtml = preseedScript + modifiedHtml;
      }

      // Open download wizard modal with the generated HTML
      setDownloadModalData({ isOpen: true, html: modifiedHtml });
      setCopiedHtml(false);

    } catch (err: any) {
      console.error("Dynamic download failed:", err);
      alert("Offline app template could not be loaded. Please try again.");
    } finally {
      setIsCompiling(false);
    }
  };

  // Check if active session allows modification of chosen Location
  const checkWritePrivileges = (): boolean => {
    if (authenticatedUserType === "SuperAdmin") return true;
    // REC divisional accounts have view-only (read-only) rights to subordinate offices
    return authenticatedUser === currentSupervisorFilterTarget;
  };

  // CREATE / UPDATE operation matching database
  const handleItemCommit = async (payload: Omit<InventoryItem, 'timestampId'> & { timestampId?: number }) => {
    const timestampId = payload.timestampId || Date.now();
    const cleanItem: InventoryItem = {
      ...payload,
      timestampId
    };

    const isInsert = !databaseStore.some(r => r.timestampId === timestampId);

    // Track as dirty first so that we retain it locally if sync fails
    trackDirtyId(timestampId);

    // 1. Immediately update Local View & Local Storage (Zero Wait UI!)
    setDatabaseStore(prevStore => {
      const nextStore = [...prevStore];
      const existingIdx = nextStore.findIndex(r => r.timestampId === timestampId);
      if (existingIdx >= 0) {
        nextStore[existingIdx] = cleanItem;
      } else {
        nextStore.push(cleanItem);
      }
      saveInventoryStore(nextStore);
      return nextStore;
    });

    // 2. Perform background Supabase query
    try {
      let syncErr = null;
      const dbItem = mapToDbPayload(cleanItem);
      const timestampColKey = getTimestampColKey();

      if (isInsert) {
        // Critical: Insert WITHOUT .select() to avoid RLS error on anon SELECT policy
        const { error } = await supabase
          .from('inventory')
          .insert([dbItem]);
        
        if (error) {
          console.warn("Supabase Sync insert failed:", error.message);
          syncErr = error.message;
        }
      } else {
        // Update query
        const { error } = await supabase
          .from('inventory')
          .update(dbItem)
          .eq(timestampColKey, timestampId);

        if (error) {
          console.warn("Supabase Sync update failed:", error.message);
          syncErr = error.message;
        }
      }

      if (syncErr) {
        setSyncError(`Save failed: ${syncErr}`);
      } else {
        // Successful remote sync! Remove from dirty list
        removeDirtyId(timestampId);
        setSyncError(null);
      }

      // 3. Trigger refreshing silently from database
      await loadInventoryFromSupabase();
    } catch (err: any) {
      console.error("Sync transaction failed:", err);
      setSyncError(`Sync error: ${err.message || err}`);
    }
  };

  // BULK CREATE / COMMIT operation matching database
  const handleItemsBulkCommit = async (items: InventoryItem[]) => {
    if (items.length === 0) return;

    // Track all items as dirty first
    items.forEach(item => trackDirtyId(item.timestampId));

    // 1. Immediately update Local View & Local Storage (Zero Wait UI!)
    setDatabaseStore(prevStore => {
      const nextStore = [...prevStore];
      items.forEach(cleanItem => {
        const existingIdx = nextStore.findIndex(r => r.timestampId === cleanItem.timestampId);
        if (existingIdx >= 0) {
          nextStore[existingIdx] = cleanItem;
        } else {
          nextStore.push(cleanItem);
        }
      });
      saveInventoryStore(nextStore);
      return nextStore;
    });

    // 2. Perform background Supabase bulk query
    try {
      const dbItems = items.map(item => mapToDbPayload(item));
      const { error } = await supabase
        .from('inventory')
        .insert(dbItems);

      if (error) {
        console.warn("Supabase Sync bulk insert failed:", error.message);
        setSyncError(`Bulk save failed: ${error.message}`);
      } else {
        // Successful remote sync! Remove from dirty list
        items.forEach(item => removeDirtyId(item.timestampId));
        setSyncError(null);
      }

      // 3. Trigger refreshing silently from database
      await loadInventoryFromSupabase();
    } catch (err: any) {
      console.error("Sync bulk transaction failed:", err);
      setSyncError(`Sync error: ${err.message || err}`);
    }
  };

  // DELETE operation
  const handleItemDelete = async (timestampId: number) => {
    // 1. Instantly delete locally & track deleted id
    trackDeletedId(timestampId);
    setDatabaseStore(prevStore => {
      const nextStore = prevStore.filter(item => item.timestampId !== timestampId);
      saveInventoryStore(nextStore);
      return nextStore;
    });

    // 2. Delete from Supabase in background
    try {
      const timestampColKey = getTimestampColKey();
      const { error } = await supabase
        .from('inventory')
        .delete()
        .eq(timestampColKey, timestampId);

      if (error) {
        console.warn("Supabase background delete failed:", error.message);
        setSyncError(`Delete failed: ${error.message}`);
      } else {
        setSyncError(null);
      }

      await loadInventoryFromSupabase();
    } catch (err: any) {
      console.error("Delete transaction error:", err);
      setSyncError(`Delete sync error: ${err.message || err}`);
    }
  };

  // DELETE ALL (Clear all items inside current supervisor node & tab)
  const handleItemDeleteAll = async () => {
    const activeSectionItems = databaseStore.filter(
      item => item.nodeLocation === currentSupervisorFilterTarget && item.tabContext === currentActiveTab
    );

    if (activeSectionItems.length === 0) return;

    // 1. Update instantly locally and track deleted IDs
    activeSectionItems.forEach(item => trackDeletedId(item.timestampId));
    const itemsToKeep = databaseStore.filter(
      item => !(item.nodeLocation === currentSupervisorFilterTarget && item.tabContext === currentActiveTab)
    );
    setDatabaseStore(itemsToKeep);
    saveInventoryStore(itemsToKeep);

    // 2. Delete on Supabase using highly-optimized bulk delete
    try {
      const timestampColKey = getTimestampColKey();
      const idsToDelete = activeSectionItems.map(item => item.timestampId);
      const { error } = await supabase
        .from('inventory')
        .delete()
        .in(timestampColKey, idsToDelete);

      if (error) {
        console.warn("Supabase Clear All failed:", error.message);
        setSyncError(`Clear All failed: ${error.message}`);
      } else {
        setSyncError(null);
      }
      await loadInventoryFromSupabase();
    } catch (err: any) {
      console.error("Mass delete transaction failure:", err);
      setSyncError(`Clear All error: ${err.message || err}`);
    }
  };

  // Filter current active scope data
  const activeScopeData = databaseStore.filter(
    item => 
      (item.nodeLocation || "").trim().toLowerCase() === (currentSupervisorFilterTarget || "").trim().toLowerCase() && 
      (item.tabContext || "").trim().toLowerCase() === (currentActiveTab || "").trim().toLowerCase()
  );

  // All items for this office location across all categories
  const allLocationData = databaseStore.filter(
    item => 
      (item.nodeLocation || "").trim().toLowerCase() === (currentSupervisorFilterTarget || "").trim().toLowerCase() &&
      (item.nodeLocation || "").trim().toUpperCase() !== "SYSTEM_SETTINGS"
  );

  if (!authenticatedUser) {
    return (
      <LoginScreen
        systemUsers={systemUsers}
        onLoginSuccess={handleLoginSuccess}
        onPasswordChanged={handlePasswordChanged}
      />
    );
  }

  // Active user writes privileges
  const isWriteAllowed = checkWritePrivileges();

  return (
    <div id="appWrapper" className="min-h-screen bg-[#0f1a2e]/75 backdrop-blur-xl text-slate-100 flex flex-col font-sans bg-grid-pattern relative overflow-hidden">
      
      {/* Exquisite ambient glows */}
      <div className="ambient-glow-top print:hidden"></div>
      <div className="ambient-glow-bottom print:hidden"></div>
      
      {/* Professional Moving Marquee Banner */}
      <div className="bg-gradient-to-r from-blue-950 via-slate-900 to-indigo-950 border-b border-blue-500/20 py-2 px-6 shadow-lg text-xs font-black uppercase tracking-wider text-cyan-400 select-none print:hidden flex items-center justify-between">
        <marquee behavior="scroll" direction="left" scrollamount="6" className="w-full text-slate-100 tracking-widest font-extrabold">
          Election Commission of Pakistan
        </marquee>
      </div>

      {/* App Header Bar */}
      <header className={`backdrop-blur-xl border-b shadow-lg print:hidden transition-colors duration-300 ${
        headerBg === "white" 
          ? "bg-white border-slate-200 text-slate-800" 
          : "bg-slate-900/35 border-slate-800/60 text-slate-100"
      }`}>
        <div className="max-w-7xl mx-auto px-4 py-4 grid grid-cols-1 md:grid-cols-3 items-center gap-4">
          
          {/* LEFT SECTION: Logo and ECP Title */}
          <div className="flex items-center gap-3 justify-center md:justify-start">
            <div className="relative w-10 h-10 flex items-center justify-center shrink-0">
              <img 
                src="ecp logo.jpg" 
                alt="ECP Logo" 
                onError={(e) => {
                  const target = e.currentTarget;
                  if (target.src.includes("ecp%20logo.jpg") || target.src.endsWith("ecp logo.jpg")) {
                    target.src = "ecp_logo.jpg";
                  } else {
                    target.style.display = "none";
                    const fallback = target.nextSibling as HTMLElement;
                    if (fallback) fallback.style.display = "flex";
                  }
                }}
                className="w-10 h-10 object-cover rounded-full border border-slate-700/60 shadow-md"
              />
              <div className="hidden w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center font-extrabold text-white shadow-lg shadow-blue-500/10">
                ECP
              </div>
            </div>
            <div>
              <h1 className={`text-sm font-black uppercase tracking-wider text-center md:text-left transition-colors duration-200 ${
                headerBg === "white" ? "text-slate-900" : "text-white"
              }`}>
                Election Commission of Pakistan
              </h1>
            </div>
          </div>

          {/* CENTER SECTION: Standalone Navigation Menus (Centered Ledger & Reports Button Swapper) */}
          <div className={`flex items-center justify-center gap-4 px-3 py-1.5 rounded-2xl shadow-inner w-fit mx-auto border transition-colors duration-300 ${
            headerBg === "white" 
              ? "bg-slate-100 border-slate-200/80" 
              : "bg-slate-950/25 border-slate-800/55"
          }`}>
            {/* Standalone Ledger Menu */}
            <button
              id="headerLedgerButton"
              onClick={() => {
                setCurrentView("Ledger");
                setReportsDropdownOpen(false);
              }}
              className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all duration-200 cursor-pointer flex items-center gap-2 border select-none ${
                currentView === "Ledger"
                  ? "bg-cyan-600 border-cyan-500 text-white shadow-lg shadow-cyan-500/20 hover:bg-cyan-500"
                  : headerBg === "white"
                    ? "bg-white border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-200/50 hover:border-slate-300"
                    : "bg-slate-900/60 border-slate-800/80 text-slate-400 hover:text-white hover:bg-slate-800/60 hover:border-slate-700"
              }`}
            >
              <Package className="w-3.5 h-3.5" />
              <span>Ledger</span>
            </button>

            <div className={`h-4 w-px transition-colors duration-300 ${headerBg === "white" ? "bg-slate-200" : "bg-slate-800"}`}></div>

            {/* Standalone Reports Dropdown */}
            <div className="relative" id="headerReportsDropdownContainer">
              <button
                onClick={() => setReportsDropdownOpen(!reportsDropdownOpen)}
                className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all duration-200 cursor-pointer flex items-center gap-2 border select-none ${
                  currentView === "Reports"
                    ? "bg-emerald-600 border-emerald-500 text-white shadow-lg shadow-emerald-500/20 hover:bg-emerald-500"
                    : headerBg === "white"
                      ? "bg-white border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-200/50 hover:border-slate-300"
                      : "bg-slate-900/60 border-slate-800/80 text-slate-400 hover:text-white hover:bg-slate-800/60 hover:border-slate-700"
                }`}
              >
                <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
                <span>Reports</span>
                <span className="text-[10px] opacity-75">▼</span>
              </button>

              {reportsDropdownOpen && (
                <>
                  <div 
                    className="fixed inset-0 z-40" 
                    onClick={() => setReportsDropdownOpen(false)}
                  />
                  {/* Perfectly aligned dropdown below the Reports button */}
                  <div className={`absolute left-1/2 -translate-x-1/2 md:translate-x-0 md:left-auto md:right-0 top-full mt-3 w-72 border rounded-2xl shadow-2xl z-50 overflow-hidden p-2.5 animate-fadeIn transition-all duration-200 ${
                    headerBg === "white"
                      ? "bg-white border-slate-200 text-slate-800"
                      : "bg-slate-900 border-slate-800 text-slate-200"
                  }`}>
                    <button
                      onClick={() => {
                        setCurrentView("Reports");
                        setReportsDropdownOpen(false);
                      }}
                      className={`w-full text-left text-xs font-black px-4 py-3 rounded-xl flex items-center justify-between transition-all ${
                        currentView === "Reports"
                          ? "bg-emerald-600/20 text-emerald-200 border border-emerald-500/30"
                          : headerBg === "white"
                            ? "text-slate-700 hover:text-slate-950 hover:bg-slate-100/80 border border-transparent"
                            : "text-slate-300 hover:text-white hover:bg-slate-800/50 border border-transparent"
                      }`}
                    >
                      <span className="flex items-center gap-2.5">
                        <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
                        <span>ECP Simple Report Center</span>
                      </span>
                      <span className="text-[9px] bg-slate-950 px-2 py-0.5 rounded font-mono text-slate-400">
                        v2.1
                      </span>
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>

          {/* RIGHT SECTION: Profile badge and Actions */}
          <div className="flex flex-col sm:flex-row items-center gap-3 justify-center md:justify-end w-full md:w-auto">
            {/* White / Black Background Switcher */}
            <button
              onClick={() => {
                const nextBg = headerBg === "black" ? "white" : "black";
                setHeaderBg(nextBg);
                safeStorage.setItem("header_bg_theme", nextBg);
              }}
              className={`p-2.5 rounded-xl border transition-all duration-200 cursor-pointer flex items-center justify-center select-none ${
                headerBg === "white"
                  ? "bg-slate-100 border-slate-200 text-slate-800 hover:bg-slate-200/70"
                  : "bg-slate-900/60 border-slate-800/80 text-slate-300 hover:bg-slate-800 hover:text-white"
              }`}
              title={`Switch to ${headerBg === "black" ? "Light Mode" : "Dark Mode"}`}
            >
              {headerBg === "white" ? (
                <Moon className="w-4 h-4 text-indigo-600 animate-fadeIn" />
              ) : (
                <Sun className="w-4 h-4 text-amber-400 animate-fadeIn" />
              )}
            </button>

            {/* User Profile Badge */}
            <div className={`flex items-center gap-2 p-2 px-3 rounded-xl shadow-sm text-xs font-mono shrink-0 border transition-colors duration-300 ${
              headerBg === "white" 
                ? "bg-slate-50 border-slate-200 text-slate-700" 
                : "bg-slate-950/35 border-slate-800/50 text-slate-300"
            }`}>
              <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse shadow-md shadow-emerald-500/20"></span>
              <span className={headerBg === "white" ? "text-slate-900 font-bold" : "text-slate-300 font-bold"}>{authenticatedUser}</span>
              <span className={headerBg === "white" ? "text-slate-300 font-bold" : "text-slate-500 font-bold"}>|</span>
              <span className={headerBg === "white" ? "text-blue-600 font-black capitalize" : "text-blue-400 font-black capitalize"}>{authenticatedUserType}</span>
            </div>

            {authenticatedUserType === "SuperAdmin" && (
              <button
                onClick={handleDownloadHtml}
                className={`py-1.5 px-3 rounded-lg text-xs font-bold flex items-center gap-1 transition cursor-pointer border ${
                  headerBg === "white"
                    ? "bg-purple-50 border-purple-200 text-purple-700 hover:bg-purple-600 hover:text-white"
                    : "bg-purple-600/10 hover:bg-purple-600 text-purple-400 hover:text-white border border-purple-500/15"
                }`}
                title="Download Standalone Offline HTML or Project ZIP"
              >
                <Download className={`w-3.5 h-3.5 ${isCompiling ? "animate-spin" : ""}`} />
                {isCompiling ? "Compiling..." : "Export Offline App"}
              </button>
            )}

            <button
              onClick={handleLogout}
              className={`py-1.5 px-3 rounded-lg text-xs font-bold flex items-center gap-1 transition cursor-pointer border ${
                headerBg === "white"
                  ? "bg-rose-50 border-rose-200 text-rose-700 hover:bg-rose-600 hover:text-white"
                  : "bg-rose-600/10 hover:bg-rose-600 text-rose-400 hover:text-white border border-rose-500/15"
              }`}
            >
              <LogOut className="w-3.5 h-3.5" /> Logout
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 py-6 space-y-6">

        {syncError && (() => {
          const isNetworkOffline = syncError.toLowerCase().includes("fetch") || 
                                   syncError.toLowerCase().includes("network") || 
                                   syncError.toLowerCase().includes("failed to load") ||
                                   syncError.toLowerCase().includes("failed");
          if (isNetworkOffline) {
            return (
              <div className="bg-sky-950/40 border border-sky-500/30 rounded-2xl p-4 flex flex-col md:flex-row items-center justify-between gap-4 shadow-lg shadow-sky-950/20 backdrop-blur-sm print:hidden">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-sky-500/10 rounded-full flex items-center justify-center text-sky-400 shrink-0 border border-sky-500/20">
                    <span className="text-xl font-bold font-mono">i</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-black text-sky-200">
                      Offline Mode Active — Running Local Database Backup
                    </p>
                    <p className="text-xs text-sky-400 mt-0.5 max-w-4xl leading-relaxed">
                      Detail: <code className="font-mono text-sky-300 font-bold bg-sky-950/60 px-1 py-0.5 rounded">Network Disconnected / Offline</code>. 
                      You are loaded locally under offline mode. All assets can still be viewed, edited, created, and deleted! Changes are stored securely in your browser's Local Storage and will sync to Supabase automatically when your internet connection is restored.
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    loadInventoryFromSupabase();
                  }}
                  className="bg-sky-500 hover:bg-sky-600 text-slate-950 font-black text-xs px-4 py-2.5 rounded-xl transition shadow-md whitespace-nowrap cursor-pointer hover:scale-[1.02]"
                >
                  Force Retry Sync
                </button>
              </div>
            );
          }

          return (
            <div className="bg-amber-950/40 border border-amber-500/30 rounded-2xl p-4 flex flex-col md:flex-row items-center justify-between gap-4 shadow-lg shadow-amber-950/20 backdrop-blur-sm print:hidden">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-amber-500/10 rounded-full flex items-center justify-center text-amber-400 shrink-0 border border-amber-500/20">
                  <span className="text-xl font-bold font-mono">!</span>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-black text-amber-200">
                    Database Synchronization is Restricted by Row-Level Security
                  </p>
                  <p className="text-xs text-amber-400 mt-0.5 max-w-4xl leading-relaxed">
                    Detail: <code className="font-mono text-amber-300 font-bold bg-amber-950/60 px-1 py-0.5 rounded">{syncError}</code>. 
                    All records are currently safely stored on your local computer, but won't be saved on Supabase or synced to other systems until the RLS rules are updated.
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowSolutionsModal(true)}
                className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs px-4 py-2.5 rounded-xl transition shadow-md whitespace-nowrap cursor-pointer hover:scale-[1.02]"
              >
                How to Fix in 10 Seconds
              </button>
            </div>
          );
        })()}
        
        {/* Render Super Admin console control panels */}
        {authenticatedUserType === "SuperAdmin" && (
          <AdminConsole
            systemUsers={systemUsers}
            activeUser={authenticatedUser}
            onUsersUpdate={handlePasswordChanged}
          />
        )}

        {currentView === "Ledger" ? (
          <>
            {/* Supervision & Filters Workspace Bar with Tabs covering the Left Side */}
            <div className="flex flex-col md:flex-row justify-between items-center gap-4 bg-slate-900/30 backdrop-blur-xl p-3.5 rounded-2xl border border-slate-800/60 print:hidden w-full animate-fadeIn shadow-xl">
              
              {/* Left Block: Larger tabs shifted and expanded to cover the left side area */}
              <div className="w-full md:flex-1 flex justify-start items-center">
                <div className="flex items-center bg-slate-950/45 backdrop-blur-sm p-2 rounded-xl border border-slate-800/60 gap-3 w-full md:w-auto overflow-x-auto shadow-inner justify-start">
                  <button
                    onClick={() => handleTabChange("IT")}
                    className={`flex items-center justify-center gap-2.5 px-10 py-4 rounded-xl text-base md:text-lg font-black tracking-wider transition-all duration-200 cursor-pointer whitespace-nowrap flex-1 md:flex-none ${
                      currentActiveTab === "IT"
                        ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-500/15 scale-[1.02]'
                        : 'text-slate-400 hover:text-white hover:bg-slate-900/50'
                    }`}
                  >
                    <Laptop className="w-5.5 h-5.5" /> IT Equipment
                  </button>
                  <button
                    onClick={() => handleTabChange("Furniture")}
                    className={`flex items-center justify-center gap-2.5 px-10 py-4 rounded-xl text-base md:text-lg font-black tracking-wider transition-all duration-200 cursor-pointer whitespace-nowrap flex-1 md:flex-none ${
                      currentActiveTab === "Furniture"
                        ? 'bg-orange-600 text-white shadow-lg shadow-orange-500/15 scale-[1.02]'
                        : 'text-slate-400 hover:text-white hover:bg-slate-900/50'
                    }`}
                  >
                    <Sofa className="w-5.5 h-5.5" /> Furniture Assets
                  </button>
                  <button
                    onClick={() => handleTabChange("Misc")}
                    className={`flex items-center justify-center gap-2.5 px-10 py-4 rounded-xl text-base md:text-lg font-black tracking-wider transition-all duration-200 cursor-pointer whitespace-nowrap flex-1 md:flex-none ${
                      currentActiveTab === "Misc"
                        ? 'bg-purple-600 text-white shadow-lg shadow-purple-500/15 scale-[1.02]'
                        : 'text-slate-400 hover:text-white hover:bg-slate-900/50'
                    }`}
                  >
                    <Package className="w-5.5 h-5.5" /> Miscellaneous
                  </button>
                </div>
              </div>

              {/* Right Block: Divisional Status Selector (Larger, Auto Width on the right side) */}
              <div className="w-full md:w-auto shrink-0 flex justify-end items-center">
                {authenticatedUser.toUpperCase().startsWith("REC") || authenticatedUserType === "SuperAdmin" ? (
                  <div className="flex items-center gap-2 bg-slate-950/35 backdrop-blur-sm border border-slate-800/60 text-slate-100 py-2.5 px-4 rounded-xl shadow-sm w-full md:w-auto">
                    <label className="text-[11px] font-black text-slate-400 uppercase tracking-widest shrink-0 select-none">
                      🔍 Divisional Status:
                    </label>
                    <select
                      value={currentSupervisorFilterTarget}
                      onChange={(e) => handleSupervisorFilterChange(e.target.value)}
                      className="bg-transparent text-xs text-zinc-100 font-black focus:outline-none focus:ring-0 max-w-xs cursor-pointer border-none py-0 pl-1 pr-5"
                    >
                      {Object.keys(systemUsers)
                        .filter(u => systemUsers[u].type === "Standard")
                        .map(node => (
                          <option key={node} value={node} className="text-slate-900 font-bold select-none">
                            {node}
                          </option>
                        ))}
                    </select>
                  </div>
                ) : (
                  <div className="inline-flex py-2.5 px-4 rounded-xl bg-slate-950/50 text-[11px] font-extrabold text-slate-400 border border-slate-800 shadow-sm">
                    📍 active location: &nbsp;<span className="text-blue-400 font-black">{currentSupervisorFilterTarget}</span>
                  </div>
                )}
              </div>
            </div>

            {/* PRINT-ONLY OFFICIAL HEADER BLOCK */}
            <div className="hidden print:block text-slate-900 mb-6 border-b-2 border-slate-800 pb-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <img 
                    src="ecp_logo.jpg" 
                    alt="ECP Logo" 
                    className="w-16 h-16 object-contain rounded-full border border-slate-300 shadow-sm" 
                  />
                  <div>
                    <h1 className="text-xl font-black uppercase tracking-wide text-slate-950">
                      Election Commission of Pakistan
                    </h1>
                    <p className="text-xs font-bold text-emerald-700 tracking-widest uppercase">
                      Inventory Tracking System Report
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-[10px] font-black uppercase tracking-wide text-slate-500 block">
                    Active Location
                  </span>
                  <span className="text-sm font-black text-blue-700 block mt-0.5">
                    {currentSupervisorFilterTarget}
                  </span>
                </div>
              </div>
              <div className="flex justify-between items-center mt-4 pt-2 border-t border-slate-200 text-xs text-slate-600">
                <div>
                  Report Category: <strong className="text-slate-900">{currentActiveTab === "IT" ? "IT Equipment" : currentActiveTab === "Furniture" ? "Furniture Assets" : "Miscellaneous"}</strong>
                </div>
                <div>
                  Date Generated: <strong className="text-slate-900">{new Date().toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' })}</strong>
                </div>
              </div>
            </div>

            {/* Ledger actions spreadsheet and CRUD controls */}
             <RegistryLedger
              key={currentSupervisorFilterTarget}
              currentTab={currentActiveTab}
              scopeData={activeScopeData}
              allLocationData={databaseStore}
              currentNodeLocation={currentSupervisorFilterTarget}
              isWriteAllowed={isWriteAllowed}
              isSuperAdmin={authenticatedUserType === "SuperAdmin"}
              onItemCommit={handleItemCommit}
              onItemsBulkCommit={handleItemsBulkCommit}
              onItemDelete={handleItemDelete}
              onItemDeleteAll={handleItemDeleteAll}
              onTabChange={handleTabChange}
            />
          </>
        ) : (
          <div className="animate-fadeIn">
            <ReportMenu
              currentTab={currentActiveTab}
              currentNodeLocation={currentSupervisorFilterTarget}
              databaseStore={databaseStore}
              initialReportType={selectedReportType}
              onReportTypeChange={setSelectedReportType}
              initialWorkingSubFilter={reportWorkingSubFilter}
              initialNonWorkingSubFilter={reportNonWorkingSubFilter}
            />
          </div>
        )}

      </main>

      <footer className="bg-slate-950 py-4 border-t border-slate-900 text-center text-[10px] text-slate-600 mt-12 print:hidden font-mono">
        &copy; 2026 ECP Inventory Tracking System. All rights reserved.
      </footer>

      {showSolutionsModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 print:hidden">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-2xl shadow-xl shadow-slate-950/50 flex flex-col overflow-hidden max-h-[90vh]">
            <div className="p-6 border-b border-slate-800 flex justify-between items-center bg-slate-900/50">
              <h3 className="text-md font-black text-white flex items-center gap-2">
                <Shield className="w-5 h-5 text-amber-400" /> Supabase Database RLS Repair Panel
              </h3>
              <button 
                onClick={() => setShowSolutionsModal(false)}
                className="text-slate-400 hover:text-white font-bold text-sm cursor-pointer"
              >
                ✕ Close
              </button>
            </div>
            
            <div className="p-6 space-y-4 overflow-y-auto text-xs leading-relaxed">
              <p className="text-slate-300">
                The error <code className="bg-slate-950 px-1 py-0.5 rounded text-rose-400 font-mono">violates row-level security policy</code> occurs when Supabase Row-Level Security (RLS) is enabled but does not authorize anonymous clients to read or write database items.
              </p>

              <div className="bg-amber-500/5 border border-amber-500/20 rounded-xl p-3.5 space-y-2">
                <h4 className="font-extrabold text-amber-200">How to Fix This in Your Supabase Console:</h4>
                <ol className="list-decimal list-inside space-y-1.5 text-slate-300">
                  <li>Go to your <a href="https://supabase.com/dashboard" target="_blank" rel="noopener noreferrer" className="text-cyan-400 underline hover:text-cyan-300 font-bold inline-flex items-center gap-0.5">Supabase Dashboard ↗</a>.</li>
                  <li>Click on your project, then open the <strong>SQL Editor</strong> tab on the left sidebar.</li>
                  <li>Click <strong>New Query</strong>, paste the SQL commands below, and click <strong>Run</strong>:</li>
                </ol>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between items-center text-[10px] text-slate-400 font-mono">
                  <span>sql schema patches</span>
                  <button
                    onClick={() => {
                      const sqlCode = `-- Enable permissions for anonymous connections on the inventory table\nALTER TABLE inventory DISABLE ROW LEVEL SECURITY;\n\n-- Direct alternative (if you want RLS enabled, run this instead):\n-- CREATE POLICY "Allow anon select" ON inventory FOR SELECT TO anon USING (true);\n-- CREATE POLICY "Allow anon insert" ON inventory FOR INSERT TO anon WITH CHECK (true);\n-- CREATE POLICY "Allow anon update" ON inventory FOR UPDATE TO anon USING (true) WITH CHECK (true);\n-- CREATE POLICY "Allow anon delete" ON inventory FOR DELETE TO anon USING (true);`;
                      navigator.clipboard.writeText(sqlCode);
                      alert("SQL command copied to clipboard!");
                    }}
                    className="bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold px-2 py-1 rounded transition cursor-pointer"
                  >
                    Copy SQL
                  </button>
                </div>
                <pre className="bg-slate-950 p-4 rounded-xl font-mono text-[11px] text-emerald-400 overflow-x-auto border border-slate-850">
{`-- SQL to remove database permission restrictions on inventory table
ALTER TABLE inventory DISABLE ROW LEVEL SECURITY;

-- Alternative: Keep RLS enabled but allow public anonymous reads and writes
CREATE POLICY "Allow anon select" ON inventory FOR SELECT TO anon USING (true);
CREATE POLICY "Allow anon insert" ON inventory FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "Allow anon update" ON inventory FOR UPDATE TO anon USING (true) WITH CHECK (true);
CREATE POLICY "Allow anon delete" ON inventory FOR DELETE TO anon USING (true);`}
                </pre>
              </div>
              
              <div className="text-slate-400 text-[11px]">
                💡 Running either of these SQL statements on your Supabase project instantly enables seamless offline-first synchronization, making records saved from any device immediately appear in your remote table and on the live dashboards!
              </div>
            </div>

            <div className="p-4 bg-slate-950/40 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => setShowSolutionsModal(false)}
                className="bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs px-4 py-2 rounded-xl transition cursor-pointer"
              >
                Close Panel
              </button>
            </div>
          </div>
        </div>
      )}

      {downloadModalData.isOpen && (
        <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md z-50 flex items-center justify-center p-4 print:hidden">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg shadow-2xl shadow-slate-950/70 flex flex-col overflow-hidden max-h-[90vh]">
            <div className="p-6 border-b border-slate-800 flex justify-between items-center bg-slate-900/50">
              <h3 className="text-md font-bold text-white flex items-center gap-2">
                <Download className="w-5 h-5 text-amber-500 animate-bounce" /> Offline App & Backup Exporter
              </h3>
              <button 
                onClick={() => setDownloadModalData({ isOpen: false, html: "" })}
                className="text-slate-400 hover:text-white font-bold text-sm cursor-pointer"
              >
                ✕ Close
              </button>
            </div>
            
            <div className="p-6 space-y-5 overflow-y-auto text-xs leading-relaxed text-slate-300">
              <div className="p-3 bg-slate-950/50 rounded-xl border border-slate-800/80 space-y-2">
                <p className="font-semibold text-white">📦 What is this?</p>
                <p className="text-slate-400">
                  This exports a fully dynamic, self-contained single-file HTML version of the ECP Asset Inventory application pre-seeded with all <strong>{databaseStore.length}</strong> currently loaded inventory items.
                </p>
              </div>

              {/* Cookie block specific warning */}
              {isCookieBlocked && (
                <div className="p-3.5 bg-rose-500/10 border border-rose-500/20 rounded-xl space-y-2 text-rose-200">
                  <p className="font-extrabold flex items-center gap-1.5 text-xs text-rose-400">
                    ⚠️ Browser Security Cookie Block Detected!
                  </p>
                  <p className="text-[11px] leading-relaxed text-slate-300">
                    Your web browser is blocking the security session cookies required by the preview server proxy (very common in <strong>Safari, iOS devices, or Private/Incognito tabs</strong>). This causes standard server downloads to fail or download raw login error screens.
                  </p>
                  <p className="text-[11px] font-bold text-amber-200 bg-slate-950/60 p-2.5 rounded border border-rose-500/10">
                    💡 <strong>How to download instantly:</strong> Click the <strong>"Open in new tab"</strong> button at the top-right of your preview screen (or reload this page in a direct browser tab). Once open in its own tab, download options will build and save 100% perfectly with no blocks!
                  </p>
                </div>
              )}

              <div className="p-3.5 bg-amber-500/10 rounded-xl border border-amber-500/20 space-y-1.5">
                <p className="font-bold text-amber-200 flex items-center gap-1.5">⚠️ Crucial Browser Preview Notice:</p>
                <p className="text-slate-300 text-[11px] leading-relaxed">
                  Because this application is running inside a <strong>sandboxed preview iframe</strong>, web browsers often block direct file downloads (Option 1) silently or serve stale cache files.
                </p>
                <p className="text-slate-300 text-[11px] font-medium leading-relaxed bg-slate-950/50 p-2 rounded border border-slate-800/80 mt-1">
                  💡 <strong>To guarantee a perfect download:</strong> Open the live preview in a <strong>New Tab</strong> using the arrow icon at the top right of the preview pane, then download the HTML file there! Alternatively, use <strong>Option 2 (Copy Code)</strong> to save it instantly.
                </p>
              </div>

              <div className="space-y-3">
                <h4 className="font-extrabold text-slate-200">Choose an Export Method:</h4>
                
                {/* Method 1: Try Direct Download */}
                <div className="border border-slate-800 bg-slate-950/30 rounded-xl p-4 space-y-3">
                  <div className="flex items-start gap-2">
                    <span className="bg-amber-500/10 text-amber-400 px-2 py-0.5 rounded text-[10px] font-bold font-mono">Option 1</span>
                    <div>
                      <p className="font-bold text-white">Download Standalone index.html File (Recommended for GitHub Pages)</p>
                      <p className="text-slate-400 text-[11px]">Downloads a single, compiled <code className="text-amber-400">index.html</code> file with the absolute latest code representing your current preview. Upload this file directly to your GitHub repository to host it with GitHub Pages instantly!</p>
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      try {
                        const blob = new Blob([downloadModalData.html], { type: 'text/html' });
                        const url = URL.createObjectURL(blob);
                        const link = document.createElement('a');
                        link.href = url;
                        link.download = 'index.html';
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                        URL.revokeObjectURL(url);
                      } catch (e) {
                        alert("File download block encountered. Please use Option 2 below!");
                      }
                    }}
                    className="w-full bg-amber-600 hover:bg-amber-500 text-slate-950 font-black py-2.5 px-4 rounded-xl transition cursor-pointer text-center text-xs flex items-center justify-center gap-1.5"
                  >
                    <Download className="w-4 h-4" /> Save as index.html (GitHub-Ready)
                  </button>
                </div>

                {/* Method 2: Copy to Clipboard Fallback */}
                <div className="border border-slate-800 bg-slate-950/30 rounded-xl p-4 space-y-3">
                  <div className="flex items-start gap-2">
                    <span className="bg-blue-500/10 text-blue-400 px-2 py-0.5 rounded text-[10px] font-bold font-mono">Option 2</span>
                    <div>
                      <p className="font-bold text-white">Copy Code to Clipboard</p>
                      <p className="text-slate-400 text-[11px]">Copy the fully compiled standalone source code and paste it manually into a local file named <code className="text-amber-400">index.html</code>.</p>
                    </div>
                  </div>
                  <button
                    onClick={async () => {
                      try {
                        await navigator.clipboard.writeText(downloadModalData.html);
                        setCopiedHtml(true);
                        setTimeout(() => setCopiedHtml(false), 3000);
                      } catch (e) {
                        alert("Failed to copy automatically. Please try manual copy.");
                      }
                    }}
                    className={`w-full py-2.5 px-4 rounded-xl font-bold transition cursor-pointer text-center text-xs flex items-center justify-center gap-1.5 ${
                      copiedHtml 
                        ? "bg-emerald-600 text-white" 
                        : "bg-slate-800 hover:bg-slate-700 text-white border border-slate-700"
                    }`}
                  >
                    {copiedHtml ? (
                      <>✨ Copied Successfully!</>
                    ) : (
                      <>Copy Entire HTML Source Code</>
                    )}
                  </button>
                  {copiedHtml && (
                    <div className="p-3 bg-emerald-500/5 border border-emerald-500/20 rounded-lg text-emerald-400 text-[11px] animate-fade-in">
                      💡 <strong>Next steps:</strong> Open any text editor (like Notepad or VS Code), paste the code (<kbd>Ctrl+V</kbd> or <kbd>Cmd+V</kbd>), and save the file with the name <strong>index.html</strong>. You can then double click it to run it completely offline or host it anywhere!
                    </div>
                  )}
                </div>

                {/* Method 3: Download Complete Project ZIP */}
                <div className="border border-slate-800 bg-slate-950/30 rounded-xl p-4 space-y-3">
                  <div className="flex items-start gap-2">
                    <span className="bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded text-[10px] font-bold font-mono">Option 3</span>
                    <div>
                      <p className="font-bold text-white">Download Complete Project ZIP (.zip)</p>
                      <p className="text-slate-400 text-[11px]">Downloads a complete, standard zip package containing the full source code (React, Tailwind, Vite configurations, etc.) of this project representing the latest active preview. The root <code className="text-amber-400">index.html</code> inside this ZIP is pre-compiled for seamless offline use and GitHub Pages!</p>
                    </div>
                  </div>
                  <button
                    onClick={async () => {
                      try {
                        const response = await fetch('/api/download-project-zip');
                        if (!response.ok) {
                          throw new Error('Failed to download project zip');
                        }
                        const contentType = response.headers.get("content-type") || "";
                        if (contentType.includes("text/html")) {
                          const text = await response.clone().text();
                          if (text.includes("blocking a required security cookie") || text.includes("Safari") || text.includes("DOCTYPE")) {
                            throw new Error("auth_cookie_blocked");
                          }
                        }
                        const blob = await response.blob();
                        const url = URL.createObjectURL(blob);
                        const link = document.createElement('a');
                        link.href = url;
                        link.download = 'ECP_Asset_Inventory_Project.zip';
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                        URL.revokeObjectURL(url);
                      } catch (e: any) {
                        console.error(e);
                        setIsCookieBlocked(true);
                        if (e.message === "auth_cookie_blocked") {
                          alert("⚠️ Security Cookie Blocked by Browser:\n\nBecause this preview is running in an iframe, your browser is blocking required authentication cookies (very common in Safari, iOS, or private browsing tabs).\n\nPlease click the 'Open in new tab' button at the top-right of your screen to open the app, then click download. It will work 100% perfectly there!");
                        } else {
                          alert("Failed to download project ZIP. Please try downloading from a New Tab.");
                        }
                      }
                    }}
                    className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-black py-2.5 px-4 rounded-xl transition cursor-pointer text-center text-xs flex items-center justify-center gap-1.5"
                  >
                    <Download className="w-4 h-4" /> Download Complete Project ZIP
                  </button>
                </div>
              </div>
            </div>

            <div className="p-4 bg-slate-950/40 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => setDownloadModalData({ isOpen: false, html: "" })}
                className="bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs px-4 py-2 rounded-xl transition cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

