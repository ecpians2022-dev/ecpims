import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';

export const saveElementAsPDF = async (
  elementId: string,
  filename: string = 'Election_Commission_of_Pakistan_Report.pdf'
): Promise<boolean> => {
  try {
    const element = document.getElementById(elementId);
    if (!element) {
      console.error(`Element with id ${elementId} not found`);
      return false;
    }

    const canvas = await html2canvas(element, {
      scale: 2,
      useCORS: true,
      allowTaint: true,
      logging: false,
      backgroundColor: '#ffffff',
      windowWidth: element.scrollWidth || 1024,
    });

    const imgData = canvas.toDataURL('image/jpeg', 0.98);
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
    });

    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = pdf.internal.pageSize.getHeight();

    const imgWidth = pdfWidth;
    const imgHeight = (canvas.height * pdfWidth) / canvas.width;

    let heightLeft = imgHeight;
    let position = 0;

    pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight);
    heightLeft -= pdfHeight;

    while (heightLeft > 0) {
      position = heightLeft - imgHeight;
      pdf.addPage();
      pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight);
      heightLeft -= pdfHeight;
    }

    pdf.save(filename);
    return true;
  } catch (err) {
    console.error("PDF generation failed:", err);
    triggerPrintDocument(elementId);
    return false;
  }
};

export const triggerPrintDocument = (printableElementId?: string) => {
  try {
    window.focus();

    const originalTitle = document.title;
    document.title = "Election Commission of Pakistan - Inventory Report";

    const isInsideIframe = window.self !== window.top;

    if (isInsideIframe) {
      // In iframe preview mode, fallbackPrint opens popup with full active styles copied
      fallbackPrint(printableElementId);
    } else {
      window.print();
    }

    setTimeout(() => {
      document.title = originalTitle;
    }, 1000);
  } catch (err) {
    console.error("Print invocation error:", err);
    fallbackPrint(printableElementId);
  }
};

const fallbackPrint = (printableElementId?: string) => {
  try {
    const targetElement = printableElementId ? document.getElementById(printableElementId) : null;
    const modalElement = document.getElementById('printReportModalOverlay');
    const element = targetElement || modalElement;

    if (!element) return;

    // Collect all active style tags and stylesheets from main document head to preserve Tailwind styles
    const stylesHtml = Array.from(document.querySelectorAll('style, link[rel="stylesheet"]'))
      .map(node => node.outerHTML)
      .join('\n');

    const printWin = window.open('about:blank', '_blank', 'width=1000,height=850,scrollbars=yes,resizable=yes');
    if (printWin) {
      printWin.document.open();
      printWin.document.title = "Election Commission of Pakistan - Inventory Report";
      printWin.document.write(`
        <!DOCTYPE html>
        <html>
          <head>
            <title>Election Commission of Pakistan - Inventory Report</title>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            ${stylesHtml}
            <style>
              @page { size: A4 portrait; margin: 10mm; }
              * { box-sizing: border-box; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
              body { 
                font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; 
                background: #ffffff !important; 
                color: #0f172a !important; 
                margin: 0; 
                padding: 16px; 
              }
              .print\\:hidden, button, .no-print, [class*="print:hidden"] { display: none !important; }
              img { max-width: 100%; }
              table { border-collapse: collapse !important; width: 100% !important; }
              tr { page-break-inside: avoid !important; }
              th, td { border: 1px solid #cbd5e1 !important; word-break: break-word !important; }
            </style>
          </head>
          <body class="bg-white text-slate-900">
            <div id="printableContent" class="w-full max-w-full bg-white text-slate-900 p-2">${element.innerHTML}</div>
            <script>
              window.onload = function() {
                setTimeout(function() {
                  window.focus();
                  window.print();
                }, 350);
              };
            </script>
          </body>
        </html>
      `);
      printWin.document.close();
    }
  } catch (err) {
    console.error("Fallback print execution error:", err);
  }
};



