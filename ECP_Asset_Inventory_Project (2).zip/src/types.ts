export interface InventoryItem {
  id?: string; // Optional database UUID/ID
  timestampId: number; // Front-end tracking and key field
  nodeLocation: string; // "REC Kohat", "DEC Kohat", etc.
  tabContext: "IT" | "Furniture" | "Misc";
  name: string;
  serial?: string | null;
  model?: string | null;
  category: string;
  receivedFrom?: string | null; // "ECP", "PEC", "REC", "Gifted", etc.
  date?: string | null;
  workingStatus: "Working" | "Non-Working";
  workingSubStatus?: "Issued" | "In-stock" | null;
  issueTo?: string | null;
  designation?: string | null;
  issuedDate?: string | null;
  nonWorkingSubStatus?: "Needs to repair" | "Ready for condemnation" | null;
  remarks?: string | null;
}

export interface UserAccount {
  username?: string;
  password?: string;
  type: "Standard" | "SuperAdmin";
  recoveryRequested?: boolean;
}
