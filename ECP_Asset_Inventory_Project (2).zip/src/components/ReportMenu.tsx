import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import * as XLSX from 'xlsx';
import { 
  FileSpreadsheet, Printer, Search, Filter, 
  CheckCircle2, AlertTriangle, Layers, Laptop
} from 'lucide-react';
import { InventoryItem } from '../types';
import { triggerPrintDocument } from '../utils/printHelper';

interface ReportMenuProps {
  currentTab: "IT" | "Furniture" | "Misc";
  currentNodeLocation: string;
  databaseStore: InventoryItem[];
  initialReportType?: "working" | "nonworking";
  onReportTypeChange?: (type: "working" | "nonworking") => void;
  initialWorkingSubFilter?: string;
  initialNonWorkingSubFilter?: string;
}

export default function ReportMenu({
  currentTab,
  currentNodeLocation,
  databaseStore,
  initialReportType = "working",
  onReportTypeChange,
  initialWorkingSubFilter = "All",
  initialNonWorkingSubFilter = "All"
}: ReportMenuProps) {
  // Simple dual-report type selection: "working" | "nonworking"
  const [selectedReport, setSelectedReport] = useState<"working" | "nonworking">(initialReportType);
  
  // Sub-filters
  const [workingSubFilter, setWorkingSubFilter] = useState<string>(initialWorkingSubFilter); // "All" | "Issued" | "In-stock"
  const [nonWorkingSubFilter, setNonWorkingSubFilter] = useState<string>(initialNonWorkingSubFilter); // "All" | "Needs to repair" | "Ready for condemnation"
  
  // Location Scope: "current" | "all"
  const [locationScope, setLocationScope] = useState<string>("current"); // "current" | "all"

  // Search filter
  const [reportSearchQuery, setReportSearchQuery] = useState<string>("");
  const [showPrintModal, setShowPrintModal] = useState<boolean>(false);

  // Sync state with parent's header actions
  useEffect(() => {
    setSelectedReport(initialReportType);
  }, [initialReportType]);

  useEffect(() => {
    setWorkingSubFilter(initialWorkingSubFilter);
  }, [initialWorkingSubFilter]);

  useEffect(() => {
    setNonWorkingSubFilter(initialNonWorkingSubFilter);
  }, [initialNonWorkingSubFilter]);

  const handleReportToggle = (type: "working" | "nonworking") => {
    setSelectedReport(type);
    if (type === "working") {
      setNonWorkingSubFilter("All");
    } else {
      setWorkingSubFilter("All");
    }
    if (onReportTypeChange) {
      onReportTypeChange(type);
    }
  };

  // Get matching filtered data
  const getFilteredReportData = (): InventoryItem[] => {
    let items = [...databaseStore];
    
    // 1. Location and category tab scope
    if (locationScope === "current") {
      items = items.filter(
        item => 
          (item.nodeLocation || "").trim().toLowerCase() === (currentNodeLocation || "").trim().toLowerCase() &&
          (item.tabContext || "").trim().toLowerCase() === (currentTab || "").trim().toLowerCase()
      );
    }

    // 2. Report Type-specific filtering
    if (selectedReport === "working") {
      items = items.filter(item => item.workingStatus === "Working");
      if (workingSubFilter !== "All") {
        items = items.filter(item => item.workingSubStatus === workingSubFilter);
      }
    } else {
      items = items.filter(item => item.workingStatus === "Non-Working");
      if (nonWorkingSubFilter !== "All") {
        items = items.filter(item => item.nonWorkingSubStatus === nonWorkingSubFilter);
      }
    }

    return items;
  };

  const reportItems = getFilteredReportData();

  // Search filter implementation
  const searchedReportItems = reportItems.filter(item => {
    const query = reportSearchQuery.toLowerCase();
    return (
      item.name.toLowerCase().includes(query) ||
      (item.serial || "").toLowerCase().includes(query) ||
      (item.model || "").toLowerCase().includes(query) ||
      (item.nodeLocation || "").toLowerCase().includes(query) ||
      (item.category || "").toLowerCase().includes(query) ||
      (item.remarks || "").toLowerCase().includes(query) ||
      (item.issueTo || "").toLowerCase().includes(query)
    );
  });

  // KPI Statistics counts
  const totalReportCount = reportItems.length;
  const workingCount = reportItems.filter(item => item.workingStatus === "Working").length;
  const nonWorkingCount = reportItems.filter(item => item.workingStatus === "Non-Working").length;

  const getReportTitle = (): string => {
    const scopeLabel = locationScope === "current" 
      ? `${currentNodeLocation} (${currentTab} Category)`
      : "All Stations & Categories";

    if (selectedReport === "working") {
      const workSub = workingSubFilter === "All" ? "All Types" : workingSubFilter;
      const nonSub = nonWorkingSubFilter === "All" ? "" : ` / ${nonWorkingSubFilter}`;
      return `Working Assets Report (${workSub}${nonSub}) - ${scopeLabel}`;
    } else {
      const nonSub = nonWorkingSubFilter === "All" ? "All Reasons" : nonWorkingSubFilter;
      return `Non-Working Defective Report (${nonSub}) - ${scopeLabel}`;
    }
  };

  // Excel exporter
  const handleExportExcel = () => {
    if (reportItems.length === 0) {
      alert("No data available to export.");
      return;
    }
    const formattedData = reportItems.map((item, idx) => ({
      "S.No": idx + 1,
      "Station Location": item.nodeLocation,
      "Category Tab": item.tabContext,
      "Asset Subtype": item.category,
      "Asset Name": item.name,
      "Model Specifications": item.model || "",
      "Serial/Tag Number": item.serial || "",
      "Working Status": item.workingStatus,
      "Allocation Type": item.workingSubStatus || "",
      "Condition Reason": item.nonWorkingSubStatus || "",
      "Issued To": item.issueTo || "",
      "Designation": item.designation || "",
      "Date Logged": item.date || "",
      "Remarks": item.remarks || ""
    }));

    const worksheet = XLSX.utils.json_to_sheet(formattedData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Inventory Report");
    XLSX.writeFile(workbook, `ECP_Report_${getReportTitle().replace(/[^a-zA-Z0-9]/g, '_')}.xlsx`);
  };

  const handlePrint = () => {
    setShowPrintModal(true);
    setTimeout(() => {
      triggerPrintDocument("printableReportDocumentContent");
    }, 150);
  };

  return (
    <div className="space-y-6">
      {/* Simplify Menu Selector Panel */}
      <div className="bg-slate-900/35 backdrop-blur-xl border border-slate-800/60 rounded-xl p-5 shadow-xl flex flex-col xl:flex-row justify-between items-start xl:items-center gap-4 animate-fadeIn">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <FileSpreadsheet className="w-5 h-5 text-cyan-400" />
            <h3 className="text-sm font-black uppercase tracking-wider text-white">ECP Simple Report Center</h3>
          </div>
          <p className="text-xs text-slate-400 font-medium">Generate simplified official reports with custom filters.</p>
        </div>

        <div className="flex flex-wrap items-center gap-3 w-full xl:w-auto">
          {/* Station location scope switcher */}
          <div className="flex items-center bg-slate-950/45 backdrop-blur-sm p-1.5 rounded-xl border border-slate-800/60 text-xs">
            <button
              onClick={() => setLocationScope("current")}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                locationScope === "current"
                  ? "bg-cyan-600/90 text-white shadow"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              Current Station
            </button>
            <button
              onClick={() => setLocationScope("all")}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                locationScope === "all"
                  ? "bg-cyan-600/90 text-white shadow"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              All Stations
            </button>
          </div>

          {/* Simple Dual Report Selection Tab Switcher */}
          <div className="flex items-center bg-slate-950/45 backdrop-blur-sm p-1 rounded-xl border border-slate-800/60 text-xs font-bold">
            <button
              onClick={() => handleReportToggle("working")}
              className={`px-4 py-2 rounded-lg transition-all cursor-pointer ${
                selectedReport === "working"
                  ? "bg-emerald-600/90 text-white shadow-md"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              Working Report
            </button>
            <button
              onClick={() => handleReportToggle("nonworking")}
              className={`px-4 py-2 rounded-lg transition-all cursor-pointer ${
                selectedReport === "nonworking"
                  ? "bg-rose-600/90 text-white shadow-md"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              Non-Working Report
            </button>
          </div>

          {/* DYNAMIC SUB-MENU SELECTORS */}
          <div className="flex flex-wrap items-center gap-2">
            {selectedReport === "working" && (
              /* Choose Allocation Type Dropdown */
              <div className="flex items-center bg-emerald-950/20 border border-emerald-500/20 px-3 py-1.5 rounded-xl gap-2 animate-fadeIn">
                <span className="text-[10px] uppercase font-black text-emerald-400">Allocation Type:</span>
                <select
                  value={workingSubFilter}
                  onChange={(e) => setWorkingSubFilter(e.target.value)}
                  className="bg-transparent text-xs text-emerald-200 font-bold focus:outline-none focus:ring-0 cursor-pointer border-none py-0 pl-0 pr-6"
                >
                  <option value="All" className="bg-slate-950 text-slate-200 font-bold">All Types</option>
                  <option value="Issued" className="bg-slate-950 text-slate-200 font-bold">Issued</option>
                  <option value="In-stock" className="bg-slate-950 text-slate-200 font-bold">In stock</option>
                </select>
              </div>
            )}

            {selectedReport === "nonworking" && (
              /* Choose Condition Reason Dropdown */
              <div className="flex items-center bg-rose-950/20 border border-rose-500/20 px-3 py-1.5 rounded-xl gap-2 animate-fadeIn">
                <span className="text-[10px] uppercase font-black text-rose-400">Condition Reason:</span>
                <select
                  value={nonWorkingSubFilter}
                  onChange={(e) => setNonWorkingSubFilter(e.target.value)}
                  className="bg-transparent text-xs text-rose-200 font-bold focus:outline-none focus:ring-0 cursor-pointer border-none py-0 pl-0 pr-6"
                >
                  <option value="All" className="bg-slate-950 text-slate-200 font-bold">All Reasons</option>
                  <option value="Needs to repair" className="bg-slate-950 text-slate-200 font-bold">Needs to repair</option>
                  <option value="Ready for condemnation" className="bg-slate-950 text-slate-200 font-bold">Ready for condemnation</option>
                </select>
              </div>
            )}
          </div>

          <button
            onClick={() => {
              setWorkingSubFilter("All");
              setNonWorkingSubFilter("All");
              setReportSearchQuery("");
            }}
            className="px-3.5 py-2 text-xs bg-slate-800/80 hover:bg-slate-700 text-slate-300 font-bold rounded-xl transition cursor-pointer select-none hover:scale-[1.02] active:scale-95"
          >
            Reset
          </button>
        </div>
      </div>

      {/* Generated Report Display Table Section */}
      <div className="bg-slate-900/30 backdrop-blur-xl border border-slate-800/60 rounded-xl p-6 shadow-xl space-y-6 animate-fadeIn">
        {/* Header Summary Panel */}
        <div className="bg-slate-950/30 backdrop-blur-md p-5 rounded-xl border border-slate-800/50 flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
          <div className="space-y-1.5 flex-1">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 text-[10px] font-black uppercase tracking-wider">
              <Layers className="w-3 h-3" /> ECP Live Stock Report
            </div>
            <h2 className="text-lg font-black text-white">{getReportTitle()}</h2>
            <p className="text-xs text-slate-400">
              Found <span className="text-cyan-400 font-bold">{totalReportCount}</span> items matching selected specifications.
            </p>
          </div>

          {/* Metrics */}
          <div className="grid grid-cols-3 gap-3 shrink-0 w-full lg:w-auto font-mono">
            <div className="bg-slate-950/25 p-3 rounded-lg border border-slate-800/60 text-center min-w-[100px]">
              <div className="text-[9px] font-bold text-slate-400 uppercase">Total Items</div>
              <div className="text-base font-black text-white mt-1">{totalReportCount}</div>
            </div>
            <div className="bg-slate-950/25 p-3 rounded-lg border border-slate-800/60 text-center min-w-[100px]">
              <div className="text-[9px] font-bold text-emerald-400 uppercase">Working</div>
              <div className="text-base font-black text-emerald-400 mt-1">{workingCount}</div>
            </div>
            <div className="bg-slate-950/25 p-3 rounded-lg border border-slate-800/60 text-center min-w-[100px]">
              <div className="text-[9px] font-bold text-rose-400 uppercase">Non-Working</div>
              <div className="text-base font-black text-rose-400 mt-1">{nonWorkingCount}</div>
            </div>
          </div>

          {/* Print and Export Buttons */}
          <div className="flex flex-wrap items-center gap-2 shrink-0 w-full lg:w-auto">
            <button
              onClick={handlePrint}
              className="bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-black px-4 py-2.5 rounded-lg flex items-center gap-1.5 cursor-pointer shadow-md transition-all flex-1 lg:flex-none justify-center active:scale-98 hover:scale-[1.02]"
            >
              <Printer className="w-4 h-4" /> Print
            </button>
            <button
              onClick={handleExportExcel}
              className="bg-blue-600 hover:bg-blue-500 text-white text-xs font-black px-4 py-2.5 rounded-lg flex items-center gap-1.5 cursor-pointer shadow-md transition-all flex-1 lg:flex-none justify-center active:scale-98 hover:scale-[1.02]"
            >
              <FileSpreadsheet className="w-4 h-4" /> Export Excel
            </button>
          </div>
        </div>

        {/* Quick Search */}
        <div className="bg-slate-950/25 backdrop-blur-md p-3 rounded-lg border border-slate-800/60 flex items-center justify-between gap-4">
          <span className="text-xs text-slate-400 font-bold hidden sm:inline-flex items-center gap-1">
            <Search className="w-4 h-4 text-cyan-500" /> Filter results:
          </span>
          <div className="relative w-full sm:max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-500" />
            <input
              type="text"
              placeholder="Search matching report criteria..."
              value={reportSearchQuery}
              onChange={(e) => setReportSearchQuery(e.target.value)}
              className="w-full bg-slate-950/45 border border-slate-800/60 rounded-lg py-2 pl-9 pr-3 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition-colors"
            />
          </div>
        </div>

        {/* Report Grid Table */}
        <div className="overflow-x-auto rounded-lg border border-slate-800/60 bg-slate-950/20 backdrop-blur-sm custom-scrollbar">
          <table className="w-full text-left text-xs text-slate-300 divide-y divide-slate-855 min-w-[1100px]">
            <thead className="bg-slate-900/50 backdrop-blur-sm text-slate-200">
              <tr className="text-[10px] font-black uppercase tracking-wider text-slate-400">
                <th className="px-4 py-3 font-semibold text-blue-400">Station location</th>
                <th className="px-4 py-3 font-semibold">Category Tab</th>
                <th className="px-4 py-3 font-semibold">Asset Name</th>
                <th className="px-4 py-3 font-semibold">Serial / Stock Register P.No</th>
                <th className="px-4 py-3 font-semibold">Model specifications</th>
                <th className="px-4 py-3 font-semibold">Subtype Category</th>
                <th className="px-4 py-3 font-semibold">Received From</th>
                <th className="px-4 py-3 font-semibold">Condition Status</th>
                <th className="px-4 py-3 font-semibold">Issued To</th>
                <th className="px-4 py-3 font-semibold">Designation</th>
                <th className="px-4 py-3 font-semibold">Remarks</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-900/60 font-medium">
              {searchedReportItems.length === 0 ? (
                <tr>
                  <td colSpan={11} className="px-6 py-12 text-center text-slate-500 font-extrabold uppercase">
                    No matching registered assets located.
                  </td>
                </tr>
              ) : (
                searchedReportItems.map((item) => {
                  const isWorking = item.workingStatus === "Working";
                  return (
                    <tr key={item.timestampId} className="hover:bg-slate-850/30 transition text-slate-100">
                      <td className="px-4 py-3.5 font-bold text-slate-400 font-mono">{item.nodeLocation}</td>
                      <td className="px-4 py-3.5 text-xs text-zinc-400 font-bold uppercase">{item.tabContext}</td>
                      <td className="px-4 py-3.5 text-white font-extrabold">{item.name}</td>
                      <td className="px-4 py-3.5 text-cyan-400 font-mono font-bold tracking-wide">{item.serial || '-'}</td>
                      <td className="px-4 py-3.5 text-slate-400">{item.model || '-'}</td>
                      <td className="px-4 py-3.5">
                        <span className="bg-slate-800 px-2 py-0.5 rounded text-amber-500 font-semibold">{item.category}</span>
                      </td>
                      <td className="px-4 py-3.5 text-slate-450">{item.receivedFrom || '-'}</td>
                      <td className="px-4 py-3.5">
                        <div className="space-y-1">
                          <span className={`inline-flex items-center gap-1 font-bold px-2 py-0.5 rounded text-[10px] border ${
                            isWorking 
                              ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/15' 
                              : 'bg-rose-500/10 text-rose-400 border-rose-500/15'
                          }`}>
                            {item.workingStatus}
                          </span>
                          {isWorking && item.workingSubStatus && (
                            <span className="block text-[10px] text-slate-500 font-bold bg-slate-950 px-1 rounded text-center">
                              {item.workingSubStatus}
                            </span>
                          )}
                          {!isWorking && item.nonWorkingSubStatus && (
                            <span className="block text-[10px] text-rose-400 font-bold bg-rose-500/5 px-1 rounded text-center border border-rose-500/10">
                              {item.nonWorkingSubStatus}
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="px-4 py-3.5 text-slate-100 font-extrabold">{item.issueTo || '-'}</td>
                      <td className="px-4 py-3.5 text-slate-400 font-bold">{item.designation || '-'}</td>
                      <td className="px-4 py-3.5 text-slate-400 italic max-w-xs truncate" title={item.remarks || ""}>
                        {item.remarks || '-'}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* PRINT PREVIEW OVERLAY DIALOG */}
      {showPrintModal && createPortal(
        <div id="printReportModalOverlay" className="fixed inset-0 z-50 bg-slate-950/95 backdrop-blur-md overflow-y-auto p-4 md:p-8 flex items-start justify-center print:static print:bg-white print:p-0 print:overflow-visible">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-5xl w-full shadow-2xl overflow-hidden print:border-none print:shadow-none print:bg-white">
            
            {/* Toolbar controls */}
            <div className="bg-slate-950 px-6 py-4 border-b border-slate-800 flex flex-col md:flex-row md:items-center md:justify-between gap-3 print:hidden">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                  <Printer className="w-4 h-4 text-cyan-400" /> Official Report Print / PDF Export
                </h3>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Scope: <span className="text-cyan-400 font-bold">{getReportTitle()}</span>
                </p>
              </div>
              
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => triggerPrintDocument("printableReportDocumentContent")}
                  className="bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-black px-4 py-2 rounded-xl flex items-center gap-1.5 cursor-pointer shadow-lg transition active:scale-98"
                >
                  <Printer className="w-4 h-4" /> Print Document
                </button>
                <button
                  type="button"
                  onClick={() => setShowPrintModal(false)}
                  className="bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold px-4 py-2 rounded-xl cursor-pointer transition active:scale-98"
                >
                  Close
                </button>
              </div>
            </div>

            {/* Print canvas */}
            <div id="printableReportDocumentContent" className="p-6 md:p-8 bg-white text-slate-950 min-h-[500px]">
              
              {/* official ECP branding */}
              <div className="border-b-2 border-slate-800 pb-4 mb-6">
                <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 bg-emerald-800 rounded-full flex items-center justify-center font-black text-white shrink-0 text-xl shadow-md">
                      ECP
                    </div>
                    <div className="text-center sm:text-left">
                      <h1 className="text-xl font-black uppercase tracking-wide text-slate-950">
                        Election Commission of Pakistan
                      </h1>
                      <p className="text-xs font-extrabold text-emerald-800 tracking-wider uppercase">
                        OFFICIAL INVENTORY TRACKING & LEDGER REPORT
                      </p>
                    </div>
                  </div>
                  
                  <div className="text-center sm:text-right">
                    <span className="text-[10px] font-black uppercase tracking-widest text-slate-500 block">
                      Location / Scope
                    </span>
                    <span className="text-sm font-black text-blue-700 uppercase block mt-0.5">
                      {locationScope === "current" ? currentNodeLocation : "ALL STATIONS"}
                    </span>
                  </div>
                </div>
                
                <div className="flex flex-col sm:flex-row justify-between items-center mt-4 pt-2 border-t border-slate-200 text-xs text-slate-600 gap-1.5">
                  <div>
                    Generated Report: <strong className="text-slate-900">{getReportTitle()}</strong>
                  </div>
                  <div>
                    Generated Date: <strong className="text-slate-900">{new Date().toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</strong>
                  </div>
                </div>
              </div>

              {/* KPIs */}
              <div className="mb-6">
                <div className="grid grid-cols-3 gap-3">
                  <div className="bg-slate-50 border border-slate-200 p-3 rounded-lg text-center">
                    <div className="text-[9px] font-bold text-slate-500 uppercase">Total Items pool</div>
                    <div className="text-lg font-black text-slate-950 mt-1">{totalReportCount}</div>
                  </div>
                  <div className="bg-slate-50 border border-slate-200 p-3 rounded-lg text-center">
                    <div className="text-[9px] font-bold text-emerald-700 uppercase">Working Count</div>
                    <div className="text-lg font-black text-emerald-700 mt-1">{workingCount}</div>
                  </div>
                  <div className="bg-slate-50 border border-slate-200 p-3 rounded-lg text-center">
                    <div className="text-[9px] font-bold text-rose-700 uppercase">Non-Working Count</div>
                    <div className="text-lg font-black text-rose-700 mt-1">{nonWorkingCount}</div>
                  </div>
                </div>
              </div>

              {/* Records List */}
              <div className="mb-6">
                <div className="text-xs font-black uppercase tracking-wider text-slate-500 mb-2 pl-1">
                  Generated Inventory Records List ({searchedReportItems.length} items found)
                </div>
                <div className="overflow-x-auto border border-slate-300 rounded-none mt-2">
                  <table className="w-full text-left text-[9px] text-slate-900 border-collapse">
                    <thead className="bg-slate-100 border-b border-slate-300">
                      <tr>
                        <th className="px-2 py-1.5 font-bold border border-slate-300">Station</th>
                        <th className="px-2 py-1.5 font-bold border border-slate-300">Category</th>
                        <th className="px-2 py-1.5 font-bold border border-slate-300">Asset Name</th>
                        <th className="px-2 py-1.5 font-bold border border-slate-300">Serial No</th>
                        <th className="px-2 py-1.5 font-bold border border-slate-300">Model</th>
                        <th className="px-2 py-1.5 font-bold border border-slate-300">Received From</th>
                        <th className="px-2 py-1.5 font-bold border border-slate-300">Condition Status</th>
                        <th className="px-2 py-1.5 font-bold border border-slate-300">Issued To</th>
                        <th className="px-2 py-1.5 font-bold border border-slate-300">Designation</th>
                        <th className="px-2 py-1.5 font-bold border border-slate-300">Remarks</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-300">
                      {searchedReportItems.length === 0 ? (
                        <tr>
                          <td colSpan={10} className="px-4 py-8 text-center text-slate-500 italic border border-slate-300 bg-slate-50">
                            No matching records found.
                          </td>
                        </tr>
                      ) : (
                        searchedReportItems.map((item, idx) => {
                          const isWorkingStatus = item.workingStatus === "Working";
                          return (
                            <tr key={item.timestampId} className="bg-white hover:bg-slate-50">
                              <td className="px-2 py-1.5 font-bold border border-slate-300">{item.nodeLocation}</td>
                              <td className="px-2 py-1.5 border border-slate-300 uppercase">{item.tabContext}</td>
                              <td className="px-2 py-1.5 font-semibold border border-slate-300">{item.name}</td>
                              <td className="px-2 py-1.5 border border-slate-300 font-mono text-[8px]">{item.serial || '-'}</td>
                              <td className="px-2 py-1.5 border border-slate-300">{item.model || '-'}</td>
                              <td className="px-2 py-1.5 border border-slate-300">{item.receivedFrom || '-'}</td>
                              <td className="px-2 py-1.5 border border-slate-300">
                                <div className="flex flex-col items-start gap-0.5">
                                  <span className={`text-[8px] font-bold px-1.5 py-0.2 rounded border ${
                                    isWorkingStatus 
                                      ? 'bg-emerald-50 text-emerald-800 border-emerald-300' 
                                      : 'bg-rose-50 text-rose-800 border-rose-300'
                                  }`}>
                                    {item.workingStatus}
                                  </span>
                                  {item.workingSubStatus && (
                                    <span className="text-[7px] text-slate-700 bg-slate-100 border border-slate-200 px-1 rounded block mt-0.5">
                                      {item.workingSubStatus}
                                    </span>
                                  )}
                                  {item.nonWorkingSubStatus && (
                                    <span className="text-[7px] text-rose-900 bg-rose-50 border border-rose-200 px-1 rounded block mt-0.5 font-medium">
                                      {item.nonWorkingSubStatus}
                                    </span>
                                  )}
                                </div>
                              </td>
                              <td className="px-2 py-1.5 border border-slate-300 font-semibold">{item.issueTo || '-'}</td>
                              <td className="px-2 py-1.5 border border-slate-300 text-slate-800">{item.designation || '-'}</td>
                              <td className="px-2 py-1.5 border border-slate-300 text-slate-800 italic text-[8px] whitespace-normal break-words">
                                {item.remarks || '-'}
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Signature space */}
              <div className="flex justify-end pt-8 mt-12 border-t border-dashed border-slate-300">
                <div className="border border-dashed border-slate-300 p-4 rounded-lg text-center w-80 bg-white text-slate-900 leading-normal">
                  <div className="h-14 border-b border-slate-200 flex items-center justify-center text-[10px] text-slate-400 italic"></div>
                  <div className="pt-2 font-black text-[11px] tracking-wide text-slate-900 uppercase">
                    {locationScope === "current" && currentNodeLocation.startsWith("REC") ? "Regional" : "District"} Election Commissioner
                  </div>
                  <div className="text-[9px] text-slate-600 font-bold mt-0.5">
                    {locationScope === "current" ? currentNodeLocation.replace(/REC|DEC/g, "").trim() : "ADMINISTRATION"} Division / Region
                  </div>
                </div>
              </div>

            </div>

            {/* Footer buttons */}
            <div className="bg-slate-950 px-6 py-4 border-t border-slate-800 flex items-center justify-end gap-2 print:hidden">
              <button
                type="button"
                onClick={() => setShowPrintModal(false)}
                className="bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs py-2 px-5 rounded-xl cursor-pointer transition active:scale-98"
              >
                Close Preview
              </button>
              <button
                type="button"
                onClick={() => triggerPrintDocument("printableReportDocumentContent")}
                className="bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs py-2 px-5 rounded-xl flex items-center gap-1.5 cursor-pointer shadow-lg transition active:scale-98"
              >
                <Printer className="w-4 h-4" /> Print Document
              </button>
            </div>

          </div>
        </div>
      , document.body)}
    </div>
  );
}
