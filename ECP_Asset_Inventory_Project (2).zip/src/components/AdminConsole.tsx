import React, { useState } from 'react';
import { ShieldCheck, UserPlus, Trash2, Shield, Eye, Lock, RefreshCw, KeyRound } from 'lucide-react';
import { UserAccount } from '../types';

interface AdminConsoleProps {
  systemUsers: Record<string, UserAccount>;
  activeUser: string;
  onUsersUpdate: (updated: Record<string, UserAccount>) => void;
}

export default function AdminConsole({ systemUsers, activeUser, onUsersUpdate }: AdminConsoleProps) {
  const [newUsername, setNewUsername] = useState<string>("");
  const [newType, setNewType] = useState<"Standard" | "SuperAdmin">("Standard");
  const [newPassword, setNewPassword] = useState<string>("");

  const handleCreateUser = () => {
    const trimmedUser = newUsername.trim();
    const trimmedPass = newPassword.trim();

    if (!trimmedUser || !trimmedPass) {
      alert("Validation Fault: User credentials parameters allocation cannot be left empty.");
      return;
    }

    if (systemUsers[trimmedUser]) {
      alert("Security Conflict: This workspace identity profile already exists.");
      return;
    }

    const updated = {
      ...systemUsers,
      [trimmedUser]: {
        password: trimmedPass,
        type: newType,
        recoveryRequested: false
      }
    };

    onUsersUpdate(updated);
    setNewUsername("");
    setNewPassword("");
    alert(`Account Profile for [${trimmedUser}] registered successfully.`);
  };

  const handleDeleteUser = (username: string) => {
    if (username === activeUser) {
      alert("Protection Fault: Cannot remove your active configuration layer.");
      return;
    }

    if (window.confirm(`Are you sure you want to completely erase the account profile for [${username}]? This removes their access privileges.`)) {
      const updated = { ...systemUsers };
      delete updated[username];
      onUsersUpdate(updated);
    }
  };

  const [manualPasswords, setManualPasswords] = useState<Record<string, string>>({});

  const handleAssignManualPassword = (username: string) => {
    const manualPass = window.prompt(`Enter new manual password for [${username}]:`);
    if (manualPass === null) return; // User cancelled
    const trimmedPass = manualPass.trim();
    if (!trimmedPass) {
      alert("Validation Fault: Password field cannot be left empty.");
      return;
    }

    const updated = {
      ...systemUsers,
      [username]: {
        ...systemUsers[username],
        password: trimmedPass,
        recoveryRequested: false
      }
    };

    onUsersUpdate(updated);
    alert(`🔑 SUCCESS! Manually assigned new password for [${username}]: "${trimmedPass}". It is now saved and synchronized.`);
  };

  const handleSaveManualPassword = (username: string) => {
    const password = (manualPasswords[username] || "").trim();
    if (!password) {
      alert("Validation Fault: Password field cannot be empty.");
      return;
    }

    const updated = {
      ...systemUsers,
      [username]: {
        ...systemUsers[username],
        password: password,
        recoveryRequested: false
      }
    };

    onUsersUpdate(updated);
    setManualPasswords(prev => {
      const copy = { ...prev };
      delete copy[username];
      return copy;
    });
    alert(`🔑 SUCCESS! Manually set new password for [${username}]: "${password}". It is now saved and synchronized.`);
  };

  const activeRecoveryRequests = Object.entries(systemUsers).filter(
    ([_, account]) => account.recoveryRequested
  );

  return (
    <div className="bg-slate-900/30 backdrop-blur-xl border border-dashed border-cyan-500/30 rounded-xl p-5 mb-6 shadow-lg space-y-6 animate-fadeIn">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-cyan-400" />
          <h3 className="text-sm font-bold uppercase tracking-wider text-cyan-400">
            Super Admin System Console
          </h3>
        </div>
      </div>

      {/* Real-time Password Recovery Requests Dashboard */}
      {activeRecoveryRequests.length > 0 && (
        <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-4 animate-fadeIn">
          <h4 className="text-xs font-black uppercase text-amber-400 tracking-wider mb-3 flex items-center gap-2">
            <RefreshCw className="w-4 h-4 text-amber-400 animate-spin" />
            Active Forgot Password (Recovery) Requests
          </h4>
          <div className="grid grid-cols-1 gap-3">
            {activeRecoveryRequests.map(([username, account]) => (
              <div key={username} className="bg-slate-950/40 backdrop-blur-md p-3 rounded-lg border border-slate-800/60 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
                <div>
                  <div className="font-extrabold text-slate-200">{username}</div>
                  <div className="text-[10px] text-slate-500">Requested password reset</div>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <input
                    type="text"
                    placeholder="Enter manual password..."
                    value={manualPasswords[username] || ""}
                    onChange={(e) => setManualPasswords(prev => ({ ...prev, [username]: e.target.value }))}
                    className="bg-slate-900/80 border border-slate-750 focus:border-amber-500 focus:outline-none rounded-lg px-3 py-1.5 text-xs text-white placeholder-slate-500 w-48 transition-all"
                  />
                  <button
                    onClick={() => handleSaveManualPassword(username)}
                    className="bg-amber-600 hover:bg-amber-500 text-white font-bold py-1.5 px-3 rounded-md transition-all flex items-center gap-1.5 cursor-pointer select-none active:scale-95"
                    title="Set manual password and approve request"
                  >
                    <KeyRound className="w-3.5 h-3.5" />
                    Set Password
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end mb-5">
        <div>
          <label className="block text-xs font-semibold text-slate-400 mb-1.5">
            Account Username / Office
          </label>
          <input
            type="text"
            placeholder="e.g. DEC Peshawar"
            value={newUsername}
            onChange={(e) => setNewUsername(e.target.value)}
            className="w-full bg-slate-950/45 border border-slate-800/60 rounded-lg p-2 text-sm text-slate-200 focus:outline-none focus:border-cyan-500 transition-colors"
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-400 mb-1.5">
            Access Security Type
          </label>
          <select
            value={newType}
            onChange={(e) => setNewType(e.target.value as "Standard" | "SuperAdmin")}
            className="w-full bg-slate-950/45 border border-slate-800/60 rounded-lg p-2 text-sm text-slate-200 focus:outline-none focus:border-cyan-500 transition-colors"
          >
            <option value="Standard" className="bg-slate-950 text-slate-200">Standard Account (REC / DEC)</option>
            <option value="SuperAdmin" className="bg-slate-950 text-slate-200">Super Admin (Full Consent Scope)</option>
          </select>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-400 mb-1.5">
            Password
          </label>
          <input
            type="text"
            placeholder="Assign password"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            className="w-full bg-slate-950/45 border border-slate-800/60 rounded-lg p-2 text-sm text-slate-200 focus:outline-none focus:border-cyan-500 transition-colors"
          />
        </div>

        <button
          onClick={handleCreateUser}
          className="bg-green-600 hover:bg-green-500 text-white font-semibold rounded-lg text-sm px-4 py-2 flex items-center justify-center gap-1.5 cursor-pointer h-[38px] transition-all hover:scale-[1.02] active:scale-98"
        >
          <UserPlus className="w-4 h-4" /> Create User
        </button>
      </div>

      <div className="border-t border-slate-800/60 pt-4">
        <div className="text-xs font-semibold uppercase text-slate-500 tracking-wider mb-2">
          Registered system directory:
        </div>
        <div className="bg-slate-950/25 backdrop-blur-md rounded-lg max-h-[160px] overflow-y-auto divide-y divide-slate-800/50 border border-slate-800/60">
          {Object.entries(systemUsers).map(([username, account]) => {
            const isSelf = username === activeUser;
            return (
              <div key={username} className="flex justify-between items-center px-4 py-2 text-xs">
                <div className="flex items-center gap-4">
                  <span className="font-bold text-slate-200">{username}</span>
                  <span className="text-slate-500 flex items-center gap-1">
                    <Shield className="w-3.5 h-3.5 text-cyan-500/50" /> {account.type}
                  </span>
                  <span className="text-slate-500 flex items-center gap-1">
                    <Lock className="w-3.5 h-3.5 text-slate-600" /> {account.password}
                  </span>
                  {account.recoveryRequested && (
                    <span className="px-1.5 py-0.5 rounded bg-amber-500/10 border border-amber-500/20 text-amber-500 font-bold text-[9px] uppercase animate-pulse">
                      Reset Pending
                    </span>
                  )}
                </div>
                <div>
                  {isSelf ? (
                    <span className="text-slate-500 italic font-medium px-2 py-1">Active Session</span>
                  ) : (
                    <div className="flex items-center gap-1.5">
                      {account.recoveryRequested ? (
                        <button
                          onClick={() => handleAssignManualPassword(username)}
                          className="bg-amber-600 hover:bg-amber-500 text-white text-[10px] font-bold px-2 py-1 rounded transition cursor-pointer flex items-center gap-1"
                        >
                          <KeyRound className="w-3 h-3" /> Set Password
                        </button>
                      ) : (
                        <button
                          onClick={() => handleAssignManualPassword(username)}
                          className="bg-slate-850 hover:bg-slate-750 text-slate-300 hover:text-white text-[10px] font-bold px-2.5 py-1 rounded border border-slate-800/80 transition cursor-pointer flex items-center gap-1"
                          title="Manually set a new password for this account"
                        >
                          <KeyRound className="w-3 h-3 text-blue-400" /> Reset Pass
                        </button>
                      )}
                      <button
                        onClick={() => handleDeleteUser(username)}
                        className="bg-red-500/10 hover:bg-red-500 text-red-400 hover:text-white border border-red-500/20 px-2.5 py-1 rounded transition cursor-pointer flex items-center gap-1"
                      >
                        <Trash2 className="w-3 h-3" /> Wipe
                      </button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
