import React, { useState, useEffect } from 'react';
import { KeyRound, ShieldAlert, UserCheck, HelpCircle, Lock } from 'lucide-react';
import { UserAccount } from '../types';

interface LoginScreenProps {
  systemUsers: Record<string, UserAccount>;
  onLoginSuccess: (username: string, accountType: "Standard" | "SuperAdmin") => void;
  onPasswordChanged: (updatedUsers: Record<string, UserAccount>) => void;
}

export default function LoginScreen({ systemUsers, onLoginSuccess, onPasswordChanged }: LoginScreenProps) {
  const [selectedUser, setSelectedUser] = useState<string>(Object.keys(systemUsers)[1] || "REC Kohat");
  const [password, setPassword] = useState<string>("");
  const [recoveryNotice, setRecoveryNotice] = useState<string | null>(null);
  
  // Change password modal state
  const [isChangeModalOpen, setIsChangeModalOpen] = useState<boolean>(false);
  const [changeUser, setChangeUser] = useState<string>(Object.keys(systemUsers)[1] || "REC Kohat");
  const [oldPassword, setOldPassword] = useState<string>("");
  const [newPassword, setNewPassword] = useState<string>("");

  const [logoSrc, setLogoSrc] = useState<string>("ecp logo.jpg");
  const [logoLoadFailed, setLogoLoadFailed] = useState<boolean>(false);

  useEffect(() => {
    const userProfile = systemUsers[selectedUser];
    if (userProfile && userProfile.recoveryRequested) {
      setRecoveryNotice(`🔑 A request for a new password has been submitted. Please wait for the Super Admin to generate your new password.`);
    } else {
      setRecoveryNotice(null);
    }
  }, [selectedUser, systemUsers]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const userProfile = systemUsers[selectedUser];
    if (userProfile && userProfile.password === password) {
      setRecoveryNotice(null);
      setPassword("");
      onLoginSuccess(selectedUser, userProfile.type);
    } else {
      alert("Authentication failed! Incorrect password entry allocation.");
    }
  };

  const handleForgotPassword = () => {
    const userProfile = systemUsers[selectedUser];
    if (!userProfile) return;

    const updated = {
      ...systemUsers,
      [selectedUser]: {
        ...userProfile,
        recoveryRequested: true
      }
    };
    onPasswordChanged(updated);
    setRecoveryNotice(`🔑 Request for new Password has been submitted for ${selectedUser}. Please contact the Super Admin to generate your new password.`);
    alert(`Request for new Password submitted successfully for ${selectedUser}. Super Admin has been notified.`);
  };

  const handleSaveChangedPassword = () => {
    if (!oldPassword || !newPassword) {
      alert("Validation Fault: Please fill in all fields.");
      return;
    }
    const userProfile = systemUsers[changeUser];
    if (!userProfile) {
      alert("Invalid selection account.");
      return;
    }
    if (userProfile.password !== oldPassword) {
      alert("The existing password value is invalid!");
      return;
    }

    const updated = {
      ...systemUsers,
      [changeUser]: {
        ...userProfile,
        password: newPassword,
        recoveryRequested: false // clear recovery if password changed manually
      }
    };
    onPasswordChanged(updated);
    alert(`Password for ${changeUser} updated successfully!`);
    setIsChangeModalOpen(false);
    setOldPassword("");
    setNewPassword("");
  };

  return (
    <div id="loginWrapper" className="flex flex-col items-center justify-center min-h-screen bg-[#0f1a2e]/75 backdrop-blur-xl bg-grid-pattern p-4 text-slate-100 relative">
      
      {/* Absolute top global scrolling header banner */}
      <div className="absolute top-0 left-0 right-0 bg-gradient-to-r from-blue-950/70 via-slate-900/70 to-indigo-950/70 backdrop-blur-md border-b border-blue-500/15 py-2.5 px-6 shadow-lg text-xs font-black uppercase tracking-wider text-cyan-400 select-none flex items-center justify-between">
        <marquee behavior="scroll" direction="left" scrollamount="5" className="w-full text-slate-100 tracking-widest font-extrabold text-center">
          Election Commission Of Pakistan Inventory Management Portal
        </marquee>
      </div>

      <div className="bg-slate-900/30 backdrop-blur-2xl border border-slate-800/80 rounded-2xl shadow-2xl p-8 max-w-sm w-full space-y-6 mt-10">
        <div className="text-center space-y-2">
          <div className="relative w-16 h-16 mx-auto flex items-center justify-center shrink-0 mb-1">
            {!logoLoadFailed ? (
              <img 
                src={logoSrc} 
                alt="ECP Logo" 
                onError={() => {
                  if (logoSrc === "ecp logo.jpg") {
                    setLogoSrc("ecp_logo.jpg");
                  } else {
                    setLogoLoadFailed(true);
                  }
                }}
                className="w-16 h-16 object-cover rounded-full border border-slate-700/60 shadow-md animate-fadeIn"
              />
            ) : (
              <div className="w-16 h-16 bg-gradient-to-tr from-emerald-600 to-teal-500 rounded-full flex items-center justify-center font-extrabold text-white text-xl shadow-lg shadow-emerald-500/20 ring-2 ring-emerald-400/30 animate-fadeIn">
                ECP
              </div>
            )}
          </div>
          <h2 className="text-xl md:text-2xl font-extrabold tracking-tight text-white">
            Inventory Management System
          </h2>
          <p className="text-xs text-emerald-400 font-bold tracking-wider uppercase">
            Election Commission of Pakistan
          </p>
        </div>

        {recoveryNotice && (
          <div className="bg-blue-500/10 border border-blue-500/20 text-blue-300 p-3 rounded-lg text-xs flex gap-2 items-start leading-relaxed animate-fadeIn">
            <ShieldAlert className="w-5 h-5 shrink-0 text-blue-400" />
            <span>{recoveryNotice}</span>
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-widest mb-1">
              Select Office
            </label>
            <div className="relative">
              <select
                value={selectedUser}
                onChange={(e) => {
                  setSelectedUser(e.target.value);
                  setRecoveryNotice(null);
                }}
                className="w-full bg-slate-950/45 border border-slate-800/60 focus:border-blue-500 focus:outline-none rounded-lg py-2.5 px-3.5 text-sm text-slate-100 placeholder-slate-500 transition-colors"
              >
                {Object.keys(systemUsers).map((username) => (
                  <option key={username} value={username} className="bg-slate-950 text-slate-200">
                    {username} ({systemUsers[username].type === 'SuperAdmin' ? 'Super Admin' : 'Office'})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-widest mb-1 text-left">
              Password
            </label>
            <div className="relative">
              <input
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-slate-950/45 border border-slate-800/60 focus:border-blue-500 focus:outline-none rounded-lg py-2.5 px-3.5 text-sm text-slate-100 placeholder-slate-500 transition-colors"
                required
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-blue-600 hover:bg-blue-500 active:bg-blue-700 text-white font-medium py-2.5 px-4 rounded-lg text-sm transition-all shadow-md active:scale-98 cursor-pointer flex items-center justify-center gap-2 mt-2"
          >
            <KeyRound className="w-4 h-4" /> Sign In
          </button>

          <button
            type="button"
            onClick={handleForgotPassword}
            className="w-full bg-slate-800 hover:bg-slate-700 active:bg-slate-900 border border-slate-700/60 text-slate-200 font-medium py-2 px-4 rounded-lg text-xs transition-all shadow-sm active:scale-98 cursor-pointer flex items-center justify-center gap-1.5 mt-1"
          >
            <HelpCircle className="w-3.5 h-3.5 text-blue-400" /> Request for new Password
          </button>
        </form>
      </div>

      {/* Change Password Modal */}
      {isChangeModalOpen && (
        <div className="fixed inset-0 flex items-center justify-center bg-black/60 backdrop-blur-sm z-50 p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 w-full max-w-sm space-y-4 shadow-2xl relative">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <UserCheck className="w-5 h-5 text-blue-400" /> Change Password
            </h3>
            
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">
                  Select Profile Target
                </label>
                <select
                  value={changeUser}
                  onChange={(e) => setChangeUser(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-sm text-white"
                >
                  {Object.keys(systemUsers).map((username) => (
                    <option key={username} value={username}>
                      {username} Profile
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">
                  Current Password
                </label>
                <input
                  type="password"
                  placeholder="Existing Password"
                  value={oldPassword}
                  onChange={(e) => setOldPassword(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-sm text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">
                  New Password
                </label>
                <input
                  type="password"
                  placeholder="Proposed Password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-sm text-white focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>

            <div className="flex gap-2 justify-end pt-2 text-xs">
              <button
                type="button"
                onClick={() => setIsChangeModalOpen(false)}
                className="bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold px-4 py-2 rounded-md transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveChangedPassword}
                className="bg-green-600 hover:bg-green-500 text-white font-semibold px-4 py-2 rounded-md transition cursor-pointer"
              >
                Save Password
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
