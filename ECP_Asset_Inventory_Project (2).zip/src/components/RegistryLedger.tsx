import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import * as XLSX from 'xlsx';
import { 
  FileSpreadsheet, Printer, Trash2, Edit2, Plus, 
  CheckCircle2, Search, Filter, Download, Sofa, Layers, Cpu, Camera, Droplet, Tv, Laptop, Package,
  AlertTriangle, Shield, RotateCcw
} from 'lucide-react';
import { InventoryItem } from '../types';
import { triggerPrintDocument } from '../utils/printHelper';

interface RegistryLedgerProps {
  key?: string;
  currentTab: "IT" | "Furniture" | "Misc";
  scopeData: InventoryItem[];
  allLocationData?: InventoryItem[];
  currentNodeLocation: string;
  isWriteAllowed: boolean;
  isSuperAdmin?: boolean;
  onItemCommit: (payload: Omit<InventoryItem, 'timestampId'> & { timestampId?: number }) => Promise<void>;
  onItemDelete: (timestampId: number) => Promise<void>;
  onItemDeleteAll: () => Promise<void>;
  onTabChange?: (tab: "IT" | "Furniture" | "Misc") => void;
  onItemsBulkCommit?: (items: InventoryItem[]) => Promise<void>;
}

export default function RegistryLedger({
  currentTab,
  scopeData,
  allLocationData = [],
  currentNodeLocation,
  isWriteAllowed,
  isSuperAdmin = false,
  onItemCommit,
  onItemDelete,
  onItemDeleteAll,
  onTabChange,
  onItemsBulkCommit
}: RegistryLedgerProps) {
  // Input fields state
  const [assetName, setAssetName] = useState<string>("");
  const [assetSerial, setAssetSerial] = useState<string>("");
  const [assetModel, setAssetModel] = useState<string>("");
  const [assetCategory, setAssetCategory] = useState<string>("");
  const [assetReceived, setAssetReceived] = useState<string>("");
  const [assetDate, setAssetDate] = useState<string>("");
  const [workingStatus, setWorkingStatus] = useState<string>("");
  const [workingSubStatus, setWorkingSubStatus] = useState<string>("");
  const [issueTo, setIssueTo] = useState<string>("");
  const [designation, setDesignation] = useState<string>("");
  const [issuedDate, setIssuedDate] = useState<string>("");
  const [nonWorkingSubStatus, setNonWorkingSubStatus] = useState<string>("");
  const [remarks, setRemarks] = useState<string>("");
  
  // Gifter / Donor states
  const [gifterName, setGifterName] = useState<string>("");
  const [gifterDesignation, setGifterDesignation] = useState<string>("");

  // Edit states
  const [editingItemId, setEditingItemId] = useState<number | null>(null);

  // Non-blocking confirmation states to circumvent iframe sandbox window.confirm restrictions
  const [confirmDeleteId, setConfirmDeleteId] = useState<number | null>(null);
  const [confirmClearAll, setConfirmClearAll] = useState<boolean>(false);

  // Auto-reset delete confirmation after 4 seconds of inactivity
  useEffect(() => {
    if (confirmDeleteId !== null) {
      const timer = setTimeout(() => {
        setConfirmDeleteId(null);
      }, 4000);
      return () => clearTimeout(timer);
    }
  }, [confirmDeleteId]);

  // Auto-reset clear all confirmation after 4 seconds of inactivity
  useEffect(() => {
    if (confirmClearAll) {
      const timer = setTimeout(() => {
        setConfirmClearAll(false);
      }, 4000);
      return () => clearTimeout(timer);
    }
  }, [confirmClearAll]);

  // Print & Save Success Dialog States
  const [saveSuccessMsg, setSaveSuccessMsg] = useState<string | null>(null);
  const [showPrintPreviewModal, setShowPrintPreviewModal] = useState<boolean>(false);
  const [downloadModalData, setDownloadModalData] = useState<{ isOpen: boolean; html: string }>({ isOpen: false, html: "" });
  const [copiedHtml, setCopiedHtml] = useState<boolean>(false);
  const [isCompiling, setIsCompiling] = useState<boolean>(false);
  const [isCookieBlocked, setIsCookieBlocked] = useState<boolean>(false);

  // Auto dismiss success notification after 3 seconds
  useEffect(() => {
    if (saveSuccessMsg) {
      const timer = setTimeout(() => {
        setSaveSuccessMsg(null);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [saveSuccessMsg]);

  // Get categories configured per tab
  const categoriesMap = {
    IT: ["Computer", "Laptop", "Printer", "Scanner", "Photo state", "others"],
    Furniture: ["chair", "table", "sofa set", "tea table", "rack", "almarah", "visitor chair", "other"],
    Misc: ["Generator", "camera", "water dispenser", "LED", "Fridge", "others"]
  };
  const activeCategories = categoriesMap[currentTab];

  const getDynamicPlaceholders = () => {
    const cat = (assetCategory || "").toLowerCase();

    // Default values:
    let assetNamePlaceholder = "e.g. Asset name or brand";
    let assetSerialPlaceholder = "e.g. S/N CNB123456";
    let assetModelPlaceholder = "e.g. Specs / Model details";

    if (cat === "laptop" || cat === "computer" || (!cat && currentTab === "IT")) {
      assetNamePlaceholder = "e.g. HP ProBook, Dell Latitude, Lenovo ThinkPad";
      assetSerialPlaceholder = "e.g. S/N CNB123456";
      assetModelPlaceholder = "e.g. Core i7, 16GB RAM, 512GB SSD";
    } else if (cat === "printer") {
      assetNamePlaceholder = "e.g. HP LaserJet, Canon Pixma, Epson L3110";
      assetSerialPlaceholder = "e.g. S/N PRNT123456";
      assetModelPlaceholder = "e.g. Duplex Printing, 40ppm, USB/Wifi";
    } else if (cat === "scanner") {
      assetNamePlaceholder = "e.g. Fujitsu Image Scanner, HP ScanJet";
      assetSerialPlaceholder = "e.g. S/N SCN789101";
      assetModelPlaceholder = "e.g. ADF, 600 dpi, Duplex Scanner";
    } else if (cat === "photo state") {
      assetNamePlaceholder = "e.g. Toshiba e-Studio, Ricoh Aficio, Canon imageRUNNER";
      assetSerialPlaceholder = "e.g. S/N COP987654";
      assetModelPlaceholder = "e.g. Heavy Duty, A3/A4 Copy, Network Printing";
    } else if (cat === "chair" || cat === "visitor chair") {
      assetNamePlaceholder = "e.g. Executive Revolving Chair, Steel Office Chair";
      assetSerialPlaceholder = "e.g. Stock Register P.No ECP-CH-023";
      assetModelPlaceholder = "e.g. Leatherette Cushion, High Back with Armrests";
    } else if (cat === "table" || cat === "tea table" || (!cat && currentTab === "Furniture")) {
      assetNamePlaceholder = "e.g. Wooden Executive Desk, Office Side Table";
      assetSerialPlaceholder = "e.g. Stock Register P.No ECP-TB-105";
      assetModelPlaceholder = "e.g. 5x3 Feet, 3 Drawers, Oak Wood Finish";
    } else if (cat === "sofa set") {
      assetNamePlaceholder = "e.g. 3-Seater Leather Sofa, Standard Office Sofa";
      assetSerialPlaceholder = "e.g. Stock Register P.No ECP-SF-045";
      assetModelPlaceholder = "e.g. Premium Velvet, Foam Cushioning";
    } else if (cat === "rack") {
      assetNamePlaceholder = "e.g. Wooden Book Rack, Metal File Shelving Rack";
      assetSerialPlaceholder = "e.g. Stock Register P.No ECP-RC-012";
      assetModelPlaceholder = "e.g. 5-Tier, Heavy Duty Steel, Adjustable Shelves";
    } else if (cat === "almarah") {
      assetNamePlaceholder = "e.g. Steel Almarah, Wooden File Cabinet";
      assetSerialPlaceholder = "e.g. Stock Register P.No ECP-AL-089";
      assetModelPlaceholder = "e.g. 4-Shelf Glass Door, Security Lock";
    } else if (cat === "generator" || (!cat && currentTab === "Misc")) {
      assetNamePlaceholder = "e.g. Honda Generator, Perkins Diesel Generator";
      assetSerialPlaceholder = "e.g. S/N GEN654321";
      assetModelPlaceholder = "e.g. 5kVA, Key Start, Petrol/LPG Dual Fuel";
    } else if (cat === "camera") {
      assetNamePlaceholder = "e.g. Sony Alpha DSLR, Hikvision Dome CCTV";
      assetSerialPlaceholder = "e.g. S/N CAM456123";
      assetModelPlaceholder = "e.g. 24.2 MP, 4K Video / 5MP Night Vision IP Camera";
    } else if (cat === "water dispenser") {
      assetNamePlaceholder = "e.g. Homage Water Dispenser, Orient Water Dispenser";
      assetSerialPlaceholder = "e.g. Stock Register P.No ECP-WD-076";
      assetModelPlaceholder = "e.g. 3-Tap (Hot, Cold, Normal), Cabinet Fridge Space";
    } else if (cat === "led") {
      assetNamePlaceholder = "e.g. Samsung 55\" Smart LED, TCL Smart TV";
      assetSerialPlaceholder = "e.g. S/N LED112233";
      assetModelPlaceholder = "e.g. 4K UHD, HDR10+, 3x HDMI Ports";
    } else if (cat === "fridge") {
      assetNamePlaceholder = "e.g. Dawlance Refrigerator, Haier Inverter Fridge";
      assetSerialPlaceholder = "e.g. S/N FRG556677";
      assetModelPlaceholder = "e.g. 15 cu ft, Double Door, Direct Cool";
    }

    return {
      name: assetNamePlaceholder,
      serial: assetSerialPlaceholder,
      model: assetModelPlaceholder
    };
  };

  // Reset category whenever tab switches
  useEffect(() => {
    if (!editingItemId) {
      clearForm();
    }
  }, [currentTab]);

  const clearForm = () => {
    setEditingItemId(null);
    setAssetName("");
    setAssetSerial("");
    setAssetModel("");
    setAssetCategory("");
    setAssetReceived("");
    setAssetDate("");
    setWorkingStatus("");
    setWorkingSubStatus("");
    setIssueTo("");
    setDesignation("");
    setIssuedDate("");
    setNonWorkingSubStatus("");
    setRemarks("");
    setGifterName("");
    setGifterDesignation("");
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!assetName.trim() || !assetCategory || !workingStatus) {
      alert("Validation Fault: Primary parameters values (Name, Category, Status) cannot be left blank.");
      return;
    }

    let finalRemarks = remarks.trim() || "";
    if (assetReceived === "Gifted") {
      finalRemarks = `Donor: ${gifterName.trim()}, Designation: ${gifterDesignation.trim()}` + (remarks.trim() ? ` | ${remarks.trim()}` : "");
    }

    const payload: Omit<InventoryItem, 'timestampId'> & { timestampId?: number } = {
      timestampId: editingItemId || Date.now(),
      nodeLocation: currentNodeLocation,
      tabContext: currentTab,
      name: assetName.trim(),
      serial: assetSerial.trim() || null,
      model: assetModel.trim() || null,
      category: assetCategory,
      receivedFrom: assetReceived || null,
      date: assetDate || null,
      workingStatus: workingStatus as "Working" | "Non-Working",
      workingSubStatus: workingStatus === "Working" ? (workingSubStatus as "Issued" | "In-stock" || null) : null,
      issueTo: (workingStatus === "Working" && workingSubStatus === "Issued") ? issueTo.trim() || null : null,
      designation: (workingStatus === "Working" && workingSubStatus === "Issued") ? designation.trim() || null : null,
      issuedDate: (workingStatus === "Working" && workingSubStatus === "Issued") ? issuedDate || null : null,
      nonWorkingSubStatus: workingStatus === "Non-Working" ? (nonWorkingSubStatus as "Needs to repair" | "Ready for condemnation" || null) : null,
      remarks: finalRemarks || null
    };

    try {
      await onItemCommit(payload);
      clearForm();
      setSaveSuccessMsg("The record has been submitted");
    } catch (err: any) {
      alert(err.message || "Failed to commit record.");
    }
  };

  const handleEditInitiate = (item: InventoryItem) => {
    if (!isWriteAllowed) return;
    
    // Switch tabs first if category is of a different tab context
    if (item.tabContext && item.tabContext !== currentTab && onTabChange) {
      onTabChange(item.tabContext as "IT" | "Furniture" | "Misc");
    }

    setEditingItemId(item.timestampId);
    setAssetName(item.name || "");
    setAssetSerial(item.serial || "");
    setAssetModel(item.model || "");
    setAssetCategory(item.category || "");
    setAssetReceived(item.receivedFrom || "");
    setAssetDate(item.date || "");
    setWorkingStatus(item.workingStatus || "");
    setWorkingSubStatus(item.workingSubStatus || "");
    setIssueTo(item.issueTo || "");
    setDesignation(item.designation || "");
    setIssuedDate(item.issuedDate || "");
    setNonWorkingSubStatus(item.nonWorkingSubStatus || "");

    if (item.receivedFrom === "Gifted" && item.remarks) {
      const donorMatch = item.remarks.match(/Donor:\s*([^,|]+)/);
      const desigMatch = item.remarks.match(/Designation:\s*([^|]+)/);
      const parts = item.remarks.split(/\s*\|\s*/);
      const otherRemarks = parts.length > 1 ? parts.slice(1).join(" | ") : "";
      
      setGifterName(donorMatch ? donorMatch[1].trim() : "");
      setGifterDesignation(desigMatch ? desigMatch[1].trim() : "");
      setRemarks(otherRemarks.trim());
    } else {
      setGifterName("");
      setGifterDesignation("");
      setRemarks(item.remarks || "");
    }

    // Scroll smoothly up to input form
    document.getElementById("registryInputsFormBlock")?.scrollIntoView({ behavior: 'smooth' });
  };

  // Export scope data to Excel matching database column schemas in user-friendly format
  const handleExportToExcel = () => {
    if (scopeData.length === 0) {
      alert("Export buffer contains empty records.");
      return;
    }

    const formattedData = scopeData.map((item, idx) => ({
      "S.No": idx + 1,
      "Asset Name": item.name,
      "Serial No": item.serial || "",
      "Model": item.model || "",
      "Category": item.category || "",
      "Received From": item.receivedFrom || "",
      "Date": item.date || "",
      "Working Status": item.workingStatus,
      "Working Type": item.workingSubStatus || "",
      "Issue To": item.issueTo || "",
      "Designation": item.designation || "",
      "Issued Date": item.issuedDate || "",
      "Condition Reason": item.nonWorkingSubStatus || "",
      "Remarks": item.remarks || ""
    }));

    const workbook = XLSX.utils.book_new();
    const worksheet = XLSX.utils.json_to_sheet(formattedData);
    XLSX.utils.book_append_sheet(workbook, worksheet, "Inventory Ledger");
    const safeNodeName = currentNodeLocation.replace(/\s+/g, '_');
    XLSX.writeFile(workbook, `Inventory_${safeNodeName}_${currentTab}.xlsx`);
  };

  // Import from Excel Sheet matching columns and syncing to Supabase in a single transaction
  const handleImportExcel = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const binary = e.target?.result;
        const workbook = XLSX.read(binary, { type: 'binary', cellDates: true });
        const sheetName = workbook.SheetNames[0];
        const rawRows = XLSX.utils.sheet_to_json<any>(workbook.Sheets[sheetName]);

        const itemsToInsert: InventoryItem[] = [];
        let addedCount = 0;

        for (let idx = 0; idx < rawRows.length; idx++) {
          const row = rawRows[idx];
          const nameValue = row["Asset Name"] || row["name"] || row["Name"] || "";
          if (nameValue) {
            const rawDate = row["Date"] || row["date"] || row["Date Logged"] || null;
            let parsedDate = null;
            try {
              parsedDate = rawDate ? new Date(rawDate).toISOString().split('T')[0] : null;
            } catch (err) {
              console.warn("Date parsing error for:", rawDate);
            }

            const rawIssuedDate = row["Issued Date"] || row["issuedDate"] || null;
            let parsedIssuedDate = null;
            try {
              parsedIssuedDate = rawIssuedDate ? new Date(rawIssuedDate).toISOString().split('T')[0] : null;
            } catch (err) {
              console.warn("Issued Date parsing error for:", rawIssuedDate);
            }

            const rawStatus = row["Working Status"] || row["workingStatus"] || "Working";
            const normWorkingStatus = String(rawStatus).trim().toLowerCase().includes("non") ? "Non-Working" : "Working";

            const rawWorkingSub = row["Working Type"] || row["workingSubStatus"] || row["Allocation Type"] || null;
            let normWorkingSubStatus: "Issued" | "In-stock" | null = null;
            if (rawWorkingSub && normWorkingStatus === "Working") {
              const str = String(rawWorkingSub).trim().toLowerCase();
              if (str.includes("issued") || str.includes("assign")) {
                normWorkingSubStatus = "Issued";
              } else if (str.includes("stock") || str.includes("in")) {
                normWorkingSubStatus = "In-stock";
              }
            }

            const rawNonWorkingSub = row["Condition Reason"] || row["nonWorkingSubStatus"] || null;
            let normNonWorkingSubStatus: "Needs to repair" | "Ready for condemnation" | null = null;
            if (rawNonWorkingSub && normWorkingStatus === "Non-Working") {
              const str = String(rawNonWorkingSub).trim().toLowerCase();
              if (str.includes("repair") || str.includes("fix")) {
                normNonWorkingSubStatus = "Needs to repair";
              } else if (str.includes("condemn") || str.includes("ready")) {
                normNonWorkingSubStatus = "Ready for condemnation";
              }
            }

            const payload: InventoryItem = {
              timestampId: Date.now() + idx,
              nodeLocation: currentNodeLocation,
              tabContext: currentTab,
              name: String(nameValue).trim(),
              serial: row["Serial No"] || row["serial"] || row["Serial/Tag Number"] || null,
              model: row["Model"] || row["model"] || row["Model Specifications"] || null,
              category: row["Category"] || row["category"] || row["Asset Subtype"] || activeCategories[0] || "others",
              receivedFrom: row["Received From"] || row["receivedFrom"] || null,
              date: parsedDate,
              workingStatus: normWorkingStatus,
              workingSubStatus: normWorkingSubStatus,
              issueTo: (normWorkingStatus === "Working" && normWorkingSubStatus === "Issued") ? (row["Issue To"] || row["issueTo"] || null) : null,
              designation: (normWorkingStatus === "Working" && normWorkingSubStatus === "Issued") ? (row["Designation"] || row["designation"] || null) : null,
              issuedDate: (normWorkingStatus === "Working" && normWorkingSubStatus === "Issued") ? parsedIssuedDate : null,
              nonWorkingSubStatus: normNonWorkingSubStatus,
              remarks: row["Remarks"] || row["remarks"] || null
            };

            itemsToInsert.push(payload);
            addedCount++;
          }
        }

        if (itemsToInsert.length > 0) {
          if (onItemsBulkCommit) {
            await onItemsBulkCommit(itemsToInsert);
          } else {
            for (const item of itemsToInsert) {
              await onItemCommit(item);
            }
          }
        }

        alert(`Successfully imported ${addedCount} rows.`);
        event.target.value = ""; // Clear file selector input
      } catch (err) {
        console.error(err);
        alert("Excel Parsing Failure. Please check columns formatting.");
      }
    };
    reader.readAsBinaryString(file);
  };

  const handlePrint = () => {
    setShowPrintPreviewModal(true);
    setTimeout(() => {
      triggerPrintDocument("printableLedgerDocumentContent");
    }, 150);
  };

  const handleDownloadOfflineHTML = async () => {
    setIsCompiling(true);
    setIsCookieBlocked(false);
    try {
      let htmlText = "";
      
      // 1. Primary Source: Compile the latest app on-the-fly and fetch the HTML template
      try {
        const res = await fetch(`/api/compile-single-html?t=${Date.now()}`, { cache: "no-store" });
        if (res.ok) {
          const txt = await res.text();
          if (txt && txt.toLowerCase().includes("doctype html") && !txt.includes("blocking a required security cookie") && !txt.includes("Safari") && txt.includes("id=\"root\"")) {
            htmlText = txt;
          } else {
            console.warn("Fetched HTML is an auth proxy or cookie-block page. Using robust local fallback.");
            setIsCookieBlocked(true);
          }
        } else {
          setIsCookieBlocked(true);
        }
      } catch (e) {
        console.error("Server compilation fetch failed, falling back to local clone:", e);
        setIsCookieBlocked(true);
      }

      // 2. Fallback: Use active page DOM if fetch failed
      if (!htmlText) {
        const docClone = document.documentElement.cloneNode(true) as HTMLElement;
        const oldDataEl = docClone.querySelector("#preseed-inventory-data");
        if (oldDataEl) oldDataEl.remove();
        const oldStateEl = docClone.querySelector("#preseed-database-state");
        if (oldStateEl) oldStateEl.remove();
        
        // CLEAR the active React mounting container to ensure a clean, un-hydrated template!
        const rootEl = docClone.querySelector("#root");
        if (rootEl) {
          rootEl.innerHTML = "";
        }
        
        htmlText = "<!DOCTYPE html>\n" + docClone.outerHTML;
      }

      // Inject the latest synchronized dataset and timestamp into the downloaded HTML
      const serializedData = JSON.stringify(allLocationData);
      let modifiedHtml = htmlText;

      // Also inject a head-script for preseeding modern compiled React single-file offline localStorage
      const dataScriptId = "preseed-inventory-data";
      const preseedScript = `
<` + `script type="application/json" id="${dataScriptId}">
${serializedData.replace(/<\/script>/g, '<\\/script>')}
</` + `script>
<` + `script id="preseed-database-state">
  try {
    const preseededTimestamp = ${Date.now()};
    window.preseededTimestamp = preseededTimestamp;
    const cachedTime = localStorage.getItem("inventory_db_timestamp") || 0;
    if (preseededTimestamp > Number(cachedTime)) {
      const dataEl = document.getElementById("${dataScriptId}");
      if (dataEl) {
        const jsonStr = dataEl.textContent || "";
        localStorage.setItem("inventory_db", jsonStr);
        localStorage.setItem("inventory_db_timestamp", preseededTimestamp.toString());
        
        // Also seed offline_db if it uses index_single.html offline variables
        localStorage.setItem("inventory_db_offline", jsonStr);
        localStorage.setItem("inventory_db_offline_timestamp", preseededTimestamp.toString());
      }
    }
  } catch (e) {
    console.error("Offline preseed error:", e);
  }
</` + `script>
`;
      
      if (modifiedHtml.includes("<head>")) {
        modifiedHtml = modifiedHtml.replace("<head>", `<head>${preseedScript}`);
      } else if (modifiedHtml.includes("<HEAD>")) {
        modifiedHtml = modifiedHtml.replace("<HEAD>", `<HEAD>${preseedScript}`);
      } else {
        modifiedHtml = preseedScript + modifiedHtml;
      }

      // Open download wizard modal with the generated HTML
      setDownloadModalData({ isOpen: true, html: modifiedHtml });
      setCopiedHtml(false);

    } catch (err: any) {
      console.error("Offline HTML download process error:", err);
      alert("Offline app template could not be loaded. Please try again.");
    } finally {
      setIsCompiling(false);
    }
  };

  const getCategoryIcon = (category: string) => {
    const cat = category.toLowerCase();
    if (cat.includes("computer") || cat.includes("laptop")) return <Laptop className="w-4.5 h-4.5 text-cyan-400" />;
    if (cat.includes("printer")) return <Printer className="w-4.5 h-4.5 text-blue-400" />;
    if (cat.includes("scanner")) return <Search className="w-4.5 h-4.5 text-teal-400" />;
    if (cat.includes("photo") || cat.includes("state")) return <FileSpreadsheet className="w-4.5 h-4.5 text-indigo-400" />;
    if (cat.includes("chair")) return <Sofa className="w-4.5 h-4.5 text-orange-400" />;
    if (cat.includes("table")) return <Package className="w-4.5 h-4.5 text-amber-400" />;
    if (cat.includes("sofa")) return <Sofa className="w-4.5 h-4.5 text-pink-400" />;
    if (cat.includes("rack") || cat.includes("almarah")) return <Layers className="w-4.5 h-4.5 text-purple-400" />;
    if (cat.includes("generator")) return <Cpu className="w-4.5 h-4.5 text-rose-400" />;
    if (cat.includes("camera")) return <Camera className="w-4.5 h-4.5 text-emerald-400" />;
    if (cat.includes("dispenser") || cat.includes("water")) return <Droplet className="w-4.5 h-4.5 text-sky-400" />;
    if (cat.includes("led")) return <Tv className="w-4.5 h-4.5 text-yellow-400" />;
    if (cat.includes("fridge") || cat.includes("refrigerator")) return <Cpu className="w-4.5 h-4.5 text-blue-300" />;
    return <Package className="w-4.5 h-4.5 text-slate-400" />;
  };

  return (
    <div className="space-y-6">
      {/* EXQUISITE HEADER AND SUBTITLE */}
      <div className="bg-slate-900/35 backdrop-blur-xl border border-slate-800/60 p-5 rounded-2xl flex flex-col justify-start gap-1.5 shadow-xl print:hidden animate-fadeIn">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 bg-blue-500 rounded-full animate-ping"></span>
          <h2 className="text-sm font-black uppercase tracking-wider text-white">
            Office Ledger &bull; {currentNodeLocation}
          </h2>
        </div>
      </div>

      {/* SUPERVISOR VIEW BANNER */}
      {!isWriteAllowed && (
        <div className="bg-blue-500/10 border border-blue-500/25 p-3 rounded-xl flex items-center gap-2.5 animate-fadeIn text-xs text-blue-400 font-bold">
          <Shield className="w-4 h-4 text-blue-400 shrink-0" />
          <span>Supervisor view</span>
        </div>
      )}

      {/* CATEGORIES WISE AMOUNT IN OFFICE LEDGER */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3 print:hidden animate-fadeIn">
        {activeCategories.map(cat => {
          const count = scopeData.filter(item => item.category.toLowerCase() === cat.toLowerCase()).length;
          return (
            <div key={cat} className="bg-slate-900/25 backdrop-blur-md border border-slate-800/60 rounded-xl p-3 flex items-center justify-between gap-3 shadow-md hover:border-slate-700/50 transition-all duration-250">
              <div className="space-y-1 min-w-0">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-wider truncate capitalize">
                  {cat}
                </p>
                <p className="text-xl font-black text-white font-mono leading-none">
                  {count}
                </p>
              </div>
              <div className="p-2 bg-slate-950/45 rounded-lg border border-slate-800/60 shrink-0">
                {getCategoryIcon(cat)}
              </div>
            </div>
          );
        })}
      </div>

      {/* INPUTS FORM PANEL BLOCK */}
      {isWriteAllowed && (
        <form 
          id="registryInputsFormBlock"
          onSubmit={handleSave} 
          className="bg-slate-900/30 backdrop-blur-2xl border border-slate-800/70 rounded-2xl p-6 shadow-xl space-y-4 print:hidden animate-fadeIn"
        >
          <div className="flex items-center justify-between border-b border-slate-800/70 pb-3">
            <h3 className="text-xs font-black text-blue-400 uppercase tracking-widest flex items-center gap-1.5">
              <span className="p-1 bg-blue-500/10 text-blue-400 rounded-md">
                <Plus className="w-4 h-4" />
              </span>
              {editingItemId ? `✏️ Modify Asset Entry (${editingItemId})` : `📝 New Asset Registration Entry`}
            </h3>
            {editingItemId && (
              <button
                type="button"
                onClick={clearForm}
                className="text-xs text-rose-400 hover:text-rose-350 underline font-semibold transition"
              >
                Reset Form
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">Asset Model Name</label>
              <input
                type="text"
                placeholder={getDynamicPlaceholders().name}
                value={assetName}
                onChange={(e) => setAssetName(e.target.value)}
                className="w-full bg-slate-950/45 border border-slate-800/60 focus:border-blue-500/80 focus:outline-none rounded-lg p-2.5 text-xs text-white"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">Serial / Stock Register P.No</label>
              <input
                type="text"
                placeholder={getDynamicPlaceholders().serial}
                value={assetSerial}
                onChange={(e) => setAssetSerial(e.target.value)}
                className="w-full bg-slate-950/45 border border-slate-800/60 focus:border-blue-500/80 focus:outline-none rounded-lg p-2.5 text-xs text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">Model / Specification</label>
              <input
                type="text"
                placeholder={getDynamicPlaceholders().model}
                value={assetModel}
                onChange={(e) => setAssetModel(e.target.value)}
                className="w-full bg-slate-950/45 border border-slate-800/60 focus:border-blue-500/80 focus:outline-none rounded-lg p-2.5 text-xs text-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">Asset Category</label>
              <select
                value={assetCategory}
                onChange={(e) => setAssetCategory(e.target.value)}
                className="w-full bg-slate-950/45 border border-slate-800/60 focus:border-blue-500/80 focus:outline-none rounded-lg p-2.5 text-xs text-white"
                required
              >
                <option value="" className="bg-slate-950 text-slate-200">-- Select Category --</option>
                {activeCategories.map(cat => (
                  <option key={cat} value={cat} className="capitalize bg-slate-950 text-slate-200">{cat}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">Received From</label>
              <select
                value={assetReceived}
                onChange={(e) => {
                  setAssetReceived(e.target.value);
                  if (e.target.value !== "Gifted") {
                    setGifterName("");
                    setGifterDesignation("");
                  }
                }}
                className="w-full bg-slate-950/45 border border-slate-800/60 focus:border-blue-500/80 focus:outline-none rounded-lg p-2.5 text-xs text-white font-medium"
              >
                <option value="" className="bg-slate-950 text-slate-400">-- Choose Option --</option>
                <option value="ECP" className="bg-slate-950 text-slate-200">ECP</option>
                <option value="PEC" className="bg-slate-950 text-slate-200">PEC</option>
                <option value="REC" className="bg-slate-950 text-slate-200">REC</option>
                <option value="DEC" className="bg-slate-950 text-slate-200">DEC</option>
                <option value="Gifted" className="bg-slate-950 text-slate-200">Gifted</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">Date of Logging</label>
              <input
                type="date"
                value={assetDate}
                onChange={(e) => setAssetDate(e.target.value)}
                className="w-full bg-slate-950/45 border border-slate-800/60 focus:border-blue-500/80 focus:outline-none rounded-lg p-2.5 text-xs text-white"
              />
            </div>
          </div>

          {/* Conditional Gifted Gifter/Donor Fields */}
          {assetReceived === "Gifted" && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-emerald-500/5 border border-emerald-500/10 p-4 rounded-xl animate-fadeIn">
              <div>
                <label className="block text-xs font-semibold text-emerald-400 mb-1">Name of Gifter / Donor</label>
                <input
                  type="text"
                  placeholder="e.g. Muhammad Ali"
                  value={gifterName}
                  onChange={(e) => setGifterName(e.target.value)}
                  className="w-full bg-slate-950/45 border border-emerald-500/20 focus:border-emerald-500 focus:outline-none rounded-lg p-2.5 text-xs text-white"
                  required={assetReceived === "Gifted"}
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-emerald-400 mb-1">Designation of Gifter / Donor</label>
                <input
                  type="text"
                  placeholder="e.g. CRO Office Peshawar"
                  value={gifterDesignation}
                  onChange={(e) => setGifterDesignation(e.target.value)}
                  className="w-full bg-slate-950/45 border border-emerald-500/20 focus:border-emerald-500 focus:outline-none rounded-lg p-2.5 text-xs text-white"
                  required={assetReceived === "Gifted"}
                />
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 border-t border-slate-800/40 pt-2">
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">Working Condition Status</label>
              <select
                value={workingStatus}
                onChange={(e) => {
                  setWorkingStatus(e.target.value);
                  setWorkingSubStatus("");
                  setNonWorkingSubStatus("");
                }}
                className="w-full bg-slate-950/45 border border-slate-800/60 focus:border-blue-500/80 focus:outline-none rounded-lg p-2.5 text-xs text-white font-bold"
                required
              >
                <option value="" className="bg-slate-950 text-slate-200">-- Choose Status --</option>
                <option value="Working" className="text-emerald-450 bg-slate-950 font-bold">Working</option>
                <option value="Non-Working" className="text-rose-455 bg-slate-950 font-bold">Non-Working</option>
              </select>
            </div>

            {workingStatus === "Working" && (
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1 text-emerald-400">Working Allocation Type</label>
                <select
                  value={workingSubStatus}
                  onChange={(e) => {
                    setWorkingSubStatus(e.target.value);
                    if (e.target.value !== "Issued") {
                      setIssueTo("");
                      setDesignation("");
                      setIssuedDate("");
                    }
                  }}
                  className="w-full bg-slate-950/45 border border-emerald-500/30 focus:border-blue-500/80 focus:outline-none rounded-lg p-2.5 text-xs text-white"
                  required
                >
                  <option value="" className="bg-slate-950 text-slate-200">-- Choose Type --</option>
                  <option value="Issued" className="bg-slate-950 text-slate-200">Issued (Assigned)</option>
                  <option value="In-stock" className="bg-slate-950 text-slate-200">In-Stock</option>
                </select>
              </div>
            )}

            {workingStatus === "Non-Working" && (
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1 text-rose-400">Condition Reason</label>
                <select
                  value={nonWorkingSubStatus}
                  onChange={(e) => setNonWorkingSubStatus(e.target.value)}
                  className="w-full bg-slate-950/45 border border-rose-500/30 focus:border-rose-500/80 focus:outline-none rounded-lg p-2.5 text-xs text-white"
                  required
                >
                  <option value="" className="bg-slate-950 text-slate-200">-- Condition Reason --</option>
                  <option value="Needs to repair" className="bg-slate-950 text-slate-200">Needs to repair</option>
                  <option value="Ready for condemnation" className="bg-slate-950 text-slate-200">Ready for condemnation</option>
                </select>
              </div>
            )}
          </div>

          {/* Inline Assignment Row if working status is working/issued */}
          {workingStatus === "Working" && workingSubStatus === "Issued" && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-emerald-500/5 p-4 rounded-lg border border-emerald-500/15 animate-fadeIn">
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1">Assigned Name</label>
                <input
                  type="text"
                  placeholder="Officer / Official Username"
                  value={issueTo}
                  onChange={(e) => setIssueTo(e.target.value)}
                  className="w-full bg-slate-950/45 border border-slate-800/60 focus:border-emerald-550 focus:outline-none rounded-lg p-2.5 text-xs text-white"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1">Designation</label>
                <input
                  type="text"
                  placeholder="Officer/Official name"
                  value={designation}
                  onChange={(e) => setDesignation(e.target.value)}
                  className="w-full bg-slate-950/45 border border-slate-800/60 focus:border-emerald-550 focus:outline-none rounded-lg p-2.5 text-xs text-white"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1">Assignment Date</label>
                <input
                  type="date"
                  value={issuedDate}
                  onChange={(e) => setIssuedDate(e.target.value)}
                  className="w-full bg-slate-950/45 border border-slate-800/60 focus:border-emerald-550 focus:outline-none rounded-lg p-2.5 text-xs text-white"
                  required
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">Observations / Remarks</label>
            <input
              type="text"
              placeholder="Any critical observations or remarks notes (Optional)"
              value={remarks}
              onChange={(e) => setRemarks(e.target.value)}
              className="w-full bg-slate-950/45 border border-slate-800/60 focus:border-blue-500/80 focus:outline-none rounded-lg p-2.5 text-xs text-white"
            />
          </div>

          <div className="flex flex-col md:flex-row justify-between items-center gap-4 pt-4 border-t border-slate-800/60 mt-4 print:hidden">
            {/* Left side actions: Print Report, Export Excel, Download, Import Excel, and Clear All / Delete All */}
            <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto justify-start">
              <button
                type="button"
                onClick={handlePrint}
                className="bg-sky-600/90 hover:bg-sky-500 active:bg-sky-700 text-white text-[11px] font-bold px-3.5 py-2 rounded-lg flex items-center gap-1.5 cursor-pointer transition-all active:scale-95"
                title="Print combined metrics summary matching your filters"
              >
                <Printer className="w-3.5 h-3.5" /> Print
              </button>
              
              <button
                type="button"
                onClick={handleExportToExcel}
                className="bg-blue-600/95 hover:bg-blue-500 active:bg-blue-700 text-white text-[11px] font-bold px-3.5 py-2 rounded-lg flex items-center gap-1.5 cursor-pointer transition-all active:scale-95"
              >
                <FileSpreadsheet className="w-3.5 h-3.5" /> Export Excel
              </button>

              {isSuperAdmin && (
                <button
                  type="button"
                  onClick={handleDownloadOfflineHTML}
                  className="bg-purple-600 hover:bg-purple-500 active:bg-purple-700 text-white text-[11px] font-bold px-3.5 py-2 rounded-lg flex items-center gap-1.5 cursor-pointer transition-all active:scale-95"
                  title="Download Standalone Offline HTML or Project ZIP"
                >
                  <Download className={`w-3.5 h-3.5 ${isCompiling ? "animate-spin" : ""}`} /> 
                  {isCompiling ? "Compiling..." : "Export Offline App"}
                </button>
              )}

              {isWriteAllowed && (
                <>
                  <label className="bg-slate-800 hover:bg-slate-700 active:bg-slate-850 border border-slate-700/60 text-slate-100 text-[11px] font-bold px-3.5 py-2 rounded-lg flex items-center gap-1.5 cursor-pointer transition-all active:scale-95">
                    <FileSpreadsheet className="w-3.5 h-3.5 text-slate-300" />
                    Import Excel
                    <input
                      type="file"
                      accept=".xlsx, .xls"
                      onChange={handleImportExcel}
                      className="hidden"
                    />
                  </label>

                  {isSuperAdmin && (
                    <button
                      type="button"
                      onClick={() => {
                        if (confirmClearAll) {
                          onItemDeleteAll();
                          setConfirmClearAll(false);
                        } else {
                          setConfirmClearAll(true);
                        }
                      }}
                      className={`transition-all cursor-pointer flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-[11px] font-bold border ${
                        confirmClearAll
                          ? "bg-rose-600 border-transparent text-white animate-pulse"
                          : "bg-rose-600/20 hover:bg-rose-600 border-rose-500/20 text-rose-400 hover:text-white"
                      }`}
                      title={confirmClearAll ? "Click again to confirm clearing all active assets" : `Clear All ${currentTab} Assets`}
                    >
                      <Trash2 className="w-3.5 h-3.5" /> 
                      {confirmClearAll ? "Confirm Clear All?" : `Clear All ${currentTab} Assets`}
                    </button>
                  )}
                </>
              )}
            </div>

            {/* Right side: Save / Cancel / Apply updates controls */}
            <div className="flex items-center gap-2 w-full md:w-auto justify-end border-t md:border-t-0 pt-3 md:pt-0 border-slate-850">
              {editingItemId && (
                <button
                  type="button"
                  onClick={clearForm}
                  className="bg-slate-800 hover:bg-slate-700 border border-slate-700/60 text-slate-350 font-bold px-4 py-2 text-xs rounded-lg cursor-pointer transition-all active:scale-95"
                >
                  Cancel
                </button>
              )}
              <button
                type="submit"
                className="bg-green-600 hover:bg-green-500 text-white font-bold px-6 py-2.5 text-xs rounded-lg cursor-pointer transition-all flex items-center gap-1.5 shadow-md hover:shadow-green-500/10 active:scale-95"
              >
                {editingItemId ? (
                  <>💾 Apply Updates</>
                ) : (
                  <><Plus className="w-4 h-4" /> Save Record</>
                )}
              </button>
            </div>
          </div>
        </form>
      )}

      {/* INVENTORY REGISTER TABLE (Category-specific register table) */}
      <div className="space-y-4 pt-2">
        <div className="flex justify-between items-center bg-slate-950/30 backdrop-blur-md p-4 rounded-xl border border-slate-800/60 shadow-lg">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></span>
            <h3 className="text-xs font-black text-blue-400 uppercase tracking-widest">
              Inventory Register — {currentTab === "IT" ? "IT Equipment" : currentTab === "Furniture" ? "Furniture Assets" : "Miscellaneous"}
            </h3>
          </div>
          <span className="text-xs bg-blue-950/40 text-blue-300 font-extrabold px-3 py-1 rounded-full border border-blue-500/20">
            {scopeData.length} records in {currentTab}
          </span>
        </div>

        <div className="overflow-x-auto rounded-xl border border-slate-800/60 bg-slate-950/20 backdrop-blur-sm shadow-xl">
          <table className="w-full text-left text-xs text-slate-300 divide-y divide-slate-800">
            <thead className="bg-slate-900/50 backdrop-blur-sm text-slate-300 uppercase font-black text-[10px] tracking-wider">
              <tr>
                <th className="px-4 py-3 border-b border-slate-800 text-blue-400">Asset Name</th>
                <th className="px-4 py-3 border-b border-slate-800">Serial / Stock Register P.No</th>
                <th className="px-4 py-3 border-b border-slate-800">Model</th>
                <th className="px-4 py-3 border-b border-slate-800">Category</th>
                <th className="px-4 py-3 border-b border-slate-800">Received From</th>
                <th className="px-4 py-3 border-b border-slate-800">Date Logged</th>
                <th className="px-4 py-3 border-b border-slate-800">Status Condition</th>
                <th className="px-4 py-3 border-b border-slate-800">Assigned To</th>
                <th className="px-4 py-3 border-b border-slate-800">Designation</th>
                <th className="px-4 py-3 border-b border-slate-800">Assignment Date</th>
                <th className="px-4 py-3 border-b border-slate-800">Remarks</th>
                {isWriteAllowed && (
                  <th className="px-4 py-3 border-b border-slate-800 text-center">Actions</th>
                )}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 bg-[#0f172a]/10">
              {scopeData.length === 0 ? (
                <tr>
                  <td colSpan={isWriteAllowed ? 12 : 11} className="px-4 py-8 text-center text-slate-500 font-semibold italic">
                    No active {currentTab === "IT" ? "IT Equipment" : currentTab === "Furniture" ? "Furniture Assets" : "Miscellaneous"} records registered for this location yet.
                  </td>
                </tr>
              ) : (
                scopeData.map((item) => {
                  const isWorking = item.workingStatus === "Working";
                  return (
                    <tr key={item.timestampId} className="hover:bg-slate-850/45 transition-colors duration-150">
                      <td className="px-4 py-3 font-bold text-slate-100">{item.name}</td>
                      <td className="px-4 py-3 font-mono text-slate-400 text-[11px]">{item.serial || "-"}</td>
                      <td className="px-4 py-3 text-slate-400">{item.model || "-"}</td>
                      <td className="px-4 py-3">
                        <span className="bg-slate-800/80 text-amber-400 px-2.5 py-0.5 rounded text-[10px] font-bold border border-slate-700/60">{item.category}</span>
                      </td>
                      <td className="px-4 py-3 text-slate-400">{item.receivedFrom || "-"}</td>
                      <td className="px-4 py-3 text-slate-400">{item.date || "-"}</td>
                      <td className="px-4 py-3">
                        <div className="space-y-1">
                          <span className={`inline-flex items-center gap-1 font-bold px-2 py-0.5 rounded text-[10px] border ${
                            isWorking 
                              ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/15' 
                              : 'bg-rose-500/10 text-rose-400 border-rose-500/15'
                          }`}>
                            {item.workingStatus}
                          </span>
                          {isWorking && item.workingSubStatus && (
                            <span className="block text-[9px] text-slate-500 font-bold bg-slate-950 px-1 py-0.5 rounded text-center max-w-[80px]">
                              {item.workingSubStatus}
                            </span>
                          )}
                          {!isWorking && item.nonWorkingSubStatus && (
                            <span className="block text-[9px] text-rose-400 font-bold bg-rose-500/5 px-1 py-0.5 rounded text-center border border-rose-500/10">
                              {item.nonWorkingSubStatus}
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="px-4 py-3 text-slate-300 font-medium">{item.issueTo || "-"}</td>
                      <td className="px-4 py-3 text-slate-400">{item.designation || "-"}</td>
                      <td className="px-4 py-3 text-slate-400">{item.issuedDate || "-"}</td>
                      <td className="px-4 py-3 text-slate-400 italic max-w-xs truncate" title={item.remarks || ""}>{item.remarks || "-"}</td>
                      {isWriteAllowed && (
                        <td className="px-4 py-3 text-center">
                          <div className="inline-flex gap-1">
                            <button
                              onClick={() => handleEditInitiate(item)}
                              className="bg-amber-600/20 hover:bg-amber-600 border border-amber-500/30 hover:border-transparent text-amber-400 hover:text-white p-1.5 rounded-lg transition-all cursor-pointer active:scale-95"
                              title="Edit Record"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            {isSuperAdmin && (
                              <button
                                onClick={() => {
                                  if (confirmDeleteId === item.timestampId) {
                                    onItemDelete(item.timestampId);
                                    setConfirmDeleteId(null);
                                  } else {
                                    setConfirmDeleteId(item.timestampId);
                                  }
                                }}
                                className={`transition-all cursor-pointer active:scale-95 flex items-center gap-1.5 p-1.5 rounded-lg border ${
                                  confirmDeleteId === item.timestampId
                                    ? "bg-rose-600 text-white border-transparent text-[10px] font-bold px-2 py-1"
                                    : "bg-rose-600/20 hover:bg-rose-600 border-rose-500/30 hover:border-transparent text-rose-400 hover:text-white"
                                }`}
                                title={confirmDeleteId === item.timestampId ? "Click again to confirm delete" : "Delete Record"}
                              >
                                {confirmDeleteId === item.timestampId ? (
                                  <span className="font-bold flex items-center gap-1"><Trash2 className="w-3 h-3 animate-bounce" /> Delete?</span>
                                ) : (
                                  <Trash2 className="w-3.5 h-3.5" />
                                )}
                              </button>
                            )}
                          </div>
                        </td>
                      )}
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Printable Specific Layout Stamps */}
      <div className="hidden print:hidden justify-end pt-12 pb-6">
        <div className="border-2 border-dashed border-slate-300 p-4 rounded-lg text-center w-80 bg-white text-slate-950 shadow-sm leading-normal">
          <div className="h-16 border-b border-slate-300 flex items-center justify-center text-xs text-slate-400 italic"></div>
          <div className="pt-3 font-bold text-sm tracking-wide text-slate-900 uppercase">
            {currentNodeLocation.startsWith("REC") ? "Regional" : "District"} Election Commissioner
          </div>
          <div className="text-xs text-slate-600 font-medium mt-1">
            {currentNodeLocation.replace(/REC|DEC/g, "").trim()} Division
          </div>
        </div>
      </div>

      {/* EXQUISITE SUCCESS NOTIFICATION DIALOG POPUP */}
      {saveSuccessMsg && (
        <div id="saveSuccessModal" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-sm animate-fade-in print:hidden" onClick={() => setSaveSuccessMsg(null)}>
          <div className="bg-slate-900 border border-emerald-500/30 rounded-2xl p-6 max-w-sm w-full shadow-2xl text-center space-y-4 animate-scale-up" onClick={(e) => e.stopPropagation()}>
            <div className="w-16 h-16 bg-emerald-500/10 text-emerald-400 rounded-full flex items-center justify-center mx-auto border border-emerald-500/20">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-100">Submitted Successfully</h3>
              <p className="text-sm text-slate-350 mt-2 font-medium">{saveSuccessMsg}</p>
            </div>
            <div className="text-[10px] text-slate-500 border-t border-slate-800/80 pt-2 flex items-center justify-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
              Automatically closing...
            </div>
          </div>
        </div>
      )}

      {/* MASTERFUL ECP WORLD-CLASS PRINT PREVIEW REPORT DIALOG MODAL */}
      {showPrintPreviewModal && createPortal(
        <div id="printReportModalOverlay" className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md overflow-y-auto p-4 md:p-8 flex items-start justify-center print:static print:bg-white print:p-0 print:overflow-visible">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-5xl w-full shadow-2xl overflow-hidden print:border-none print:shadow-none print:bg-white">
            
            {/* Modal Header Controls (Invisible When Printed) */}
            <div className="bg-slate-950 px-6 py-4 border-b border-slate-800 flex flex-col md:flex-row md:items-center md:justify-between gap-3 print:hidden">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                  <Printer className="w-4 h-4 text-emerald-400" /> Official Inventory Print Preview
                </h3>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Location: <span className="text-emerald-400 font-bold">{currentNodeLocation}</span>
                </p>
              </div>
              
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => triggerPrintDocument("printableLedgerDocumentContent")}
                  className="bg-sky-600 hover:bg-sky-500 active:bg-sky-700 text-white text-xs font-bold px-4 py-2 rounded-xl flex items-center gap-1.5 cursor-pointer shadow-lg shadow-sky-800/10 transition active:scale-98"
                >
                  <Printer className="w-4 h-4" /> Print Document
                </button>
                
                <button
                  type="button"
                  onClick={() => setShowPrintPreviewModal(false)}
                  className="bg-slate-800 hover:bg-slate-700 active:bg-slate-850 text-slate-300 text-xs font-semibold px-4 py-2 rounded-xl cursor-pointer transition active:scale-98"
                >
                  Close Preview
                </button>
              </div>
            </div>

            {/* Printable Sheet Viewport Frame */}
            <div id="printableLedgerDocumentContent" className="p-6 md:p-8 bg-white text-slate-950 min-h-[500px]">
              
              {/* ECP Header Identity Block */}
              <div className="border-b-2 border-slate-800 pb-4 mb-6">
                <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                  <div className="flex items-center gap-4">
                    <img 
                      src="ecp_logo.jpg" 
                      alt="ECP logo" 
                      className="w-16 h-16 object-contain rounded-full border border-slate-300 shadow-sm"
                      referrerPolicy="no-referrer"
                    />
                    <div className="text-center sm:text-left">
                      <h1 className="text-xl font-black uppercase tracking-wide text-slate-950">
                        Election Commission of Pakistan
                      </h1>
                      <p className="text-xs font-extrabold text-emerald-800 tracking-wider uppercase">
                        INVENTORY TRACKING & LEDGER AUDIT SYSTEM
                      </p>
                    </div>
                  </div>
                  
                  <div className="text-center sm:text-right">
                    <span className="text-[10px] font-black uppercase tracking-widest text-slate-500 block">
                      Report Location
                    </span>
                    <span className="text-sm font-black text-blue-700 uppercase block mt-0.5">
                      {currentNodeLocation}
                    </span>
                  </div>
                </div>
                
                <div className="flex flex-col sm:flex-row justify-between items-center mt-4 pt-2 border-t border-slate-200 text-xs text-slate-600 gap-1.5">
                  <div>
                    Report Category: <strong className="text-slate-900">{currentTab === "IT" ? "IT Equipment Database" : currentTab === "Furniture" ? "Furniture Assets" : "Miscellaneous Assets"}</strong>
                  </div>
                  <div>
                    Generated On: <strong className="text-slate-900">{new Date().toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</strong>
                  </div>
                </div>
              </div>

              {/* COMBINATION BLOCK: Live Summary Dashboard metrics layout matches report category */}
              <div className="mb-6">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  
                  <div className="bg-slate-50 border border-slate-250 p-3 rounded-lg">
                    <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Total Stock Pool</div>
                    <div className="text-xl font-extrabold text-slate-950 mt-1">
                      {scopeData.length}
                    </div>
                  </div>

                  <div className="bg-slate-50 border border-slate-250 p-3 rounded-lg">
                    <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Working (Issued)</div>
                    <div className="text-xl font-extrabold text-slate-950 mt-1 text-emerald-700">
                      {scopeData.filter(i => i.workingStatus === "Working" && i.workingSubStatus === "Issued").length}
                    </div>
                  </div>

                  <div className="bg-slate-50 border border-slate-250 p-3 rounded-lg">
                    <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Working (In-Stock)</div>
                    <div className="text-xl font-extrabold text-slate-950 mt-1 text-blue-700">
                      {scopeData.filter(i => i.workingStatus === "Working" && i.workingSubStatus === "In-stock").length}
                    </div>
                  </div>

                  <div className="bg-slate-50 border border-slate-250 p-3 rounded-lg">
                    <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wide flex justify-between items-center">
                      <span>Non-Working Conditions</span>
                      <span className="text-[8px] font-bold bg-rose-100 text-rose-800 px-1 py-0.2 rounded border border-rose-300">ALERT</span>
                    </div>
                    <div className="text-xl font-extrabold text-rose-700 mt-1">
                      {scopeData.filter(i => i.workingStatus === "Non-Working").length}
                    </div>
                    <div className="text-[8px] text-slate-600 mt-1 flex justify-between border-t border-dashed border-slate-300 pt-1">
                      <span>Repair: <strong>{scopeData.filter(i => i.workingStatus === "Non-Working" && i.nonWorkingSubStatus === "Needs to repair").length}</strong></span>
                      <span>Condemn: <strong>{scopeData.filter(i => i.workingStatus === "Non-Working" && i.nonWorkingSubStatus === "Ready for condemnation").length}</strong></span>
                    </div>
                  </div>

                </div>
              </div>

              {/* COMBINATION BLOCK: Category tally counters from Live Asset Category Stock Feed */}
              <div className="mb-6">
                <div className="flex flex-wrap gap-2 pt-1">
                  {activeCategories.map(cat => {
                    const count = scopeData.filter(i => i.category.toLowerCase() === cat.toLowerCase()).length;
                    return (
                      <div key={cat} className="bg-slate-100 border border-slate-300 flex items-center justify-between gap-3 px-3 py-1.5 rounded-lg text-xs font-semibold min-w-[120px]">
                        <span className="text-slate-800 capitalize font-medium">{cat}</span>
                        <span className="bg-white border border-slate-300 text-slate-950 font-black px-2 py-0.5 rounded text-[10px]">
                          {count}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* COMBINATION BLOCK: Combined dynamic search and output table matrix */}
              <div id="printableActiveLedgerTableArea" className="mb-6">
                <div className="text-xs font-black uppercase tracking-wider text-slate-500 mb-2 border-l-2 border-slate-600 pl-2 flex justify-between items-center print:hidden">
                  <span>Active Ledger Data Records List</span>
                  <span className="text-[9px] text-slate-600 normal-case italic font-medium">
                    Showing {scopeData.length} records matching search filter matches
                  </span>
                </div>
                
                <div className="overflow-x-auto border border-slate-300 rounded-none mt-2">
                  <table className="w-full text-left text-[9px] text-slate-900 border-collapse">
                    <thead className="bg-slate-100 border-b border-slate-300">
                      <tr>
                        <th className="px-2 py-1.5 font-bold border border-slate-300 text-slate-900">Station</th>
                        <th className="px-2 py-1.5 font-bold border border-slate-300 text-slate-900">Asset Name</th>
                        <th className="px-2 py-1.5 font-bold border border-slate-300 text-slate-900">Serial / Stock Register P.No</th>
                        <th className="px-2 py-1.5 font-bold border border-slate-300 text-slate-900">Model</th>
                        <th className="px-2 py-1.5 font-bold border border-slate-300 text-slate-900">Category</th>
                        <th className="px-2 py-1.5 font-bold border border-slate-300 text-slate-400">Date Logged</th>
                        <th className="px-2 py-1.5 font-bold border border-slate-300 text-slate-900">Condition Status</th>
                        <th className="px-2 py-1.5 font-bold border border-slate-300 text-slate-900">Issued Assignment To</th>
                        <th className="px-2 py-1.5 font-bold border border-slate-300 text-slate-900">Designation</th>
                        <th className="px-2 py-1.5 font-bold border border-slate-300 text-slate-900">Remarks</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-300">
                      {scopeData.length === 0 ? (
                        <tr>
                          <td colSpan={10} className="px-4 py-8 text-center text-slate-500 italic border border-slate-300 bg-slate-50">
                            No matching active ledger dataset records found in export queue.
                          </td>
                        </tr>
                      ) : (
                        scopeData.map(item => {
                          const isWorkingStatus = item.workingStatus === "Working";
                          return (
                            <tr key={item.timestampId} className="hover:bg-slate-50 bg-white">
                              <td className="px-2 py-1.5 font-bold border border-slate-300 text-slate-900">{item.nodeLocation}</td>
                              <td className="px-2 py-1.5 font-semibold border border-slate-300 text-slate-900">{item.name}</td>
                              <td className="px-2 py-1.5 border border-slate-300 text-slate-800 font-mono text-[8px]">{item.serial || '-'}</td>
                              <td className="px-2 py-1.5 border border-slate-300 text-slate-800">{item.model || '-'}</td>
                              <td className="px-2 py-1.5 border border-slate-300 capitalize text-slate-900">{item.category}</td>
                              <td className="px-2 py-1.5 border border-slate-300 text-slate-700">{item.date || '-'}</td>
                              <td className="px-2 py-1.5 border border-slate-300">
                                <div className="flex flex-col gap-0.5 items-start">
                                  <span className={`text-[8px] font-extrabold px-1.5 py-0.2 rounded border ${
                                    isWorkingStatus 
                                      ? 'bg-emerald-50 text-emerald-800 border-emerald-300' 
                                      : 'bg-rose-50 text-rose-800 border-rose-300'
                                  }`}>
                                    {item.workingStatus}
                                  </span>
                                  {item.workingSubStatus && (
                                    <span className="text-[7px] text-slate-700 bg-slate-100 border border-slate-200 px-1 rounded block mt-0.5">
                                      {item.workingSubStatus}
                                    </span>
                                  )}
                                  {item.nonWorkingSubStatus && (
                                    <span className="text-[7px] text-rose-900 bg-rose-50 border border-rose-200 px-1 rounded block mt-0.5 font-medium">
                                      {item.nonWorkingSubStatus}
                                    </span>
                                  )}
                                </div>
                              </td>
                              <td className="px-2 py-1.5 border border-slate-300 text-slate-900 font-semibold">{item.issueTo || '-'}</td>
                              <td className="px-2 py-1.5 border border-slate-300 text-slate-800">{item.designation || '-'}</td>
                              <td className="px-2 py-1.5 border border-slate-300 text-slate-800 italic text-[8px] whitespace-normal break-words">
                                {item.remarks || '-'}
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Verification signature section */}
              <div className="flex justify-end pt-8 mt-12 border-t border-dashed border-slate-300">
                <div className="border border-dashed border-slate-300 p-4 rounded-lg text-center w-80 bg-white text-slate-900 shadow-sm leading-normal">
                  <div className="h-14 border-b border-slate-200 flex items-center justify-center text-[10px] text-slate-400 italic"></div>
                  <div className="pt-2 font-black text-[11px] tracking-wide text-slate-900 uppercase">
                    {currentNodeLocation.startsWith("REC") ? "Regional" : "District"} Election Commissioner
                  </div>
                  <div className="text-[9px] text-slate-600 font-bold mt-0.5">
                    {currentNodeLocation.replace(/REC|DEC/g, "").trim()} Division / Region
                  </div>
                </div>
              </div>

            </div>

            {/* Modal Footer Controls */}
            <div className="bg-slate-950 px-6 py-4 border-t border-slate-800 flex items-center justify-end gap-2 print:hidden">
              <button
                type="button"
                onClick={() => setShowPrintPreviewModal(false)}
                className="bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs py-2 px-5 rounded-xl cursor-pointer transition active:scale-98"
              >
                Close Preview
              </button>
              <button
                type="button"
                onClick={() => triggerPrintDocument("printableLedgerDocumentContent")}
                className="bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs py-2 px-5 rounded-xl flex items-center gap-1.5 cursor-pointer shadow-lg transition active:scale-98"
              >
                <Printer className="w-4 h-4" /> Print Document
              </button>
            </div>

          </div>
        </div>
      , document.body)}

      {downloadModalData.isOpen && (
        <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md z-50 flex items-center justify-center p-4 print:hidden">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg shadow-2xl shadow-slate-950/70 flex flex-col overflow-hidden max-h-[90vh]">
            <div className="p-6 border-b border-slate-800 flex justify-between items-center bg-slate-900/50">
              <h3 className="text-md font-bold text-white flex items-center gap-2">
                <Download className="w-5 h-5 text-amber-500 animate-bounce" /> Offline App & Backup Exporter
              </h3>
              <button 
                onClick={() => setDownloadModalData({ isOpen: false, html: "" })}
                className="text-slate-400 hover:text-white font-bold text-sm cursor-pointer"
              >
                ✕ Close
              </button>
            </div>
            
            <div className="p-6 space-y-5 overflow-y-auto text-xs leading-relaxed text-slate-300">
              <div className="p-3 bg-slate-950/50 rounded-xl border border-slate-800/80 space-y-2">
                <p className="font-semibold text-white">📦 What is this?</p>
                <p className="text-slate-400">
                  This exports a fully dynamic, self-contained single-file HTML version of the ECP Asset Inventory application pre-seeded with all <strong>{allLocationData.length}</strong> currently loaded inventory items.
                </p>
              </div>

              {/* Cookie block specific warning */}
              {isCookieBlocked && (
                <div className="p-3.5 bg-rose-500/10 border border-rose-500/20 rounded-xl space-y-2 text-rose-200">
                  <p className="font-extrabold flex items-center gap-1.5 text-xs text-rose-400">
                    ⚠️ Browser Security Cookie Block Detected!
                  </p>
                  <p className="text-[11px] leading-relaxed text-slate-300">
                    Your web browser is blocking the security session cookies required by the preview server proxy (very common in <strong>Safari, iOS devices, or Private/Incognito tabs</strong>). This causes standard server downloads to fail or download raw login error screens.
                  </p>
                  <p className="text-[11px] font-bold text-amber-200 bg-slate-950/60 p-2.5 rounded border border-rose-500/10">
                    💡 <strong>How to download instantly:</strong> Click the <strong>"Open in new tab"</strong> button at the top-right of your preview screen (or reload this page in a direct browser tab). Once open in its own tab, download options will build and save 100% perfectly with no blocks!
                  </p>
                </div>
              )}

              <div className="p-3.5 bg-amber-500/10 rounded-xl border border-amber-500/20 space-y-1.5">
                <p className="font-bold text-amber-200 flex items-center gap-1.5">⚠️ Crucial Browser Preview Notice:</p>
                <p className="text-slate-300 text-[11px] leading-relaxed">
                  Because this application is running inside a <strong>sandboxed preview iframe</strong>, web browsers often block direct file downloads (Option 1) silently or serve stale cache files.
                </p>
                <p className="text-slate-300 text-[11px] font-medium leading-relaxed bg-slate-950/50 p-2 rounded border border-slate-800/80 mt-1">
                  💡 <strong>To guarantee a perfect download:</strong> Open the live preview in a <strong>New Tab</strong> using the arrow icon at the top right of the preview pane, then download the HTML file there! Alternatively, use <strong>Option 2 (Copy Code)</strong> to save it instantly.
                </p>
              </div>

              <div className="space-y-3">
                <h4 className="font-extrabold text-slate-200">Choose an Export Method:</h4>
                
                {/* Method 1: Try Direct Download */}
                <div className="border border-slate-800 bg-slate-950/30 rounded-xl p-4 space-y-3">
                  <div className="flex items-start gap-2">
                    <span className="bg-amber-500/10 text-amber-400 px-2 py-0.5 rounded text-[10px] font-bold font-mono">Option 1</span>
                    <div>
                      <p className="font-bold text-white">Download Standalone index.html File (Recommended for GitHub Pages)</p>
                      <p className="text-slate-400 text-[11px]">Downloads a single, compiled <code className="text-amber-400">index.html</code> file with the absolute latest code representing your current preview. Upload this file directly to your GitHub repository to host it with GitHub Pages instantly!</p>
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      try {
                        const blob = new Blob([downloadModalData.html], { type: 'text/html' });
                        const url = URL.createObjectURL(blob);
                        const link = document.createElement('a');
                        link.href = url;
                        link.download = 'index.html';
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                        URL.revokeObjectURL(url);
                      } catch (e) {
                        alert("File download block encountered. Please use Option 2 below!");
                      }
                    }}
                    className="w-full bg-amber-600 hover:bg-amber-500 text-slate-950 font-black py-2.5 px-4 rounded-xl transition cursor-pointer text-center text-xs flex items-center justify-center gap-1.5"
                  >
                    <Download className="w-4 h-4" /> Save as index.html (GitHub-Ready)
                  </button>
                </div>

                {/* Method 2: Copy to Clipboard Fallback */}
                <div className="border border-slate-800 bg-slate-950/30 rounded-xl p-4 space-y-3">
                  <div className="flex items-start gap-2">
                    <span className="bg-blue-500/10 text-blue-400 px-2 py-0.5 rounded text-[10px] font-bold font-mono">Option 2</span>
                    <div>
                      <p className="font-bold text-white">Copy Code to Clipboard</p>
                      <p className="text-slate-400 text-[11px]">Copy the fully compiled standalone source code and paste it manually into a local file named <code className="text-amber-400">index.html</code>.</p>
                    </div>
                  </div>
                  <button
                    onClick={async () => {
                      try {
                        await navigator.clipboard.writeText(downloadModalData.html);
                        setCopiedHtml(true);
                        setTimeout(() => setCopiedHtml(false), 3000);
                      } catch (e) {
                        alert("Failed to copy automatically. Please try manual copy.");
                      }
                    }}
                    className={`w-full py-2.5 px-4 rounded-xl font-bold transition cursor-pointer text-center text-xs flex items-center justify-center gap-1.5 ${
                      copiedHtml 
                        ? "bg-emerald-600 text-white" 
                        : "bg-slate-800 hover:bg-slate-700 text-white border border-slate-700"
                    }`}
                  >
                    {copiedHtml ? (
                      <>✨ Copied Successfully!</>
                    ) : (
                      <>Copy Entire HTML Source Code</>
                    )}
                  </button>
                  {copiedHtml && (
                    <div className="p-3 bg-emerald-500/5 border border-emerald-500/20 rounded-lg text-emerald-400 text-[11px] animate-fade-in">
                      💡 <strong>Next steps:</strong> Open any text editor (like Notepad or VS Code), paste the code (<kbd>Ctrl+V</kbd> or <kbd>Cmd+V</kbd>), and save the file with the name <strong>index.html</strong>. You can then double click it to run it completely offline or host it anywhere!
                    </div>
                  )}
                </div>

                {/* Method 3: Download Complete Project ZIP */}
                <div className="border border-slate-800 bg-slate-950/30 rounded-xl p-4 space-y-3">
                  <div className="flex items-start gap-2">
                    <span className="bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded text-[10px] font-bold font-mono">Option 3</span>
                    <div>
                      <p className="font-bold text-white">Download Complete Project ZIP (.zip)</p>
                      <p className="text-slate-400 text-[11px]">Downloads a complete, standard zip package containing the full source code (React, Tailwind, Vite configurations, etc.) of this project representing the latest active preview. The root <code className="text-amber-400">index.html</code> inside this ZIP is pre-compiled for seamless offline use and GitHub Pages!</p>
                    </div>
                  </div>
                  <button
                    onClick={async () => {
                      try {
                        const response = await fetch('/api/download-project-zip');
                        if (!response.ok) {
                          throw new Error('Failed to download project zip');
                        }
                        const contentType = response.headers.get("content-type") || "";
                        if (contentType.includes("text/html")) {
                          const text = await response.clone().text();
                          if (text.includes("blocking a required security cookie") || text.includes("Safari") || text.includes("DOCTYPE")) {
                            throw new Error("auth_cookie_blocked");
                          }
                        }
                        const blob = await response.blob();
                        const url = URL.createObjectURL(blob);
                        const link = document.createElement('a');
                        link.href = url;
                        link.download = 'ECP_Asset_Inventory_Project.zip';
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                        URL.revokeObjectURL(url);
                      } catch (e: any) {
                        console.error(e);
                        setIsCookieBlocked(true);
                        if (e.message === "auth_cookie_blocked") {
                          alert("⚠️ Security Cookie Blocked by Browser:\n\nBecause this preview is running in an iframe, your browser is blocking required authentication cookies (very common in Safari, iOS, or private browsing tabs).\n\nPlease click the 'Open in new tab' button at the top-right of your screen to open the app, then click download. It will work 100% perfectly there!");
                        } else {
                          alert("Failed to download project ZIP. Please try downloading from a New Tab.");
                        }
                      }
                    }}
                    className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-black py-2.5 px-4 rounded-xl transition cursor-pointer text-center text-xs flex items-center justify-center gap-1.5"
                  >
                    <Download className="w-4 h-4" /> Download Complete Project ZIP
                  </button>
                </div>
              </div>
            </div>

            <div className="p-4 bg-slate-950/40 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => setDownloadModalData({ isOpen: false, html: "" })}
                className="bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs px-4 py-2 rounded-xl transition cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
