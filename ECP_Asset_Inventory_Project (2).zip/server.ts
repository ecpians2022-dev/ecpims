import express from "express";
import path from "path";
import fs from "fs";
import AdmZip from "adm-zip";
import { execSync } from "child_process";

async function startServer() {
  // Restore development index.html if we are running in dev mode
  if (process.env.NODE_ENV !== "production") {
    try {
      const devPath = path.join(process.cwd(), "index_dev.html");
      const rootPath = path.join(process.cwd(), "index.html");
      if (fs.existsSync(devPath)) {
        fs.copyFileSync(devPath, rootPath);
        console.log("[Dev Server] Successfully restored development index.html for live preview.");
      }
    } catch (err: any) {
      console.warn("[Dev Server] Could not restore development index.html:", err.message);
    }
  }

  const app = express();
  const PORT = 3000;

  // Helper to get index_single.html path
  const getSingleHtmlPath = () => {
    const paths = [
      path.join(process.cwd(), "dist", "index_single.html"),
      path.join(process.cwd(), "index_single.html"),
      path.join(process.cwd(), "public", "index_single.html"),
    ];
    for (const p of paths) {
      if (fs.existsSync(p)) return p;
    }
    return null;
  };

  // API endpoint to compile and get the latest single-file HTML
  app.get("/api/compile-single-html", (req, res) => {
    try {
      if (process.env.NODE_ENV !== "production") {
        try {
          console.log("Compiling latest preview code on-the-fly...");
          // Trigger a clean production build to ensure we capture all of the user's latest code changes!
          execSync("npm run build", { stdio: "inherit" });
          console.log("Compilation complete.");
        } catch (buildErr: any) {
          console.warn("On-the-fly compilation failed, serving pre-built file:", buildErr.message);
        }
      }

      const singleHtmlPath = getSingleHtmlPath();
      if (singleHtmlPath) {
        res.setHeader("Content-Type", "text/html");
        res.sendFile(singleHtmlPath);
      } else {
        res.status(404).json({ error: "Compiled index_single.html not found." });
      }
    } catch (error: any) {
      console.error("Failed to compile latest single-file HTML:", error);
      res.status(500).json({ error: "Failed to compile latest preview HTML: " + error.message });
    }
  });

  // API endpoint to compile and download the latest single-file index.html directly as an attachment (solves iframe sandbox browser download blocks!)
  app.get("/api/download-single-html", (req, res) => {
    try {
      if (process.env.NODE_ENV !== "production") {
        try {
          console.log("Compiling latest preview code on-the-fly for direct download...");
          execSync("npm run build", { stdio: "inherit" });
          console.log("Compilation complete.");
        } catch (buildErr: any) {
          console.warn("On-the-fly compilation failed, serving pre-built file:", buildErr.message);
        }
      }

      const singleHtmlPath = getSingleHtmlPath();
      if (singleHtmlPath) {
        res.setHeader("Content-Type", "text/html");
        res.setHeader(
          "Content-Disposition",
          "attachment; filename=index.html"
        );
        res.sendFile(singleHtmlPath);
      } else {
        res.status(404).json({ error: "Compiled index_single.html not found." });
      }
    } catch (error: any) {
      console.error("Failed to compile latest single-file HTML:", error);
      res.status(500).json({ error: "Failed to compile latest preview HTML: " + error.message });
    }
  });

  // API endpoint to download the latest project source code as a ZIP
  app.get("/api/download-project-zip", (req, res) => {
    try {
      if (process.env.NODE_ENV !== "production") {
        try {
          console.log("Preparing project ZIP: Triggering clean build to sync all files...");
          execSync("npm run build", { stdio: "inherit" });
          console.log("Clean build completed successfully.");
        } catch (buildError: any) {
          console.warn("Warning: Build step failed inside ZIP generator, proceeding with existing files:", buildError.message);
        }
      }

      const zip = new AdmZip();
      const workspaceRoot = process.cwd();
      const compiledHtmlPath = getSingleHtmlPath();
      const compiledHtmlContent = compiledHtmlPath
        ? fs.readFileSync(compiledHtmlPath)
        : null;

      // Recursively add files to zip, excluding node_modules, dist, .git, etc.
      function addDirToZip(localPath: string, zipPath: string) {
        if (!fs.existsSync(localPath)) return;
        const items = fs.readdirSync(localPath);
        for (const item of items) {
          const fullPath = path.join(localPath, item);
          const stat = fs.statSync(fullPath);

          // Excluded directories/files to keep the ZIP lean and clean
          if (
            item === "node_modules" ||
            item === "dist" ||
            item === ".git" ||
            item === ".github" ||
            item === ".cache" ||
            item === "tmp"
          ) {
            continue;
          }

          const relativeZipPath = zipPath ? `${zipPath}/${item}` : item;

          if (stat.isDirectory()) {
            addDirToZip(fullPath, relativeZipPath);
          } else {
            // Overwrite the root index.html with the compiled index_single.html for flawless out-of-the-box hosting/offline usage
            if (item === "index.html" && relativeZipPath === "index.html" && compiledHtmlContent) {
              console.log("ZIP Generator: Replacing root index.html with compiled standalone version for GitHub Pages deployment.");
              // Keep original as index_source.html inside ZIP so they don't lose the Vite development entrypoint!
              zip.addFile("index_source.html", fs.readFileSync(fullPath));
              zip.addFile("index.html", compiledHtmlContent);
            } else if (item === "index_single.html" && relativeZipPath === "index_single.html") {
              // Skip index_single.html duplication to avoid confusing the user
              continue;
            } else {
              const content = fs.readFileSync(fullPath);
              zip.addFile(relativeZipPath, content);
            }
          }
        }
      }

      addDirToZip(workspaceRoot, "");

      // Ensure logos are at the root of the ZIP so they match relative image paths
      const logoPaths = [
        { name: "ecp_logo.jpg", src: path.join(workspaceRoot, "public", "ecp_logo.jpg") },
        { name: "ecp logo.jpg", src: path.join(workspaceRoot, "public", "ecp_logo.jpg") },
        { name: "ecp_logo_small.jpg", src: path.join(workspaceRoot, "public", "ecp_logo_small.jpg") }
      ];
      for (const logo of logoPaths) {
        if (fs.existsSync(logo.src)) {
          try {
            // Delete if already added to avoid duplication in ZIP structure
            const entry = zip.getEntry(logo.name);
            if (entry) {
              zip.deleteFile(entry);
            }
          } catch (e) {}
          zip.addFile(logo.name, fs.readFileSync(logo.src));
        }
      }

      const zipBuffer = zip.toBuffer();

      res.setHeader("Content-Type", "application/zip");
      res.setHeader(
        "Content-Disposition",
        "attachment; filename=ECP_Asset_Inventory_Project.zip"
      );
      res.setHeader("Content-Length", zipBuffer.length);
      res.send(zipBuffer);
    } catch (error: any) {
      console.error("Failed to generate ZIP archive:", error);
      res.status(500).json({ error: "Failed to generate ZIP archive: " + error.message });
    }
  });

  // Serve static assets or use Vite middleware
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
    console.log("Vite development middleware mounted.");
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
    console.log("Production static server configured.");
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
  process.exit(1);
});
